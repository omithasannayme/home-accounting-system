import difflib
import re
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import figures, query
from app.ai.synonyms import (
    ADVICE_WORDS, CONCEPTS, HIGH_WORDS, LOW_WORDS, PERIOD_PHRASES, SMALL_TALK,
    STOP_WORDS, SUMMARY_WORDS, EXTENDED_SYNONYMS, COMMON_MISSPELLINGS,
)
from app.models.models import ROLE_MEMBER, User, Category, Expense
from app.services.finance_service import allowance_status

TAGLINE = (
    "I am a finance assistant for a Home Accounting App. I can help you with financial calculations. "
    "If you have any questions about your family's finances, feel free to ask!"
)
HINT = (
    'You can ask, for example: "How much is the total income this month?", "What is the budget for October?", '
    '"How much balance is available this year?", "How much allowance was given?" or "How much paid for internet?"'
)
HELP_TEXT = TAGLINE + " " + HINT

TALK_REPLY = {
    "morning": "Good morning, {name}!",
    "afternoon": "Good afternoon, {name}!",
    "evening": "Good evening, {name}!",
    "night": "Good night, {name}!",
    "hello": "Hello, {name}!",
    "salam": "Wa alaikum assalam, {name}!",
    "howare": "I am doing well, thank you for asking!",
    "thanks": "You are welcome!",
    "bye": "Goodbye, {name}! Have a nice day.",
    "who": "I am your family finance assistant.",
    "help": "I can answer questions about income, budget, expenses, savings, balance, allowance, members "
            "and any record in your family data.",
}
TALK_ORDER = ["morning", "afternoon", "evening", "night", "hello", "salam", "howare", "thanks", "bye", "who", "help"]

TITLES = {"mr", "mrs", "ms", "miss", "dr", "md"}
MONTHS = {
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3, "april": 4, "apr": 4, "may": 5,
    "june": 6, "jun": 6, "july": 7, "jul": 7, "august": 8, "aug": 8, "september": 9, "sept": 9, "sep": 9,
    "october": 10, "oct": 10, "november": 11, "nov": 11, "december": 12, "dec": 12,
}
ALL_START, ALL_END = date(2000, 1, 1), date(2100, 1, 1)


def _alt(words) -> re.Pattern:
    body = "|".join(re.escape(w) for w in sorted(words, key=len, reverse=True))
    return re.compile(rf"(?<!\w)(?:{body})(?!\w)")


_ADVICE = _alt(ADVICE_WORDS)
_SUMMARY = _alt(SUMMARY_WORDS)
_PHRASES = sorted(
    (
        (p, c)
        for c, ps in {**CONCEPTS, **EXTENDED_SYNONYMS}.items()
        for p in ps
    ),
    key=lambda x: -len(x[0])
)
_TALK = sorted(SMALL_TALK, key=lambda x: -len(x[0]))
_MONTH_RE = re.compile(
    r"(?<!\w)(january|february|march|april|june|july|august|september|october|november|december|"
    r"jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec)(?:\s+(20\d{2}))?(?!\w)")
_MAY_RE = [
    re.compile(r"(?<!\w)(?:in|for|of|during)\s+(may)(?:\s+(20\d{2}))?(?!\w)"),
    re.compile(r"(?<!\w)(may)\s+(20\d{2})(?!\w)"),
]
_YEAR_RE = re.compile(r"(?<!\d)(20\d{2})(?!\d)")


# ---------- helpers ----------
def normalize(text: str) -> str:
    t = text.lower().replace("\u2019", "'")
    t = re.sub(r"'s\b", "", t)
    t = re.sub(r"[^\w\s]", " ", t).replace("_", " ")
    t = re.sub(r"\s+", " ", t).strip()

    words = t.split()
    words = [COMMON_MISSPELLINGS.get(w, w) for w in words]

    return " ".join(words)

def _find(work: str, phrase: str):
    return re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", work)


def _blank(work: str, m) -> str:
    return work[:m.start()] + " " * (m.end() - m.start()) + work[m.end():]


def _month_end(d: date) -> date:
    return (d.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)


def tk(v) -> str:
    v = float(v or 0)
    if abs(v) < 0.005:
        v = 0.0
    return f"{v:,.0f} Tk" if abs(v - round(v)) < 0.005 else f"{v:,.2f} Tk"


def _range(kind: str, today: date):
    if kind == "month":
        s = today.replace(day=1)
        return s, _month_end(s), s.strftime("%B %Y"), "month"
    if kind == "last_month":
        s = (today.replace(day=1) - timedelta(days=1)).replace(day=1)
        return s, _month_end(s), s.strftime("%B %Y"), "month"
    if kind == "year":
        return date(today.year, 1, 1), date(today.year, 12, 31), f"this year ({today.year})", "year"
    if kind == "last_year":
        y = today.year - 1
        return date(y, 1, 1), date(y, 12, 31), str(y), "year"
    if kind == "today":
        return today, today, f"today ({today:%d %b %Y})", "day"
    if kind == "yesterday":
        d = today - timedelta(days=1)
        return d, d, f"yesterday ({d:%d %b %Y})", "day"
    if kind == "week":
        s = today - timedelta(days=today.weekday())
        return s, s + timedelta(days=6), "this week", "week"
    if kind == "last_week":
        s = today - timedelta(days=today.weekday() + 7)
        return s, s + timedelta(days=6), "last week", "week"
    return ALL_START, ALL_END, "all time", "all"


def parse_period(text: str, today: date):
    work = f" {text} "
    m = _MONTH_RE.search(work)
    if not m:
        for rx in _MAY_RE:
            m = rx.search(work)
            if m:
                break
    if m:
        year = int(m.group(2)) if m.group(2) else today.year
        start = date(year, MONTHS[m.group(1)], 1)
        return start, _month_end(start), start.strftime("%B %Y"), "month", True, _blank(work, m)
    for phrase, kind in PERIOD_PHRASES:
        pm = _find(work, phrase)
        if pm:
            s, e, lab, k = _range(kind, today)
            return s, e, lab, k, True, _blank(work, pm)
    ym = _YEAR_RE.search(work)
    if ym:
        y = int(ym.group(1))
        return date(y, 1, 1), date(y, 12, 31), str(y), "year", True, _blank(work, ym)
    s, e, lab, k = _range("month", today)
    return s, e, lab, k, False, work


def find_concepts(work: str):
    hits = []
    for phrase, concept in _PHRASES:
        while True:
            m = _find(work, phrase)
            if not m:
                break
            hits.append((m.start(), concept))
            work = _blank(work, m)
    hits.sort()
    order: list[str] = []
    for _, c in hits:
        if c not in order:
            order.append(c)
    return order, work


def find_member(work: str, people: list[User], asker: User):
    padded = f" {work} "
    best, best_pat, best_score, tie = None, "", 0, False
    for u in people:
        name = normalize(u.full_name or "")
        cands = []
        if name:
            cands.append((f" {name} ", len(name) + 100))
            cands += [(f" {t} ", len(t)) for t in name.split() if t not in TITLES and len(t) >= 3]
        rel = normalize(u.relation or "")
        if rel and rel != "other":
            cands.append((f" {rel} ", len(rel)))
        for pat, score in cands:
            if pat in padded:
                if score > best_score:
                    best, best_pat, best_score, tie = u, pat, score, False
                elif score == best_score and best is not u:
                    tie = True
    if best and not tie:
        return best, padded.replace(best_pat, " ").strip()
    pm = re.search(r"(?<!\w)(?:my|mine|myself)(?!\w)", padded)
    if pm:
        return asker, _blank(padded, pm).strip()
    return None, work


def strip_small_talk(work: str):
    keys: list[str] = []
    for phrase, key in _TALK:
        while True:
            m = _find(work, phrase)
            if not m:
                break
            if key not in keys:
                keys.append(key)
            work = _blank(work, m)
    return keys, work


def keywords(work: str) -> list[str]:
    out: list[str] = []
    for w in re.findall(r"[a-z]+", work):
        if len(w) < 3 or w in STOP_WORDS or w in out:
            continue
        out.append(w)
    return out[:5]


# ---------- answers ----------
def _talk_reply(keys: list[str], user: User) -> str:
    parts_name = (user.full_name or "").split()
    first = parts_name[0] if parts_name else ""
    name = user.full_name if first.endswith(".") else first
    keys = list(keys)
    if "hello" in keys and any(k in keys for k in ("morning", "afternoon", "evening", "night")):
        keys.remove("hello")
    parts = [TALK_REPLY[k].format(name=name) for k in TALK_ORDER if k in keys]
    return " ".join(parts + [TAGLINE])


def _line(key: str, kp: dict, member, label: str, kind: str) -> str:
    name = f"{member.full_name}'s " if member else ""
    if key == "income":
        return f"{name or 'Total '}income for {label}: {tk(kp['income'])}."
    if key == "budget":
        if member:
            return f"{member.full_name}'s family share for {label}: {tk(kp['budget'])}."
        return f"Budget (total family share) for {label}: {tk(kp['budget'])}."
    if key == "expenses":
        return f"{name or 'Total '}expenses for {label}: {tk(kp['expenses'])} (includes allowance given)."
    if key == "savings":
        return f"{name or 'Total '}savings for {label}: {tk(kp['savings'])}."
    if key == "balance":
        pre = f"{name}balance available" if member else "Balance available"
        return (f"{pre} for {label}: {tk(kp['balance'])} "
                f"(Budget {tk(kp['budget'])} - Expenses {tk(kp['expenses'])}).")
    pre = f"{name}liquid funds available" if member else "Liquid funds available"
    if kind in ("year", "all"):
        return f"{pre} for {label}, sum of all months: {tk(kp['unspent'])}."
    return f"{pre} for {label}: {tk(kp['unspent'])}."


def _allowance_text(db, fam, people, member, start, label, kind, kp) -> str:
    pool = [member] if member else people
    members = [u for u in pool if u.role == ROLE_MEMBER]
    if kind == "month":
        month = start.strftime("%Y-%m")
        total, rows = 0.0, []
        for u in members:
            st = allowance_status(db, fam, u.id, month)
            given, spent = float(st["given"]), float(st["spent"])
            total += given
            if given or spent:
                rows.append(f"- {u.full_name}: given {tk(given)}, spent {tk(spent)}, "
                            f"remaining {tk(given - spent)} ({st['percent_used']:.0f}% used)")
        head = f"Allowance given for {label}: {tk(total)}."
        if member and not members:
            head = f"{member.full_name} does not receive an allowance."
        return "\n".join([head] + rows)
    return f"Allowance given for {label}: {tk(kp['allowance'])}."


def _kpi_lines(db, fam, concepts, kp, member, label, kind, start, people) -> list[str]:
    cs = list(concepts)
    if "allowance" in cs and any(c in cs for c in ("expenses", "balance", "liquid")):
        cs = [c for c in cs if c not in ("expenses", "balance", "liquid")]
    lines, seen = [], set()
    for c in cs:
        key = "liquid" if (c == "balance" and kind in ("year", "all")) else c
        if key in seen:
            continue
        seen.add(key)
        if key == "allowance":
            lines.append(_allowance_text(db, fam, people, member, start, label, kind, kp))
        else:
            lines.append(_line(key, kp, member, label, kind))
    return lines


def summary_text(db, fam: int, start: date, end: date, label: str, kind: str, member=None) -> str:
    mid = member.id if member else None
    k = figures.period_kpis(db, fam, start, end, mid)
    who = f"{member.full_name}'s " if member else ""
    lines = [
        f"{who}Summary for {label}:",
        f"- Income: {tk(k['income'])}",
        f"- Budget (family share): {tk(k['budget'])}",
        f"- Expenses (allowance included): {tk(k['expenses'])}",
        f"- Balance: {tk(k['balance'])}",
        f"- Savings: {tk(k['savings'])}",
        f"- Liquid funds available: {tk(k['unspent'])}",
    ]
    cats = figures.top_categories(db, fam, start, end, mid)
    if cats:
        lines.append("- Top spending: " + ", ".join(f"{n} {tk(a)}" for n, a in cats))
    if kind == "month":
        ps = (start - timedelta(days=1)).replace(day=1)
        pk = figures.period_kpis(db, fam, ps, _month_end(ps), mid)
        if pk["expenses"] > 0:
            diff = k["expenses"] - pk["expenses"]
            if diff:
                lines.append(f"- Expenses are {'higher' if diff > 0 else 'lower'} than last month by {tk(abs(diff))}.")
            else:
                lines.append("- Expenses are the same as last month.")
    if k["balance"] < 0:
        lines.append("Tip: expenses are above the budget. Please review your biggest categories.")
    return "\n".join(lines)


def monthly_summary_text(db: Session, user: User) -> str:
    today = date.today()
    s, e, label, kind = _range("month", today)
    return summary_text(db, user.family_id, s, e, label, kind)

_SUFFIX = r"(?:bill|bills|charge|charges|fee|fees|payment|payments|cost|costs)"

KEY_OF = {
    "income": ("income", "Income"),
    "budget": ("budget", "Family share"),
    "expenses": ("expenses", "Expenses"),
    "savings": ("savings", "Savings"),
    "allowance": ("allowance", "Allowance given"),
    "balance": ("balance", "Balance"),
    "liquid": ("unspent", "Liquid funds available"),
}


def _topic(words: list[str], text: str) -> str:
    """Item name as the user wrote it, for example 'gas bill'."""
    parts = []
    for w in words:
        m = re.search(rf"(?<!\w){re.escape(w)}\s+({_SUFFIX})(?!\w)", text)
        if m:
            suffix = m.group(1)
            parts.append(f"{w} {suffix[:-1] if suffix.endswith('s') else suffix}")
        else:
            parts.append(w)
    return " ".join(parts)


def _records_text(found: dict, words: list[str], label: str, member=None, topic: str | None = None) -> str:
    topic = topic or " ".join(words)
    by = f" by {member.full_name}" if member else ""
    when = "" if label == "all time" else f" in {label}"
    out: list[str] = []

    def block(title, rows, date_of, amount_of):
        total = sum(float(amount_of(r)) for r in rows)
        if len(rows) == 1:
            out.append(f"{title}{by}{when}: {tk(total)} (on {date_of(rows[0])}).")
            return
        out.append(f"{title}{by}{when}: {tk(total)}.")
        out.extend(f"- {date_of(r)}: {tk(amount_of(r))}" for r in rows[:6])
        if len(rows) > 6:
            out.append(f"- and {len(rows) - 6} more.")

    if "expenses" in found:
        block(f"Total paid for {topic}", found["expenses"], lambda r: r[0].expense_date, lambda r: r[0].amount)
    if "income" in found:
        block(f"Total income from {topic}", found["income"], lambda r: r[0].income_date, lambda r: r[0].amount)
    if "allowance" in found:
        block(f"Total allowance for {topic}", found["allowance"], lambda r: r[0].created_at.date(), lambda r: r[0].amount)
    return "\n".join(out)


def _who_text(found: dict, topic: str, label: str) -> str:
    when = "" if label == "all time" else f" in {label}"
    out: list[str] = []

    def block(verb, rows, name_of, date_of, amount_of):
        groups: dict[str, list] = {}
        for r in rows:
            groups.setdefault(name_of(r), []).append(r)
        if len(groups) == 1:
            name, rs = next(iter(groups.items()))
            total = sum(float(amount_of(r)) for r in rs)
            if len(rs) == 1:
                out.append(f"{name} {verb} {topic}{when}: {tk(total)} (on {date_of(rs[0])}).")
                return
            out.append(f"{name} {verb} {topic}{when}: {tk(total)}.")
            out.extend(f"- {date_of(r)}: {tk(amount_of(r))}" for r in rs[:6])
            return
        out.append(f"{verb[0].upper()}{verb[1:]} {topic}{when}:")
        for name, rs in groups.items():
            total = sum(float(amount_of(r)) for r in rs)
            on = f" (on {date_of(rs[0])})" if len(rs) == 1 else ""
            out.append(f"- {name}: {tk(total)}{on}")

    if "expenses" in found:
        block("paid for", found["expenses"], lambda r: r[1], lambda r: r[0].expense_date, lambda r: r[0].amount)
    if "income" in found:
        block("received income from", found["income"], lambda r: r[1] or "Family",
              lambda r: r[0].income_date, lambda r: r[0].amount)
    if "allowance" in found:
        block("received allowance for", found["allowance"], lambda r: r[1],
              lambda r: r[0].created_at.date(), lambda r: r[0].amount)
    return "\n".join(out)


def _by_member_text(db, fam: int, concepts: list[str], people: list[User], start: date, end: date, label: str) -> str:
    out: list[str] = []
    for c in dict.fromkeys(concepts):
        key, title = KEY_OF[c]
        rows = []
        for u in people:
            v = figures.period_kpis(db, fam, start, end, u.id)[key]
            if v:
                rows.append((u.full_name, v))
        if not rows:
            out.append(f"No {title.lower()} found for {label}.")
            continue
        out.append(f"{title} by member for {label}:")
        out.extend(f"- {n}: {tk(v)}" for n, v in sorted(rows, key=lambda r: -r[1]))
    return "\n".join(out)
_HIGH = _alt(HIGH_WORDS)
_LOW = _alt(LOW_WORDS)
_RECENT = re.compile(r"(?<!\w)(?:recent|recently|latest|newest|last)(?!\w)")
_CAT = re.compile(r"(?<!\w)(?:category|categories)(?!\w)")
_MEM = re.compile(r"(?<!\w)(?:member|members|person|people)(?!\w)")
_ITEM = re.compile(
    r"(?<!\w)(?:item|items|bill|bills|payment|payments|purchase|purchases|transaction|transactions|expense|expenses)(?!\w)")

_VOCAB_SET = (
    {w for ps in CONCEPTS.values() for p in ps for w in p.split() if len(w) >= 3}
    | {w for w in ADVICE_WORDS if " " not in w}
    | set(HIGH_WORDS) | set(LOW_WORDS) | set(MONTHS)
    | {"category", "categories", "member", "members", "item", "items", "person", "people"}
)
_VOCAB = sorted(_VOCAB_SET)


def autocorrect(text: str, skip: set[str]) -> str:
    """Fix small typos, for example 'mos' -> 'most', 'categry' -> 'category'."""
    out = []
    for tok in text.split():
        if tok in _VOCAB_SET or tok in STOP_WORDS or tok in skip or len(tok) < 3 or not (tok.isascii() and tok.isalpha()):
            out.append(tok)
            continue
        cutoff = 0.85 if len(tok) < 5 else 0.8
        close = [c for c in difflib.get_close_matches(tok, _VOCAB, n=3, cutoff=cutoff) if c[0] == tok[0]]
        out.append(close[0] if close else tok)
    return " ".join(out)


def _ranking(db, fam, text, concepts, people, member, start, end, label, high, ask_who):
    """Exact answers for 'most / least / highest / lowest' questions, or None."""
    mid = member.id if member else None
    word = "Highest" if high else "Lowest"
    most = "most" if high else "least"
    wants_member = ask_who or bool(_MEM.search(text))

    if _CAT.search(text) or (not (wants_member or _ITEM.search(text)) and (not concepts or "expenses" in concepts)):
        rows = [r for r in figures.category_totals(db, fam, start, end, mid) if r[1] > 0]
        if not rows:
            return f"No expenses found for {label}."
        name, value = rows[0] if high else rows[-1]
        return f"{word} spending category for {label}: {name}, {tk(value)}."

    if wants_member:
        if "income" in concepts:
            key, verb = "income", "earned"
        elif "savings" in concepts:
            key, verb = "savings", "saved"
        elif "budget" in concepts:
            key, verb = "budget", "shared with the family"
        elif "allowance" in concepts:
            key, verb = "allowance", "received"
        else:
            key, verb = "expenses", "spent"
        rows = []
        for u in people:
            v = figures.period_kpis(db, fam, start, end, u.id)[key]
            if v > 0:
                rows.append((u.full_name, v))
        if not rows:
            return f"No data found for {label}."
        name, value = max(rows, key=lambda r: r[1]) if high else min(rows, key=lambda r: r[1])
        return f"{name} {verb} the {most} in {label}: {tk(value)}."

    if _ITEM.search(text):
        found = figures.extreme_expense(db, fam, start, end, mid, high)
        if not found:
            return f"No expenses found for {label}."
        e, _who = found
        return f"{word} single expense for {label}: {e.purpose}, {tk(e.amount)} (on {e.expense_date})."
    return None


_PCT = _alt(["percentage", "percent", "pct", "proportion", "portion", "ratio"])
_PCT_BASE = re.compile(
    r"(?<!\w)(?:percentage|percent|pct|proportion|portion|ratio)\s+(?:of|from|out of)\s+"
    r"(?:(?:the|my|our|total)\s+)*(\w+)")
_BASE_PRIORITY = ["budget", "income", "expenses", "savings"]
_NUM_PRIORITY = ["savings", "expenses", "allowance", "budget", "income"]
_METRIC_OF = {"savings": "savings", "expenses": "expenses", "allowance": "allowance",
              "budget": "family_share", "income": "income"}
_VOCAB_SET |= {"percentage", "percent", "proportion", "portion", "ratio"}
_VOCAB = sorted(_VOCAB_SET)


def _percent_plan(text, concepts, words, member, start, end, label) -> dict:
    """Plan for 'what percentage of the budget was spent on house rent?'"""
    base = None
    m = _PCT_BASE.search(text)
    if m:
        base = next((c for c in _BASE_PRIORITY if m.group(1) in CONCEPTS[c]), None)
    if base is None:
        base = next((c for c in _BASE_PRIORITY if c in concepts), "budget")
    numerator = "expenses"
    if not words:
        numerator = next((c for c in _NUM_PRIORITY if c in concepts and c != base), "expenses")
    return {
        "metric": _METRIC_OF[numerator], "group": "none", "range": (start, end, label),
        "member_id": member.id if member else None, "member_name": member.full_name if member else "",
        "cat_id": None, "cat_name": "", "words": words, "percent_of": base, "order": "desc", "limit": 5,
    }


def respond(db: Session, user: User, message: str):
    """Return ("text", exact answer) or ("llm", info) when the model should find the answer."""
    raw = normalize(message)
    if not raw:
        return "llm", {"words": [], "fallback": None}
    today = date.today()
    fam = user.family_id
    people = list(db.scalars(
        select(User).where(User.family_id == fam, User.is_active.is_(True)).order_by(User.id)).all())

    skip = {
        t
        for u in people
        for t in (normalize(u.full_name or "") + " " + normalize(u.relation or "")).split()
    }

    categories = db.scalars(
        select(Category.name).where(Category.family_id == fam)
    ).all()

    expenses = db.execute(
        select(Expense.purpose, Expense.place).where(Expense.family_id == fam)
    ).all()
    for name in categories:
        skip.update(normalize(name or "").split())

    for purpose, place in expenses:
        skip.update(normalize(purpose or "").split())
        skip.update(normalize(place or "").split())

    text = autocorrect(raw, skip)
    start, end, label, kind, explicit, work = parse_period(text, today)
    period_free = work
    concepts, work = find_concepts(work)
    member, work = find_member(work, people, user)
    talk, work = strip_small_talk(work)
    ask_who = bool(re.search(r"(?<!\w)(?:who|whom|whose)(?!\w)", work))
    is_pct = bool(_PCT.search(text)) or "%" in message
    work = _PCT.sub(" ", work)
    words = keywords(work)
    topic = _topic(words, text)
    mid = member.id if member else None

    high, low = bool(_HIGH.search(text)), bool(_LOW.search(text))
    if (high or low) and not _RECENT.search(period_free):
        ranked = _ranking(db, fam, text, concepts, people, member, start, end, label, high, ask_who)
        if ranked:
            return "text", ranked

    if is_pct and (concepts or words):
        plan = _percent_plan(text, concepts, words, member, start, end, label)
        res = query.execute_plan(db, fam, plan, [(u.id, u.full_name) for u in people])
        return "text", query.render_result(res)

    if _SUMMARY.search(text):
        return "text", summary_text(db, fam, start, end, label, kind, member)
    if _ADVICE.search(text):
        return "llm", {"words": words, "fallback": None, "advice": True}
    if not concepts and not words:
        if talk:
            return "text", _talk_reply(talk, user)
        return "llm", {"words": [], "fallback": None}

    notes: list[str] = []
    if words:
        s, e, lab = (start, end, label) if explicit else (ALL_START, ALL_END, "all time")
        want: set[str] = set()
        if "income" in concepts:
            want.add("income")
        if "allowance" in concepts:
            want.add("allowance")
        if "expenses" in concepts or not concepts:
            want.add("expenses")
        if not concepts:
            want |= {"income", "allowance"}
        found = figures.find_records(db, fam, words, s, e, mid, want)
        if found:
            if ask_who:
                return "text", _who_text(found, topic, lab)
            return "text", _records_text(found, words, lab, member, topic)
        if not concepts:
            return "llm", {
                "words": words,
                "fallback": f'I could not find any record about "{" ".join(words)}" in your family data. ' + HINT,
            }
        notes.append(f'No record matches "{" ".join(words)}", so here is the overall figure:')

    if ask_who and concepts and not words:
        return "text", _by_member_text(db, fam, concepts, people, start, end, label)

    kp = figures.period_kpis(db, fam, start, end, mid)
    lines = _kpi_lines(db, fam, concepts, kp, member, label, kind, start, people)
    return "text", "\n".join(notes + lines)