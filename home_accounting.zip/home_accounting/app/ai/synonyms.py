"""Words the AI assistant understands. Add more words to any list to teach it new words."""


def _w(text: str) -> list[str]:
    return [w.strip() for w in text.split(",") if w.strip()]


CONCEPTS = {
    "income": _w(
        "income, incomes, total income, earnings, earning, earned, earn, earns, salary, salaries, wage, wages, "
        "paycheck, pay check, payroll, revenue, revenues, receipts, proceeds, gross income, net income, "
        "take home pay, take home, profit, profits, gain, gains, remuneration, compensation, pension, commission, "
        "bonus, bonuses, business income, personal income, family income, money received, money coming in, "
        "money earned, cash inflow, inflow, inflows, incoming money, credited, income received, total earnings, "
        "total salary, how much earned, how much earn, earned money, takings, turnover, honorarium, rent received, "
        "dividend, dividends, interest income, side income, extra income, additional income, total revenue, "
        "total receipts, income amount, salary income, job income, work income"
    ),
    "budget": _w(
        "budget, budgets, family budget, household budget, home budget, budget amount, total budget, appropriation, "
        "spending plan, financial plan, planned spending, spending limit, expense limit, spending cap, ceiling, "
        "kitty, pool, pooled, family fund, family pool, common fund, shared fund, household fund, joint fund, "
        "family share, family shares, share for family, share with family, shared with family, shared for family, "
        "sharing with family, family contribution, family contributions, contribution to family, "
        "contributed to family, contribution, contributions, contributed, contribute, shared amount, "
        "amount shared, money shared, family money, home fund, household pool, common pool, communal fund, "
        "family kitty, funds for family, shared money, share amount, planned budget, budgeted, budget plan, "
        "amount for family, money for family, given to family, family wallet, share, shares, shared, sharing"
    ),
    "expenses": _w(
        "expense, expenses, total expenses, expenditure, expenditures, spending, spendings, spend, spent, spends, "
        "cost, costs, costing, outgoing, outgoings, outflow, outflows, payment, payments, paid, pay out, payout, "
        "payouts, purchase, purchases, bought, buying, bill, bills, charge, charges, fee, fees, dues, outlay, "
        "outlays, disbursement, disbursements, money gone, money out, money went, how much spent, how much paid, "
        "how much cost, deduction, deductions, shopping, expensed, total spending, total spent, total cost, "
        "total paid, money spent, expense amount, spending amount, amount spent, amount paid, paying, pay, pays, "
        "expenditure amount, running costs, overheads, overhead"
    ),
    "savings": _w(
        "savings, saving, saved, save, saves, total savings, savings amount, reserve, reserves, nest egg, "
        "rainy day fund, emergency fund, stash, set aside, put aside, kept aside, banked, bank deposit, "
        "deposit to bank, deposited, piggy bank, accumulated, accumulation, cushion, backup fund, safety net, "
        "future fund, money saved, amount saved, savings account, savings fund, thrift, conserved, stockpile, "
        "hoard, hoarded, lay by, laid by, put away, tucked away, sinking fund, retirement fund, "
        "long term savings, short term savings, how much saved, how much save, savings balance, total saved, "
        "saved money, saving amount, money kept, money kept aside, deposit, deposits"
    ),
    "balance": _w(
        "balance, balances, remaining balance, balance available, available balance, remaining, remains, remain, "
        "remainder, left, left over, leftover, leftovers, residual, residue, net balance, net amount, in hand, "
        "on hand, cash in hand, cash on hand, hand cash, money left, money remaining, money available, "
        "amount left, amount remaining, amount available, funds left, funds remaining, funds available, "
        "what remains, what is left, how much left, how much remaining, how much available, spare, spare money, "
        "surplus, deficit, shortfall, difference, closing balance, outstanding, outstanding balance, balance left, "
        "remaining budget, budget left, budget remaining, available budget, unused budget, unused, to spend, "
        "left to spend, still available, yet to spend, current balance, present balance, running balance, "
        "net remaining"
    ),
    "liquid": _w(
        "liquid funds, liquid fund, liquid funds available, liquid money, liquid cash, liquidity, liquid assets, "
        "liquid balance, unspent, total unspent, unspent money, unspent amount, unspent funds, not spent, "
        "untouched money, idle money, idle cash, free cash, free money, free funds, spare cash, cash reserves, "
        "cash reserve, cash available, available cash, available funds, funds in hand, usable money, usable funds, "
        "usable cash, disposable income, disposable money, disposable funds, spendable money, spendable funds, "
        "spendable cash, net unspent, total liquid, total liquidity, money in hand, ready cash, ready money, "
        "cash flow, cashflow, net cash, net cash flow, available liquidity, available liquid funds, "
        "liquid position, financial liquidity, free balance, uncommitted funds, uncommitted money, "
        "unallocated money, unallocated funds, money not spent, amount unspent, left unspent"
    ),
    "allowance": _w(
        "allowance, allowances, pocket money, pocket cash, pocket allowance, kids allowance, child allowance, "
        "children allowance, spending money, allotted money, given money, money given, handout, handouts, stipend, "
        "grant, grants, subsidy, support money, upkeep, maintenance money, ration, rations, daily money, "
        "lunch money, tiffin money, school money, personal allowance, member allowance, allowance given, "
        "allowance amount, allowance balance, allowance remaining, allowance left, allowance spent, allowance used, "
        "allowance history, allowance summary, given allowance, allowance to members, allowance for members, "
        "amount given to, money given to, cash given, handed money, spending allowance, personal spending money, "
        "child pocket money, kids pocket money, children pocket money, allowance fund, allowance paid, "
        "allowed money, allowed amount, member pocket money, family allowance"
    ),
}

PERIOD_PHRASES = [
    ("last month", "last_month"), ("previous month", "last_month"), ("past month", "last_month"),
    ("prior month", "last_month"), ("month before", "last_month"),
    ("this month", "month"), ("current month", "month"), ("present month", "month"),
    ("month to date", "month"), ("monthly", "month"), ("each month", "month"), ("per month", "month"),
    ("for the month", "month"),
    ("this year", "year"), ("current year", "year"), ("present year", "year"), ("year to date", "year"),
    ("ytd", "year"), ("yearly", "year"), ("annual", "year"), ("annually", "year"), ("whole year", "year"),
    ("full year", "year"), ("all year", "year"), ("year wise", "year"), ("yearwise", "year"),
    ("per year", "year"), ("each year", "year"), ("for the year", "year"), ("this fiscal year", "year"),
    ("last year", "last_year"), ("previous year", "last_year"), ("past year", "last_year"),
    ("prior year", "last_year"),
    ("today", "today"), ("todays", "today"), ("yesterday", "yesterday"),
    ("this week", "week"), ("current week", "week"), ("weekly", "week"),
    ("last week", "last_week"), ("previous week", "last_week"),
    ("all time", "all"), ("alltime", "all"), ("overall", "all"), ("lifetime", "all"), ("ever", "all"),
    ("since the beginning", "all"), ("since beginning", "all"), ("till date", "all"), ("till now", "all"),
    ("until now", "all"), ("all records", "all"), ("whole history", "all"), ("entire history", "all"),
]
PERIOD_PHRASES.sort(key=lambda x: -len(x[0]))

SMALL_TALK = [
    ("good morning", "morning"), ("morning", "morning"), ("gm", "morning"),
    ("good afternoon", "afternoon"), ("afternoon", "afternoon"),
    ("good evening", "evening"), ("evening", "evening"), ("good night", "night"),
    ("hi", "hello"), ("hii", "hello"), ("hiii", "hello"), ("hello", "hello"), ("helo", "hello"),
    ("hey", "hello"), ("hola", "hello"), ("greetings", "hello"), ("howdy", "hello"), ("yo", "hello"),
    ("sup", "hello"), ("namaste", "hello"), ("nomoskar", "hello"),
    ("assalamu alaikum", "salam"), ("assalamualaikum", "salam"), ("assalamu alaykum", "salam"),
    ("as salamu alaikum", "salam"), ("salam", "salam"), ("salaam", "salam"),
    ("how are you", "howare"), ("how are you doing", "howare"), ("how r u", "howare"),
    ("how do you do", "howare"), ("how it going", "howare"), ("how is it going", "howare"),
    ("what up", "howare"), ("what is up", "howare"), ("how have you been", "howare"),
    ("are you ok", "howare"), ("are you fine", "howare"), ("how you doing", "howare"),
    ("thank you", "thanks"), ("thanks", "thanks"), ("thx", "thanks"), ("thank u", "thanks"),
    ("many thanks", "thanks"), ("great", "thanks"), ("awesome", "thanks"), ("nice", "thanks"),
    ("good job", "thanks"), ("well done", "thanks"),
    ("bye", "bye"), ("goodbye", "bye"), ("good bye", "bye"), ("see you", "bye"),
    ("see you later", "bye"), ("take care", "bye"),
    ("who are you", "who"), ("what are you", "who"), ("your name", "who"), ("what is your name", "who"),
    ("introduce yourself", "who"),
    ("what can you do", "help"), ("help", "help"), ("what do you do", "help"), ("how can you help", "help"),
    ("can you help", "help"),
]

SUMMARY_WORDS = ["summary", "summarise", "summarize", "overview", "report"]

ADVICE_WORDS = [
    "advice", "advise", "tip", "tips", "suggest", "suggestion", "suggestions", "recommend", "recommendation",
    "recommendations", "analyse", "analyze", "analysis", "insight", "insights", "trend", "trends", "compare",
    "comparison", "why", "reduce", "improve", "strategy", "ideas", "idea", "explain", "how can i",
    "how should i", "what should i", "help me save", "how to save", "ways to save",
]

ADVICE_WORDS += [
    "which", "most", "least", "highest", "lowest", "biggest", "largest", "smallest", "maximum", "minimum",
    "top", "rank", "ranking", "average", "percent", "percentage", "ratio",
]

STOP_WORDS = set(
    "a an the is are was were be been am i me my mine myself we our us you your yours he she it they them his "
    "her its their theirs how what whats hows thats lets when where which who whom much many amount amounts "
    "total sum there here did do does done for of in on at to from by with and or but this that these those "
    "give show tell please can could would should will shall may might also about any all each every some tk "
    "taka bdt money cash funds fund family families member members current currently now then than as if into "
    "out up down over under again still just only more most less least very really get got have has had having "
    "want know need let list check find see data details detail information info number numbers figure figures "
    "value values count allocate allocated allocation allocations allotment month months year years day days "
    "week weeks today yesterday hi hello hey thanks thank ok okay yes no not dont don didn doesn isn aren wasn "
    "won couldn wouldn shouldn so far ever tillnow mrs miss good per via between during before after till until "
    "since while because though through across record records entry entries transaction transactions history "
    "tell tells" .split()
)

STOP_WORDS |= set(
    "provide provides provided providing gave give gives given giving receive receives received receiving "
    "obtain obtained issue issues issued distribute distributed distributing assign assigned assigning allot "
    "allots allotted hand handed offer offered offering granted get gets getting gotten take takes took taken "
    "make makes made put puts keep keeps use uses using used did going went come came belong belongs belonged "
    "happen happened exist exists contain contains include includes included quantity".split()
)

HIGH_WORDS = ["most", "highest", "biggest", "largest", "maximum", "max", "top", "greatest", "costliest", "priciest"]
LOW_WORDS = ["least", "lowest", "smallest", "minimum", "min", "fewest", "cheapest"]

# ---------------------------------------------------------------------------
# Extended natural-language synonyms
# ---------------------------------------------------------------------------
# These are additional ways users may ask about the same financial concept.
# Keep the canonical key on the left; the AI can use any phrase on the right.

EXTENDED_SYNONYMS = {
    "expenses": _w(
        "expense, expenses, spending, spend, spent, spends, expenditure, expenditures, "
        "cost, costs, costing, payment, payments, paid, pay, paying, payout, payouts, "
        "outgoing, outgoings, outflow, outflows, money spent, money paid, money used, "
        "money gone, money out, amount spent, amount paid, amount used, spending amount, "
        "expense amount, total spending, total spent, total cost, total paid, total expense, "
        "how much spent, how much paid, how much cost, what did I spend, what have I spent, "
        "what was spent, what was paid, what did it cost, expenditure amount, spending cost, "
        "household spending, family spending, home spending, household expenses, family expenses, "
        "home expenses, living expenses, daily expenses, monthly expenses, yearly expenses"
    ),

    "income": _w(
        "income, incomes, earning, earnings, earned, earn, earns, salary, salaries, "
        "wage, wages, paycheck, pay check, payroll, revenue, revenues, receipts, proceeds, "
        "money received, money coming in, money earned, cash inflow, inflow, inflows, "
        "incoming money, income received, total earnings, total salary, total income, "
        "how much earned, how much earn, earned money, take home, take-home pay, "
        "pay received, salary received, money coming, money received, family income, "
        "household income, monthly income, yearly income, total revenue, total receipts"
    ),

    "allowance": _w(
        "allowance, allowances, pocket money, pocket-money, spending allowance, "
        "member allowance, family allowance, personal allowance, monthly allowance, "
        "allowance money, allowance amount, money given, money allocated, allocated money, "
        "given allowance, allowance given, allowance received, money for allowance, "
        "allowance budget, allowance limit, allowance spending, allowance expense, "
        "allowance expenses, allowance payment, allowance payments, pocket cash, "
        "personal spending money, member spending money, money allocated to member, "
        "money given to member, amount given, amount allocated, given amount"
    ),

    "budget": _w(
        "budget, budgets, budgeted, budget amount, total budget, family budget, "
        "household budget, home budget, spending plan, financial plan, planned spending, "
        "spending limit, spending cap, expense limit, expense cap, spending ceiling, "
        "planned amount, planned expense, planned expenses, allocated budget, "
        "allocated amount, family fund, household fund, home fund, family pool, "
        "shared fund, common fund, common pool, family money, household money, "
        "available budget, remaining budget, budget remaining, budget usage, budget used"
    ),

    "savings": _w(
        "saving, savings, saved, save, reserve, reserves, nest egg, rainy day fund, "
        "emergency fund, stash, set aside, put aside, kept aside, banked, bank deposit, "
        "deposit, deposited, piggy bank, accumulated, accumulation, cushion, backup fund, "
        "safety net, future fund, money saved, amount saved, savings amount, savings account, "
        "savings fund, money kept, money put aside, money reserved, reserved money, "
        "saved money, total saved, total savings, monthly savings, yearly savings"
    ),

    "balance": _w(
        "balance, balances, account balance, remaining balance, current balance, "
        "available balance, money remaining, remaining money, money left, amount left, "
        "funds remaining, funds left, cash remaining, cash left, leftover money, "
        "remaining funds, available funds, unspent money, unspent funds, unused money, "
        "unused funds, balance left, balance remaining, final balance, net balance"
    ),

    "liquid_funds": _w(
        "liquid funds, liquid fund, available funds, available money, free money, "
        "money available, cash available, cash on hand, available cash, usable money, "
        "usable funds, spendable money, spendable funds, money I can spend, "
        "money we can spend, funds I can use, funds available, cash remaining, "
        "money left to spend, funds left to spend, disposable funds, disposable money"
    ),

    "highest": _w(
        "highest, high, most, maximum, max, biggest, largest, greatest, top, topmost, "
        "costliest, priciest, most expensive, most costly, highest amount, highest cost, "
        "largest amount, biggest amount, greatest amount, maximum amount, number one, "
        "no one higher, highest spending, highest expense, highest income"
    ),

    "lowest": _w(
        "lowest, low, least, minimum, min, smallest, tiniest, cheapest, least expensive, "
        "least costly, lowest amount, lowest cost, smallest amount, minimum amount, "
        "lowest spending, lowest expense, lowest income"
    ),

    "count": _w(
        "count, counts, number, numbers, how many, quantity, total number, number of, "
        "how much records, how many records, how many entries, how many transactions, "
        "number of expenses, number of incomes, number of payments"
    ),

    "show": _w(
        "show, shows, showing, display, displays, displayed, list, lists, listed, "
        "tell me, tell, give me, provide, presents, present, find, find me, "
        "let me know, what is, what are, give, explain, report"
    ),

    "monthly": _w(
        "monthly, month, this month, current month, per month, every month, "
        "monthly total, month total, monthly amount, monthly spending, monthly expenses, "
        "monthly income, monthly savings, monthly allowance"
    ),

    "yearly": _w(
        "yearly, annual, annually, year, this year, current year, per year, "
        "yearly total, annual total, yearly amount, annual amount, yearly spending, "
        "annual spending, yearly expenses, annual expenses, yearly income, annual income"
    ),
}


# Common typing mistakes. These map a misspelled word to the intended word.
COMMON_MISSPELLINGS = {
    "internt": "internet",
    "internat": "internet",
    "interent": "internet",
    "intenet": "internet",
    "inernet": "internet",
    "expence": "expense",
    "expences": "expenses",
    "expenese": "expenses",
    "expendeture": "expenditure",
    "allowence": "allowance",
    "allowanse": "allowance",
    "allownance": "allowance",
    "budjet": "budget",
    "budgget": "budget",
    "savng": "saving",
    "savins": "savings",
    "balence": "balance",
    "balnce": "balance",
    "incom": "income",
    "incme": "income",
    "salarry": "salary",
    "salery": "salary",
    "paymant": "payment",
    "payement": "payment",
    "reciept": "receipt",
    "recipt": "receipt",
    "mont": "month",
    "yer": "year",
}