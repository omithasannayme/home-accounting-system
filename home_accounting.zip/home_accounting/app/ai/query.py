"""Safe query layer: the AI model only chooses a query plan. This code checks it, runs it and does ALL the math."""
import difflib
import re
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.ai import figures
from app.ai.synonyms import STOP_WORDS
from app.models.models import Allowance, Category, Expense, Income, User

METRICS = ["expenses", "income", "family_share", "savings", "allowance", "balance", "liquid_funds", "count"]
GROUPS = ["none", "category", "member", "month", "day", "type"]
PERIODS = ["this_month", "last_month", "this_year", "last_year", "all_time", "today", "this_week"]
BASES = ["none", "budget", "income", "expenses", "savings"]
BASE_NAMES = {"budget": "budget", "income": "income", "expenses": "total expenses", "savings": "savings"}
GROUP_NAMES = {"category": "category", "member": "member", "month": "month", "day": "day", "type": "income type"}
KEY_OF = {"expenses": "expenses", "income": "income", "family_share": "budget", "savings": "savings",
          "allowance": "allowance"}

PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "metric": {"type": "string", "enum": METRICS},
        "group_by": {"type": "string", "enum": GROUPS},
        "period": {"type": "string", "enum": PERIODS},
        "month": {"type": "string"},
        "member": {"type": "string"},
        "category": {"type": "string"},
        "text": {"type": "string"},
        "percent_of": {"type": "string", "enum": BASES},
        "order": {"type": "string", "enum": ["desc", "asc"]},
        "limit": {"type": "integer"},
    },
    "required": ["metric", "group_by", "period", "month", "member", "category", "text", "percent_of",
                 "order", "limit"],
}

PLANNER_SYSTEM = """You convert a question about a family's finances into a JSON query plan. Output ONLY the JSON.
Fields:
- metric: expenses, income, family_share (money shared with the family = the budget), savings, allowance (allowance given to members), balance, liquid_funds, count (number of expense records)
- group_by: none, category, member, month, day, type (income type)
- period: this_month, last_month, this_year, last_year, all_time, today, this_week
- month: YYYY-MM when a month is named, otherwise empty
- member: a name from MEMBERS, otherwise empty
- category: a name from CATEGORIES, otherwise empty
- text: item words such as house rent, otherwise empty
- percent_of: budget, income, expenses or savings when the question asks for a percentage or share, otherwise none
- order: desc or asc; limit: 1 to 10
Examples:
Question: What percentage of the budget was spent on house rent?
{"metric":"expenses","group_by":"none","period":"this_month","month":"","member":"","category":"","text":"house rent","percent_of":"budget","order":"desc","limit":5}
Question: Which member earned the most last month?
{"metric":"income","group_by":"member","period":"last_month","month":"","member":"","category":"","text":"","percent_of":"none","order":"desc","limit":1}
Question: How many expenses were recorded in September?
{"metric":"count","group_by":"none","period":"this_month","month":"YEAR-09","member":"","category":"","text":"","percent_of":"none","order":"desc","limit":5}
Question: Show expenses by category this year
{"metric":"expenses","group_by":"category","period":"this_year","month":"","member":"","category":"","text":"","percent_of":"none","order":"desc","limit":10}
Question: How much did Mrs. A spend on food this month?
{"metric":"expenses","group_by":"none","period":"this_month","month":"","member":"Mrs. A","category":"","text":"food","percent_of":"none","order":"desc","limit":5}"""


# ---------- small helpers ----------
def _num(v) -> str:
    v = float(v or 0)
    if abs(v) < 0.005:
        v = 0.0
    return f"{v:,.0f}" if abs(v - round(v)) < 0.005 else f"{v:,.2f}"


def _money(v) -> str:
    return f"{_num(v)} Tk"


def _dec(v) -> Decimal:
    return Decimal(str(v or 0))


def _pct(num: Decimal, base: Decimal):
    if base == 0:
        return None
    return float((num / base * 100).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def month_end(d: date) -> date:
    return (d.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)


def period_range(name: str, today: date):
    if name == "last_month":
        s = (today.replace(day=1) - timedelta(days=1)).replace(day=1)
        return s, month_end(s), s.strftime("%B %Y")
    if name == "this_year":
        return date(today.year, 1, 1), date(today.year, 12, 31), f"this year ({today.year})"
    if name == "last_year":
        y = today.year - 1
        return date(y, 1, 1), date(y, 12, 31), str(y)
    if name == "all_time":
        return date(2000, 1, 1), date(2100, 1, 1), "all time"
    if name == "today":
        return today, today, f"today ({today:%d %b %Y})"
    if name == "this_week":
        s = today - timedelta(days=today.weekday())
        return s, s + timedelta(days=6), "this week"
    s = today.replace(day=1)
    return s, month_end(s), s.strftime("%B %Y")


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", (s or "").lower())).strip()


def _closest(value: str, options: list):
    """Match a name written by the model to a real (id, name)."""
    v = _norm(value)
    if not v:
        return None
    names = {_norm(n): (i, n) for i, n in options}
    if v in names:
        return names[v]
    close = difflib.get_close_matches(v, list(names), n=1, cutoff=0.8)
    if close:
        return names[close[0]]
    for key, val in names.items():
        if v in key.split() or key in v.split():
            return val
    return None


def _words(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z]+", (text or "").lower()) if len(w) >= 3 and w not in STOP_WORDS][:4]


# ---------- context and plan ----------
def context(db: Session, fam: int) -> dict:
    people = [(u.id, u.full_name) for u in db.scalars(
        select(User).where(User.family_id == fam, User.is_active.is_(True)).order_by(User.id)).all()]
    cats = [(c.id, c.name) for c in db.scalars(
        select(Category).where(Category.family_id == fam).order_by(Category.name)).all()]
    return {"people": people, "categories": cats}


def planner_messages(ctx: dict, message: str, today: date):
    user = (f"Today: {today.isoformat()}\nMEMBERS: {', '.join(n for _, n in ctx['people'])}\n"
            f"CATEGORIES: {', '.join(n for _, n in ctx['categories'])}\nQUESTION: {message}")
    return PLANNER_SYSTEM.replace("YEAR", str(today.year)), user


def parse_plan(raw, ctx: dict, today: date):
    """Check the plan written by the model. Returns a safe plan dict, or None."""
    if not isinstance(raw, dict) or raw.get("metric") not in METRICS:
        return None
    metric = raw["metric"]
    group = raw.get("group_by") if raw.get("group_by") in GROUPS else "none"
    period = raw.get("period") if raw.get("period") in PERIODS else "this_month"
    month = str(raw.get("month") or "")
    if re.fullmatch(r"20\d{2}-(0[1-9]|1[0-2])", month):
        s = date(int(month[:4]), int(month[5:7]), 1)
        rng = (s, month_end(s), s.strftime("%B %Y"))
    else:
        rng = period_range(period, today)
    member = _closest(str(raw.get("member") or ""), ctx["people"])
    cat_raw = str(raw.get("category") or "")
    cat = _closest(cat_raw, ctx["categories"])
    words = _words(str(raw.get("text") or ""))
    if cat_raw and not cat:
        words += [w for w in _words(cat_raw) if w not in words]
    percent_of = raw.get("percent_of") if raw.get("percent_of") in BASES and raw.get("percent_of") != "none" else None
    try:
        limit = max(1, min(10, int(raw.get("limit") or 5)))
    except (TypeError, ValueError):
        limit = 5
    return {
        "metric": metric, "group": group, "range": rng,
        "member_id": member[0] if member else None, "member_name": member[1] if member else "",
        "cat_id": cat[0] if cat else None, "cat_name": cat[1] if cat else "",
        "words": words, "percent_of": percent_of,
        "order": "asc" if raw.get("order") == "asc" else "desc", "limit": limit,
    }


# ---------- data (all exact, no AI) ----------
def _best_rows(rows, text_of, words):
    if not words:
        return rows
    scored = [(sum(1 for w in words if w in text_of(r).lower()), r) for r in rows]
    top = max((s for s, _ in scored), default=0)
    return [r for s, r in scored if s == top and s > 0]


def _expenses(db, fam, start, end, member_id, cat_id, words):
    q = (
        select(Expense, User.full_name, Category.name)
        .join(User, User.id == Expense.user_id)
        .join(Category, Category.id == Expense.category_id)
        .where(Expense.family_id == fam, Expense.expense_date >= start, Expense.expense_date <= end)
    )
    if member_id is not None:
        q = q.where(Expense.user_id == member_id)
    if cat_id is not None:
        q = q.where(Expense.category_id == cat_id)
    if words:
        q = q.where(or_(*[or_(Expense.purpose.ilike(f"%{w}%"), Category.name.ilike(f"%{w}%")) for w in words]))
    rows = db.execute(q.limit(5000)).all()
    return _best_rows(rows, lambda r: f"{r[0].purpose} {r[2]}", words)


def _incomes(db, fam, start, end, member_id, words, kind):
    q = (
        select(Income, User.full_name).outerjoin(User, User.id == Income.user_id)
        .where(Income.family_id == fam, Income.kind == kind,
               Income.income_date >= start, Income.income_date <= end)
    )
    if member_id is not None:
        q = q.where(Income.user_id == member_id)
    if words:
        q = q.where(or_(*[or_(Income.description.ilike(f"%{w}%"), Income.income_type.ilike(f"%{w}%"))
                          for w in words]))
    rows = db.execute(q.limit(5000)).all()
    return _best_rows(rows, lambda r: f"{r[0].description or ''} {r[0].income_type}", words)


def _allowances(db, fam, start, end, member_id, words):
    al_date = func.date(Allowance.created_at)
    q = (
        select(Allowance, User.full_name).join(User, User.id == Allowance.user_id)
        .where(Allowance.family_id == fam, al_date >= start, al_date <= end)
    )
    if member_id is not None:
        q = q.where(Allowance.user_id == member_id)
    if words:
        q = q.where(or_(*[Allowance.note.ilike(f"%{w}%") for w in words]))
    rows = db.execute(q.limit(5000)).all()
    return _best_rows(rows, lambda r: r[0].note or "", words)


def execute_plan(db: Session, fam: int, plan: dict, people: list) -> dict:
    start, end, label = plan["range"]
    metric, group = plan["metric"], plan["group"]
    mid, cid, words = plan["member_id"], plan["cat_id"], plan["words"]
    kp = figures.period_kpis(db, fam, start, end, mid)
    res = {"metric": metric, "group": "none", "label": label, "words": words, "member": plan["member_name"],
           "category": plan["cat_name"], "rows": [], "total": None, "base": None, "percent": None,
           "filtered": False, "count": False}

    if metric in ("balance", "liquid_funds"):
        res["total"] = _dec(kp["balance"] if metric == "balance" else kp["unspent"])
        return res
    if metric == "count":
        res["total"] = Decimal(len(_expenses(db, fam, start, end, mid, cid, words)))
        res["count"] = True
        return res

    if metric == "expenses":
        records = _expenses(db, fam, start, end, mid, cid, words)
        amount, who = (lambda r: r[0].amount), (lambda r: r[1])
        day, cat = (lambda r: r[0].expense_date), (lambda r: r[2])
    elif metric == "allowance":
        records = _allowances(db, fam, start, end, mid, words)
        amount, who = (lambda r: r[0].amount), (lambda r: r[1])
        day, cat = (lambda r: r[0].created_at.date()), None
    else:
        records = _incomes(db, fam, start, end, mid, words, metric)
        amount, who = (lambda r: r[0].amount), (lambda r: r[1] or "Family")
        day, cat = (lambda r: r[0].income_date), (lambda r: r[0].income_type)

    if group == "category" and metric != "expenses":
        group = "none"
    if group == "type" and metric not in ("income", "family_share", "savings"):
        group = "none"
    filtered = bool(words or cid)
    res["group"], res["filtered"] = group, filtered

    rows: list = []
    total = None
    if group == "none":
        total = (sum((_dec(amount(r)) for r in records), Decimal(0)) if filtered
                 else _dec(kp[KEY_OF[metric]]))
    elif group == "member" and not filtered:
        for pid, pname in people:
            v = _dec(figures.period_kpis(db, fam, start, end, pid)[KEY_OF[metric]])
            if v > 0:
                rows.append((pname, v))
    else:
        bucket: dict = {}
        for r in records:
            if group in ("category", "type"):
                k = cat(r)
            elif group == "member":
                k = who(r)
            elif group == "month":
                k = day(r).strftime("%Y-%m")
            else:
                k = day(r).isoformat()
            bucket[k] = bucket.get(k, Decimal(0)) + _dec(amount(r))
        rows = list(bucket.items())

    if group in ("month", "day"):
        rows.sort(key=lambda r: r[0])
        rows = rows[:60]
    elif rows:
        rows.sort(key=lambda r: r[1], reverse=(plan["order"] == "desc"))
        rows = rows[: plan["limit"]]

    base = None
    if plan["percent_of"]:
        pk = plan["percent_of"]
        if pk == "expenses":
            value = sum((_dec(r[0].amount) for r in _expenses(db, fam, start, end, mid, None, [])), Decimal(0))
        else:
            value = _dec(kp[pk])
        base = (BASE_NAMES[pk], value)
    res["base"] = base
    res["total"] = total
    if total is not None and base:
        res["percent"] = _pct(total, base[1])
    res["rows"] = [(n, v, _pct(v, base[1]) if base else None) for n, v in rows]
    return res


# ---------- text of the exact result ----------
def _subject(res: dict) -> str:
    m = res["metric"]
    who = f" by {res['member']}" if res["member"] else ""
    topic = res["category"] or " ".join(res["words"])
    if m == "expenses":
        return (f"Spending on {topic}" if topic else "Expenses") + who
    if m == "income":
        return (f"Income from {topic}" if topic else "Income") + who
    names = {"family_share": "Family share", "savings": "Savings", "allowance": "Allowance given",
             "balance": "Balance available", "liquid_funds": "Liquid funds available",
             "count": "Number of expense records"}
    return names[m] + who


def is_empty(res: dict) -> bool:
    if res["group"] != "none":
        return not res["rows"]
    return bool(res["filtered"]) and (res["total"] is None or res["total"] == 0)


def render_result(res: dict) -> str:
    label = res["label"]
    if is_empty(res):
        what = res["category"] or " ".join(res["words"])
        return f'No records found for "{what}" in {label}.' if what else f"No matching records found for {label}."
    subject = _subject(res)
    if res["group"] != "none":
        lines = [f"{subject} by {GROUP_NAMES[res['group']]} for {label}:"]
        for name, value, pct in res["rows"]:
            lines.append(f"- {name}: {_money(value)}" + (f" ({pct:.1f}%)" if pct is not None else ""))
        if res["base"]:
            lines.append(f"Percentages are shares of the {res['base'][0]} ({_money(res['base'][1])}).")
        return "\n".join(lines)
    total = res["total"]
    if res["count"]:
        return f"{subject} for {label}: {int(total)}."
    text = f"{subject} for {label}: {_money(total)}."
    if res["base"]:
        name, base = res["base"]
        if res["percent"] is None:
            text += f" The {name} is {_money(base)}, so a percentage cannot be calculated."
        else:
            text += (f" That is {res['percent']:.1f}% of the {name} ({_money(base)}): "
                     f"{_num(total)} \u00f7 {_num(base)} \u00d7 100 = {res['percent']:.1f}%.")
    return text