from datetime import date, timedelta

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, aliased

from app.models.models import Allowance, Category, Expense, Income, User


def _f(v) -> float:
    return float(v or 0)


def period_kpis(db: Session, fam: int, start: date, end: date, member_id: int | None = None) -> dict:
    """Same formulas as the dashboard KPI cards."""

    def income_sum(kind: str) -> float:
        q = select(func.coalesce(func.sum(Income.amount), 0)).where(
            Income.family_id == fam, Income.kind == kind,
            Income.income_date >= start, Income.income_date <= end)
        if member_id is not None:
            q = q.where(Income.user_id == member_id)
        return _f(db.scalar(q))

    income, budget, savings = income_sum("income"), income_sum("family_share"), income_sum("savings")

    al_date = func.date(Allowance.created_at)
    q = select(func.coalesce(func.sum(Allowance.amount), 0)).where(
        Allowance.family_id == fam, al_date >= start, al_date <= end)
    if member_id is not None:
        q = q.where(Allowance.user_id == member_id)
    allowance = _f(db.scalar(q))

    q = select(func.coalesce(func.sum(Expense.amount), 0)).where(
        Expense.family_id == fam, Expense.place != "allowance",
        Expense.expense_date >= start, Expense.expense_date <= end)
    if member_id is not None:
        q = q.where(Expense.user_id == member_id)
    other = _f(db.scalar(q))

    expenses = other + allowance
    balance = budget - expenses

    allowance_remaining = 0.0

    if start.month == 1 and end.month == 12:
        month = start
        while month <= end:
            month_key = month.strftime("%Y-%m")

            given = _f(db.scalar(
                select(func.coalesce(func.sum(Allowance.amount), 0)).where(
                    Allowance.family_id == fam,
                    Allowance.period == month_key,
                    *([Allowance.user_id == member_id] if member_id is not None else [])
                )
            ))

            next_month = (month.replace(day=28) + timedelta(days=4)).replace(day=1)

            spent = _f(db.scalar(
                select(func.coalesce(func.sum(Expense.amount), 0)).where(
                    Expense.family_id == fam,
                    Expense.place == "allowance",
                    Expense.expense_date >= month,
                    Expense.expense_date < next_month,
                    *([Expense.user_id == member_id] if member_id is not None else [])
                )
            ))

            allowance_remaining += given - spent
            month = next_month

    print("AI YEARLY DEBUG")
    print("income =", income)
    print("budget =", budget)
    print("expenses =", expenses)
    print("balance =", balance)
    print("allowance_remaining =", allowance_remaining)
    print("unspent =", balance + allowance_remaining)

    return {
        "income": income, "budget": budget, "allowance": allowance, "expenses": expenses,
        "balance": balance,
        "savings": savings,
        "unspent": (
            income - budget - savings
            if not (start.month == 1 and end.month == 12)
            else balance + allowance_remaining
        ),
    }


def top_categories(db: Session, fam: int, start: date, end: date, member_id: int | None = None,
                   limit: int = 3) -> list[tuple[str, float]]:
    conds = [Expense.family_id == fam, Expense.from_allowance.is_(False),
             Expense.expense_date >= start, Expense.expense_date <= end]
    if member_id is not None:
        conds.append(Expense.user_id == member_id)
    total = func.sum(Expense.amount)
    rows = [
        (name, _f(t)) for name, t in db.execute(
            select(Category.name, total).select_from(Expense)
            .join(Category, Category.id == Expense.category_id)
            .where(*conds).group_by(Category.name)
        ).all()
    ]
    allowance = period_kpis(db, fam, start, end, member_id)["allowance"]
    if allowance > 0:
        rows.append(("Allowance", allowance))
    rows.sort(key=lambda r: r[1], reverse=True)
    return rows[:limit]


def _best(rows, text_of, words):
    scored = [(sum(1 for w in words if w in text_of(r).lower()), r) for r in rows]
    top = max((s for s, _ in scored), default=0)
    return [r for s, r in scored if s == top and s > 0]


def find_records(db: Session, fam: int, words: list[str], start: date, end: date,
                 member_id: int | None, want: set[str]) -> dict:
    """Exact records that match the words of the question."""
    pats = [f"%{w}%" for w in words]
    out: dict = {}

    if "expenses" in want:
        ForUser = aliased(User)
        q = (
            select(Expense, User.full_name, Category.name, ForUser.full_name)
            .join(User, User.id == Expense.user_id)
            .join(Category, Category.id == Expense.category_id)
            .outerjoin(ForUser, ForUser.id == Expense.for_user_id)
            .where(Expense.family_id == fam, Expense.expense_date >= start, Expense.expense_date <= end,
                   or_(*[or_(Expense.purpose.ilike(p), Category.name.ilike(p)) for p in pats]))
            .order_by(Expense.expense_date.desc(), Expense.id.desc()).limit(200)
        )
        if member_id is not None:
            q = q.where(Expense.user_id == member_id)
        best = _best(db.execute(q).all(), lambda r: f"{r[0].purpose} {r[2]}", words)
        if best:
            out["expenses"] = best

    if "income" in want:
        q = (
            select(Income, User.full_name).outerjoin(User, User.id == Income.user_id)
            .where(Income.family_id == fam, Income.income_date >= start, Income.income_date <= end,
                   or_(*[or_(Income.description.ilike(p), Income.income_type.ilike(p)) for p in pats]))
            .order_by(Income.income_date.desc(), Income.id.desc()).limit(200)
        )
        if member_id is not None:
            q = q.where(Income.user_id == member_id)
        best = _best(db.execute(q).all(), lambda r: f"{r[0].description or ''} {r[0].income_type}", words)
        if best:
            out["income"] = best

    if "allowance" in want:
        al_date = func.date(Allowance.created_at)
        q = (
            select(Allowance, User.full_name).join(User, User.id == Allowance.user_id)
            .where(Allowance.family_id == fam, al_date >= start, al_date <= end,
                   or_(*[Allowance.note.ilike(p) for p in pats]))
            .order_by(Allowance.id.desc()).limit(200)
        )
        if member_id is not None:
            q = q.where(Allowance.user_id == member_id)
        best = _best(db.execute(q).all(), lambda r: r[0].note or "", words)
        if best:
            out["allowance"] = best

    return out

def category_totals(db: Session, fam: int, start: date, end: date,
                    member_id: int | None = None) -> list[tuple[str, float]]:
    """All expense records grouped by category (same data as the Expenses by category chart)."""
    conds = [Expense.family_id == fam, Expense.expense_date >= start, Expense.expense_date <= end]
    if member_id is not None:
        conds.append(Expense.user_id == member_id)
    total = func.sum(Expense.amount)
    rows = [
        (name, _f(t)) for name, t in db.execute(
            select(Category.name, total).select_from(Expense)
            .join(Category, Category.id == Expense.category_id)
            .where(*conds).group_by(Category.name)
        ).all()
    ]
    return sorted(rows, key=lambda r: -r[1])


def extreme_expense(db: Session, fam: int, start: date, end: date, member_id: int | None, highest: bool = True):
    """The biggest (or smallest) single expense record: (Expense, who) or None."""
    q = (
        select(Expense, User.full_name).join(User, User.id == Expense.user_id)
        .where(Expense.family_id == fam, Expense.expense_date >= start, Expense.expense_date <= end)
    )
    if member_id is not None:
        q = q.where(Expense.user_id == member_id)
    q = q.order_by(Expense.amount.desc() if highest else Expense.amount.asc(), Expense.id.desc()).limit(1)
    return db.execute(q).first()