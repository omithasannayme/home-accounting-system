import re

NUM_RE = re.compile(r"\d[\d,]*(?:\.\d+)?")


def to_number(token: str) -> float | None:
    try:
        return round(float(token.replace(",", "").rstrip(".")), 2)
    except ValueError:
        return None


def allowed_numbers(*texts: str) -> set[float]:
    """Every number that really exists in the facts or in the question."""
    out: set[float] = set()
    for t in texts:
        for m in NUM_RE.finditer(t):
            n = to_number(m.group())
            if n is not None:
                out.add(n)
    return out


def bad_numbers(text: str, allowed: set[float]) -> list[str]:
    """Numbers in the AI text that are NOT in the real data."""
    bad = []
    for m in NUM_RE.finditer(text):
        n = to_number(m.group())
        if n is None or n not in allowed:
            bad.append(m.group())
    return bad