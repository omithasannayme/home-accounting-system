from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session, aliased

from app.ai import figures
from app.ai.intent import ALL_END, ALL_START, _month_end, tk
from app.models.models import (
    ROLE_ADMIN, ROLE_MEMBER, Allowance, Category, Expense, Family, Income, User,
)
from app.services.finance_service import allowance_status


def _kpi_line(title: str, k: dict) -> str:
    return (
        f"{title}: income {tk(k['income'])}; budget (family share) {tk(k['budget'])}; "
        f"allowance given {tk(k['allowance'])}; expenses (allowance included) {tk(k['expenses'])}; "
        f"balance {tk(k['balance'])}; savings {tk(k['savings'])}; "
        f"liquid funds available {tk(k['unspent'])}."
    )


def build_facts(db: Session, user: User, words: list[str]) -> str:
    """Exact facts of the user's own family, written as plain text for the model."""
    fam = user.family_id
    today = date.today()
    ms = today.replace(day=1)
    me = _month_end(ms)
    ps = (ms - timedelta(days=1)).replace(day=1)
    pe = _month_end(ps)
    ys, ye = date(today.year, 1, 1), date(today.year, 12, 31)

    family = db.get(Family, fam)
    people = list(db.scalars(
        select(User).where(User.family_id == fam, User.is_active.is_(True)).order_by(User.id)).all())

    lines = [
        f"Family: {family.name if family else ''}",
        f"Today: {today.isoformat()}",
        f"Person asking: {user.full_name}",
        "Members: " + "; ".join(
            f"{u.full_name} ({u.relation or 'family member'}, {'admin' if u.role == ROLE_ADMIN else 'member'})"
            for u in people),
    ]

    for title, s, e in (
        (f"This month ({ms:%B %Y})", ms, me),
        (f"Last month ({ps:%B %Y})", ps, pe),
        (f"This year ({today.year})", ys, ye),
    ):
        k = figures.period_kpis(db, fam, s, e)
        lines.append(_kpi_line(title, k))
        cats = figures.top_categories(db, fam, s, e, 5)
        if cats:
            lines.append(f"Top spending, {title}: " + "; ".join(f"{n} {tk(a)}" for n, a in cats))
        if title.startswith("This month") and k["budget"] > 0:
            lines.append(f"Expenses are {k['expenses'] / k['budget'] * 100:.1f}% of the budget this month.")

    cats_all = [c for c in figures.category_totals(db, fam, ms, me) if c[1] > 0]
    if cats_all:
        lines.append(f"Highest spending category this month: {cats_all[0][0]}, {tk(cats_all[0][1])}.")
        lines.append(f"Lowest spending category this month: {cats_all[-1][0]}, {tk(cats_all[-1][1])}.")
    top = figures.extreme_expense(db, fam, ms, me, None, True)
    if top:
        lines.append(f"Highest single expense this month: {top[0].purpose}, {tk(top[0].amount)}, on {top[0].expense_date}.")

    month = ms.strftime("%Y-%m")
    for u in people:
        k = figures.period_kpis(db, fam, ms, me, u.id)
        lines.append(
            f"{u.full_name}, this month: income {tk(k['income'])}; family share {tk(k['budget'])}; "
            f"expenses (allowance included) {tk(k['expenses'])}; savings {tk(k['savings'])}.")
        if u.role == ROLE_MEMBER:
            st = allowance_status(db, fam, u.id, month)
            lines.append(
                f"{u.full_name} allowance this month: given {tk(st['given'])}; spent {tk(st['spent'])}; "
                f"remaining {tk(st['remaining'])}; {st['percent_used']:.1f}% used.")

    ForUser = aliased(User)
    for e, who, cat, fn in db.execute(
        select(Expense, User.full_name, Category.name, ForUser.full_name)
        .join(User, User.id == Expense.user_id)
        .join(Category, Category.id == Expense.category_id)
        .outerjoin(ForUser, ForUser.id == Expense.for_user_id)
        .where(Expense.family_id == fam)
        .order_by(Expense.expense_date.desc(), Expense.id.desc()).limit(8)
    ).all():
        lines.append(f"Recent expense {e.expense_date}: {who} paid {tk(e.amount)} for {e.purpose} "
                     f"({cat}), for {fn or 'Family'}, source {e.source}.")
    for i, name in db.execute(
        select(Income, User.full_name).outerjoin(User, User.id == Income.user_id)
        .where(Income.family_id == fam)
        .order_by(Income.income_date.desc(), Income.id.desc()).limit(8)
    ).all():
        lines.append(f"Recent {i.kind.replace('_', ' ')} {i.income_date}: {name or 'Family'}, "
                     f"{i.income_type}, {tk(i.amount)}.")
    for a, name in db.execute(
        select(Allowance, User.full_name).join(User, User.id == Allowance.user_id)
        .where(Allowance.family_id == fam).order_by(Allowance.id.desc()).limit(8)
    ).all():
        lines.append(f"Recent allowance {a.created_at.date()}: {name} received {tk(a.amount)} for {a.period}.")

    if words:
        found = figures.find_records(db, fam, words, ALL_START, ALL_END, None, {"expenses", "income", "allowance"})
        for e, who, cat, fn in found.get("expenses", [])[:10]:
            lines.append(f"Matching expense {e.expense_date}: {who} paid {tk(e.amount)} for {e.purpose} ({cat}).")
        for i, name in found.get("income", [])[:10]:
            lines.append(f"Matching income {i.income_date}: {name or 'Family'}, {i.income_type}, {tk(i.amount)}.")
        for a, name in found.get("allowance", [])[:10]:
            lines.append(f"Matching allowance {a.created_at.date()}: {name}, {tk(a.amount)}.")
        if not found:
            lines.append(f"No record matches: {', '.join(words)}.")
    return "\n".join(lines)