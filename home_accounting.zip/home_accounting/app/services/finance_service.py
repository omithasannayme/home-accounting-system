from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.models import Allowance, Category, Expense, Income


def current_month() -> str:
    return date.today().strftime("%Y-%m")


def previous_month(month: str) -> str:
    y, m = int(month[:4]), int(month[5:7])
    return f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"


def month_bounds(month: str) -> tuple[date, date]:
    y, m = int(month[:4]), int(month[5:7])
    start = date(y, m, 1)
    end = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
    return start, end


def _dec(value) -> Decimal:
    return Decimal(str(value or 0))


def total_expense(db: Session, family_id: int, start: date, end: date, user_id=None,
                  category_id=None, from_allowance=None) -> Decimal:
    q = select(func.coalesce(func.sum(Expense.amount), 0)).where(
        Expense.family_id == family_id, Expense.expense_date >= start, Expense.expense_date < end
    )
    if user_id is not None:
        q = q.where(Expense.user_id == user_id)
    if category_id is not None:
        q = q.where(Expense.category_id == category_id)
    if from_allowance is not None:
        q = q.where(Expense.from_allowance == from_allowance)
    return _dec(db.scalar(q))


def expense_by_category(db: Session, family_id: int, start: date, end: date, user_id=None,
                        from_allowance=None) -> list[tuple[str, Decimal]]:
    total = func.sum(Expense.amount)
    q = (
        select(Category.name, total)
        .join(Category, Category.id == Expense.category_id)
        .where(Expense.family_id == family_id, Expense.expense_date >= start, Expense.expense_date < end)
        .group_by(Category.name)
        .order_by(total.desc())
    )
    if user_id is not None:
        q = q.where(Expense.user_id == user_id)
    if from_allowance is not None:
        q = q.where(Expense.from_allowance == from_allowance)
    return [(name, _dec(t)) for name, t in db.execute(q).all()]


def total_income(db: Session, family_id: int, start: date, end: date, user_id=None) -> Decimal:
    q = select(func.coalesce(func.sum(Income.amount), 0)).where(
        Income.family_id == family_id, Income.income_date >= start, Income.income_date < end,
        Income.kind == "income",
    )
    if user_id is not None:
        q = q.where(Income.user_id == user_id)
    return _dec(db.scalar(q))


def income_by_type(db: Session, family_id: int, start: date, end: date, user_id=None) -> list[tuple[str, Decimal]]:
    total = func.sum(Income.amount)
    q = (
        select(Income.income_type, total)
        .where(Income.family_id == family_id, Income.income_date >= start, Income.income_date < end,
               Income.kind == "income")
        .group_by(Income.income_type)
        .order_by(total.desc())
    )
    if user_id is not None:
        q = q.where(Income.user_id == user_id)
    return [(name, _dec(t)) for name, t in db.execute(q).all()]


def allowance_status(db: Session, family_id: int, user_id: int, month: str) -> dict:
    given = _dec(db.scalar(
        select(func.coalesce(func.sum(Allowance.amount), 0)).where(
            Allowance.family_id == family_id, Allowance.user_id == user_id, Allowance.period == month
        )
    ))
    start, end = month_bounds(month)
    spent = _dec(db.scalar(
        select(func.coalesce(func.sum(Expense.amount), 0)).where(
            Expense.family_id == family_id,
            Expense.user_id == user_id,
            Expense.expense_date >= start,
            Expense.expense_date < end,
            Expense.place == "allowance",
        )
    ))
    percent = float(spent / given * 100) if given > 0 else 0.0
    return {"given": given, "spent": spent, "remaining": given - spent, "percent_used": round(percent, 1)}