"use strict";

const $ = (s, r = document) => r.querySelector(s);
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
const money = (v) => Number(v || 0).toLocaleString("en-US", {maximumFractionDigits: 0}) + " Tk";
const today = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
const thisMonth = () => today().slice(0, 7);

const RELATIONS = ["father", "mother", "brother", "sister", "daughter", "son", "child", "other"];
const TYPES = {salary: "Salary", business: "Business income", personal: "Personal income", family_member: "Income from family member"};

const S = {
  access: sessionStorage.getItem("at"), refresh: sessionStorage.getItem("rt"),
  me: null, view: "dashboard", month: thisMonth(), scope: "personal",
  categories: [], members: [], isSuper: false, isAdmin: false, canFamily: false, canIncome: false,
};

/* ---------- api ---------- */
function setTokens(t) {
  S.access = t.access_token; S.refresh = t.refresh_token;
  sessionStorage.setItem("at", S.access); sessionStorage.setItem("rt", S.refresh);
}

async function refreshTokens() {
  try {
    const r = await fetch("/api/v1/auth/refresh", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({refresh_token: S.refresh}),
    });
    if (!r.ok) return false;
    setTokens(await r.json());
    return true;
  } catch { return false; }
}

async function api(path, method = "GET", body, retry = true) {
  const headers = {"Content-Type": "application/json"};
  if (S.access) headers.Authorization = "Bearer " + S.access;
  const res = await fetch("/api/v1" + path, {method, headers, body: body ? JSON.stringify(body) : undefined});
  if (res.status === 401 && retry && S.refresh && !path.startsWith("/auth/")) {
    if (await refreshTokens()) return api(path, method, body, false);
    logout();
    throw new Error("Session expired. Please sign in again.");
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const d = data && data.detail;
    throw new Error(typeof d === "string" ? d : Array.isArray(d) ? d.map((x) => x.msg).join(", ") : "Request failed");
  }
  return data;
}

function showAuth() { $("#app").classList.add("hidden"); $("#auth").classList.remove("hidden"); }
function logout() {

  sessionStorage.clear();

  S.access = S.refresh = S.me = null;


  const form = document.getElementById("loginForm");

  if(form){

    const email =
      form.querySelector('input[name="email"]');

    const password =
      form.querySelector('input[name="password"]');


    if(password)
      password.value="";


    const remember =
      document.getElementById("rememberMe");


    if(remember && !remember.checked && email)
      email.value="";

  }


  showAuth();
}

/* ---------- app shell ---------- */
async function startApp() {
  const me = S.me, p = me.permissions || {};
  S.isSuper = me.role === "super_admin";
  S.isAdmin = me.role === "family_admin";
  S.canFamily = !S.isSuper;
  S.canIncome = S.isAdmin;
  S.scope = "family";
  S.incView = "family";
  S.month = thisMonth();
  resetDash("month");
  S.hidden = new Set();
  S.pieHidden = new Set();
  $("#auth").classList.add("hidden");
  $("#app").classList.remove("hidden");
  $("#authMsg").textContent = "";
  $("#famName").textContent = S.isSuper ? "Platform Console" : (me.family_name || "Home Accounting");
  $("#ai").classList.toggle("hidden", S.isSuper);
  $("#aiToggle").classList.toggle("hidden", S.isSuper);
  $("#chat").innerHTML = "";
  if (!S.isSuper) {
    S.categories = await api("/categories");
    if (S.isAdmin) S.members = await api("/members");
    addMsg("bot", "Hi " + me.full_name.split(" ")[0] + "! I'm your finance assistant. Ask me about your spending.");
  }
  const items = S.isSuper ? [["platform", "Families"]] : [
  ["dashboard", "Dashboard"],
  ["expenses", "Expenses"],
  ["income", "Income"],
  ["allowance", "Allowance"],
  ["members", "Members"],
];

const navIcons = {
  dashboard: svg(
    '<path d="M3 12h7V3H3z"/><path d="M14 21h7V12h-7z"/><path d="M14 3h7v5h-7z"/><path d="M3 16h7v5H3z"/>',
    17
  ),
  expenses: ICON.expense,
  income: ICON.income,
  allowance: ICON.allowance,
  members: ICON.family,
  platform: ICON.family,
};

$("#nav").innerHTML = ""
  + "<div class=\"side-brand\">"
  + "<div class=\"side-logo\">"
  + "<svg viewBox=\"0 0 64 64\" aria-hidden=\"true\">"
  + "<defs><linearGradient id=\"sideHome\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\">"
  + "<stop offset=\"0%\" stop-color=\"#0a84ff\"/>"
  + "<stop offset=\"55%\" stop-color=\"#6c5ce7\"/>"
  + "<stop offset=\"100%\" stop-color=\"#ff4da6\"/>"
  + "</linearGradient></defs>"
  + "<path d=\"M12 30.5 32 13l20 17.5v20A5.5 5.5 0 0 1 46.5 56h-29A5.5 5.5 0 0 1 12 50.5z\" fill=\"url(#sideHome)\"/>"
  + "<path d=\"M25 46V35h5v11zm9 0V29h5v17zm9 0V38h5v8z\" fill=\"#fff\"/>"
  + "</svg></div><b>Home Accounting</b></div>"
  + "<div class=\"nav-menu\">"
  + items.map(function (pair) {
      return "<button data-view=\"" + pair[0] + "\"><span class=\"nav-ico\">"
        + (navIcons[pair[0]] || "")
        + "</span><span>" + pair[1] + "</span></button>";
    }).join("")
  + "</div><div class=\"sp\"></div>"
  + "<div class=\"who\"><span class=\"who-dot\">"
  + esc((me.full_name || "U").slice(0, 1))
  + "</span><span>"
  + esc((me.full_name || "").split(" ")[0])
  + "</span></div>"
  + "<button data-act=\"logout\" class=\"nav-logout\"><span class=\"nav-ico\">"
  + svg("<path d=\"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4\"/><polyline points=\"16 17 21 12 16 7\"/><line x1=\"21\" y1=\"12\" x2=\"9\" y2=\"12\"/>", 17)
  + "</span><span>Sign out</span></button>";

  go(S.isSuper ? "platform" : "dashboard");
}

async function go(view) {
  S.view = view;
  document.querySelectorAll("#nav [data-view]").forEach((b) => b.classList.toggle("on", b.dataset.view === view));
  $("#main").innerHTML = '<p class="mute">Loading...</p>';
  try {
    $("#main").innerHTML = await VIEWS[view]();
    if (view === "dashboard") drawDashboard();
  } catch (e) {
    $("#main").innerHTML = `<p class="err">${esc(e.message)}</p>`;
  }
}
/* ---------- view helpers ---------- */
const head = (title, ctl = "") => `<div class="head"><h2>${title}</h2><div class="ctl">${ctl}</div></div>`;
const ctlMonth = () => `<input type="month" id="month" value="${S.month}">`;
const ctlScope = () => S.canFamily
  ? `<select id="scope"><option value="personal"${S.scope === "personal" ? " selected" : ""}>Personal</option><option value="family"${S.scope === "family" ? " selected" : ""}>Family</option></select>` : "";
const table = (heads, rows) => rows.length
  ? `<div class="scroll"><table><thead><tr>${heads.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`
  : '<p class="mute">Nothing here yet.</p>';
const pickScope = () => (S.canFamily ? S.scope : "personal");

/* ---------- views ---------- */
/* ---------- dashboard ---------- */
const COLORS = {income: "#0a84ff", budget: "#af52de", expenses: "#ff453a", savings: "#30d158", balance: "#ff9f0a", allowance: "#64d2ff"};
const PALETTE = ["#0a84ff", "#30d158", "#ff9f0a", "#af52de", "#ff453a", "#64d2ff", "#ffd60a", "#ac8e68"];
const SERIES = [
  {key: "income", name: "Income", color: COLORS.income},
  {key: "budget", name: "Budget", color: COLORS.budget},
  {key: "expenses", name: "Expenses", color: COLORS.expenses},
  {key: "savings", name: "Savings", color: COLORS.savings},
];
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const pad2 = (n) => String(n).padStart(2, "0");
const isoDate = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const monthRange = () => { const n = new Date(); return [isoDate(new Date(n.getFullYear(), n.getMonth(), 1)), isoDate(new Date(n.getFullYear(), n.getMonth() + 1, 0))]; };
const yearRange = () => { const y = new Date().getFullYear(); return [`${y}-01-01`, `${y}-12-31`]; };
const fmtDate = (s) => new Date(s + "T00:00:00").toLocaleDateString("en-GB", {day: "numeric", month: "short", year: "numeric"});
const short = (v) => { const a = Math.abs(v), f = (x) => String(+x.toFixed(1)); return a >= 1e6 ? f(v / 1e6) + "M" : a >= 1e3 ? f(v / 1e3) + "k" : f(v); };

function resetDash(kind) {
  [S.dFrom, S.dTo] = kind === "year" ? yearRange() : monthRange();
  S.dGroup = kind === "year" ? "month" : "day";
}

function niceScale(max) {
  if (!(max > 0)) return {max: 100, step: 25};
  const raw = max / 4, pow = Math.pow(10, Math.floor(Math.log10(raw))), n = raw / pow;
  const step = (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * pow;
  return {max: Math.ceil(max / step) * step, step};
}

function fmtLabel(l, g, full) {
  if (g === "year") return l;
  if (g === "month") return MON[+l.slice(5, 7) - 1] + (full ? " " + l.slice(0, 4) : "'" + l.slice(2, 4));
  return +l.slice(8) + " " + MON[+l.slice(5, 7) - 1] + (full ? " " + l.slice(0, 4) : "");
}

function gridSvg(W, m, y, sc) {
  let g = "";
  const ticks = Math.round(sc.max / sc.step);
  for (let t = 0; t <= ticks; t++) {
    const v = t * sc.step, yy = y(v).toFixed(1);
    g += `<line x1="${m.l}" x2="${W - m.r}" y1="${yy}" y2="${yy}" class="gl"/><text x="${m.l - 6}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" class="ax">${short(v)}</text>`;
  }
  return g;
}

function arc(cx, cy, R, r, a0, a1) {
  const p = (rad, a) => [(cx + rad * Math.cos(a)).toFixed(2), (cy + rad * Math.sin(a)).toFixed(2)];
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const [x0, y0] = p(R, a0), [x1, y1] = p(R, a1), [x2, y2] = p(r, a1), [x3, y3] = p(r, a0);
  return `M${x0} ${y0} A${R} ${R} 0 ${large} 1 ${x1} ${y1} L${x2} ${y2} A${r} ${r} 0 ${large} 0 ${x3} ${y3} Z`;
}

function tip(el, html, e) {
  let t = el.querySelector(".ch-tip");
  if (!t) { t = document.createElement("div"); t.className = "ch-tip"; el.appendChild(t); }
  t.innerHTML = html;
  t.style.display = "block";
  const r = el.getBoundingClientRect();
  let x = e.clientX - r.left + 14, y = e.clientY - r.top + 14;
  if (x + t.offsetWidth > r.width - 4) x = e.clientX - r.left - t.offsetWidth - 14;
  if (y + t.offsetHeight > r.height - 4) y = e.clientY - r.top - t.offsetHeight - 14;
  t.style.left = Math.max(4, x) + "px";
  t.style.top = Math.max(4, y) + "px";
}
function hideTip(el) { const t = el.querySelector(".ch-tip"); if (t) t.style.display = "none"; }

function drawLine(el, d, hidden) {
  const W = Math.max(280, el.clientWidth), H = 250;
  const m = {l: 42, r: 12, t: 10, b: 26};
  const iw = W - m.l - m.r, ih = H - m.t - m.b, n = d.labels.length;
  const vis = d.series.filter((s) => !hidden.has(s.key));
  const sc = niceScale(Math.max(0, ...vis.flatMap((s) => s.values)));
  const x = (i) => m.l + (n === 1 ? iw / 2 : (i * iw) / (n - 1));
  const y = (v) => m.t + ih - (v / sc.max) * ih;
  const every = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(iw / 70))));
  let xl = "";
  d.labels.forEach((l, i) => {
    if (i % every === 0) xl += `<text x="${x(i).toFixed(1)}" y="${H - 8}" text-anchor="middle" class="ax">${esc(fmtLabel(l, d.group))}</text>`;
  });
  const lines = vis.map((s) => {
    const pts = s.values.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
    const dots = n <= 40 ? s.values.map((v, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(v).toFixed(1)}" r="2.5" fill="${s.color}"/>`).join("") : "";
    return `<polyline points="${pts}" fill="none" stroke="${s.color}" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>${dots}`;
  }).join("");
  const cds = vis.map((s) => `<circle class="cd" data-k="${s.key}" r="4.5" fill="${s.color}" style="display:none;stroke:var(--card);stroke-width:2"/>`).join("");
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${gridSvg(W, m, y, sc)}${xl}${lines}<line class="cl" y1="${m.t}" y2="${m.t + ih}" style="display:none"/>${cds}</svg>`;

  const svg = el.querySelector("svg"), cl = el.querySelector(".cl"), dotEls = el.querySelectorAll(".cd");
  el.onmousemove = (e) => {
    const r = svg.getBoundingClientRect();
    const mx = (e.clientX - r.left) * (W / r.width);
    const i = Math.max(0, Math.min(n - 1, n === 1 ? 0 : Math.round(((mx - m.l) / iw) * (n - 1))));
    cl.setAttribute("x1", x(i)); cl.setAttribute("x2", x(i)); cl.style.display = "";
    dotEls.forEach((c) => {
      const s = vis.find((q) => q.key === c.dataset.k);
      c.setAttribute("cx", x(i)); c.setAttribute("cy", y(s.values[i])); c.style.display = "";
    });
    tip(el, `<b>${esc(fmtLabel(d.labels[i], d.group, true))}</b>` + vis.map((s) => `<div><span><i style="background:${s.color}"></i>${s.name}</span><span>${money(s.values[i])}</span></div>`).join(""), e);
  };
  el.onmouseleave = () => { cl.style.display = "none"; dotEls.forEach((c) => { c.style.display = "none"; }); hideTip(el); };
}

function drawBars(el, items, emptyMsg) {
  if (!items.length) { el.onmousemove = el.onmouseleave = null; el.innerHTML = `<div class="inc-empty">${emptyMsg}</div>`; return; }
  const W = Math.max(280, el.clientWidth), H = 260, n = items.length;
  const rot = (W - 52) / n < 62;
  const m = {l: 42, r: 10, t: 14, b: rot ? 62 : 28};
  const iw = W - m.l - m.r, ih = H - m.t - m.b, slot = iw / n, bw = Math.min(48, slot * 0.62);
  const total = items.reduce((a, b) => a + b.amount, 0);
  const sc = niceScale(Math.max(...items.map((i) => i.amount)));
  const y = (v) => m.t + ih - (v / sc.max) * ih;
  const bars = items.map((it, i) => {
    const cx = m.l + slot * i + slot / 2, top = y(it.amount), ly = H - m.b + 16;
    const name = it.name.length > 12 ? it.name.slice(0, 11) + "\u2026" : it.name;
    const lab = rot
      ? `<text x="${cx.toFixed(1)}" y="${ly}" text-anchor="end" transform="rotate(-35 ${cx.toFixed(1)} ${ly})" class="ax">${esc(name)}</text>`
      : `<text x="${cx.toFixed(1)}" y="${ly}" text-anchor="middle" class="ax">${esc(name)}</text>`;
    const val = !rot && slot >= 44 ? `<text x="${cx.toFixed(1)}" y="${(top - 5).toFixed(1)}" class="bv">${short(it.amount)}</text>` : "";
    return `<rect class="brr" x="${(cx - bw / 2).toFixed(1)}" y="${top.toFixed(1)}" width="${bw.toFixed(1)}" height="${Math.max(0, m.t + ih - top).toFixed(1)}" rx="6" fill="${PALETTE[i % PALETTE.length]}"/>${val}${lab}`;
  }).join("");
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${gridSvg(W, m, y, sc)}${bars}</svg>`;

  const svg = el.querySelector("svg"), rects = el.querySelectorAll(".brr");
  el.onmousemove = (e) => {
    const r = svg.getBoundingClientRect();
    const i = Math.floor(((e.clientX - r.left) * (W / r.width) - m.l) / slot);
    if (i < 0 || i >= n) { rects.forEach((b) => { b.style.opacity = ""; }); hideTip(el); return; }
    rects.forEach((b, j) => { b.style.opacity = j === i ? "1" : "0.45"; });
    const it = items[i];
    tip(el, `<b>${esc(it.name)}</b><div><span>${money(it.amount)}</span><span>${total ? (it.amount / total * 100).toFixed(1) : 0}%</span></div>`, e);
  };
  el.onmouseleave = () => { rects.forEach((b) => { b.style.opacity = ""; }); hideTip(el); };
}

function pieItems() {
  const k = S.dash.kpi;
  return [
    {key: "budget", name: "Budget", value: Math.max(0, k.budget), color: COLORS.budget},
    {key: "savings", name: "Savings", value: Math.max(0, k.savings), color: COLORS.savings},
    {key: "unspent", name: "Liquid funds", short: "Liquid funds", value: Math.max(0, k.unspent), color: "#5e5ce6"},
  ];
}

function budgetPieItems() {
  const d = S.dash;
  const items = d.budget_usage.map((c, i) => ({key: "c" + i, name: c.name, value: c.amount, color: PALETTE[i % PALETTE.length]}));
  if (d.kpi.balance > 0) items.push({key: "bal", name: "Balance", value: d.kpi.balance, color: "#8e8e93"});
  return items;
}

function donut(el, o) {
  const items = o.all.filter((s) => !o.hidden.has(s.key) && s.value > 0);
  const visible = items.reduce((a, s) => a + s.value, 0);
  const angleBase = o.fill ? visible : o.base;
  const pctOf = (v) => (angleBase ? v / angleBase * 100 : 0);
  const sz = o.size || 220, c = sz / 2, R = sz * 0.45, r = sz * 0.28, rm = (R + r) / 2;
  let paths = "", labels = "", a = -Math.PI / 2;
  items.forEach((s, i) => {
    const frac = s.value / angleBase, a1 = a + frac * 2 * Math.PI;
    paths += `<path class="sl" data-i="${i}" style="transform-origin:${c}px ${c}px" d="${arc(c, c, R, r, a, Math.min(a1, a + 2 * Math.PI - 0.0001))}" fill="${s.color}"/>`;
    if (frac >= 0.06) {
      const am = (a + a1) / 2;
      labels += `<text class="sp" x="${(c + rm * Math.cos(am)).toFixed(1)}" y="${(c + rm * Math.sin(am)).toFixed(1)}">${Math.round(pctOf(s.value))}%</text>`;
    }
    a = a1;
  });
  if (!paths) paths = `<circle cx="${c}" cy="${c}" r="${rm}" fill="none" style="stroke:var(--line)" stroke-width="${R - r}"/>`;
  const legend = o.all.map((s) => `<li><button type="button" class="lg${o.hidden.has(s.key) ? " off" : ""}" data-act="${o.act}" data-k="${s.key}"><i style="background:${s.color}"></i>${esc(s.name)}</button></li>`).join("");
  const ctr = o.base ? o.center : "No data";
  const sub = o.base ? o.sub : "";
  el.innerHTML = `<div class="pie"><svg viewBox="0 0 ${sz} ${sz}" style="width:${sz}px;max-width:100%;height:auto">${paths}${labels}<text x="${c}" y="${c}" text-anchor="middle" class="pc1">${ctr}</text><text x="${c}" y="${c + 17}" text-anchor="middle" class="pc2">${sub}</text></svg><ul class="plg">${legend}</ul></div>${o.note || ""}`;

  const pc1 = el.querySelector(".pc1"), pc2 = el.querySelector(".pc2");
  const reset = () => {
    el.querySelectorAll(".sl").forEach((q) => { q.style.opacity = ""; });
    pc1.textContent = ctr;
    pc2.textContent = sub;
    hideTip(el);
  };
  el.onmousemove = (e) => {
    const p = e.target.closest(".sl");
    if (!p) return reset();
    const s = items[+p.dataset.i];
    el.querySelectorAll(".sl").forEach((q) => { q.style.opacity = q === p ? "1" : "0.45"; });
    pc1.textContent = pctOf(s.value).toFixed(1) + "%";
    pc2.textContent = s.short || s.name;
    tip(el, `<b>${esc(s.name)}</b><div><span>${money(s.value)}</span><span>${pctOf(s.value).toFixed(1)}%</span></div>`, e);
  };
  el.onmouseleave = reset;
}

function drawPie(el, all, hidden) {
  const k = S.dash.kpi;
  const base = k.income > 0 ? k.income : all.reduce((a, s) => a + s.value, 0);
  const note = (k.unspent < 0 ? `<p class="pie-note">Expenses and savings exceed income by ${money(-k.unspent)}.</p>` : "")
  donut(el, {all, hidden, act: "pie-toggle", base, fill: true, center: money(k.income), sub: "income", note, size: 170});
}

function drawBudgetPie(el, all, hidden) {
  const k = S.dash.kpi;
  const base = Math.max(k.budget, all.reduce((a, s) => a + s.value, 0));
  const note = k.balance < 0 ? `<p class="pie-note">Expenses exceed the budget by ${money(-k.balance)}.</p>` : "";
  donut(el, {all, hidden, act: "bp-toggle", base, fill: true, center: money(k.budget), sub: "budget", note});
}
function drawTrend() {
  const d = S.dash, t = d.trend;
  drawLine($("#chTrend"), {labels: t.labels, group: d.group, series: SERIES.map((s) => ({...s, values: t[s.key]}))}, S.hidden);
}

function drawDashboard() {
  const d = S.dash;
  drawTrend();
  drawBars(
      $("#chCat"),
      d.by_category.filter((item) => Number(item.amount) > 0),
      "No expenses in this period."
  );
  drawBudgetPie($("#chBudget"), budgetPieItems(), S.catHidden);
  drawPie($("#chPie"), pieItems(), S.pieHidden);
}

async function vDashboard() {
  if (!S.canFamily) S.scope = "personal";
  const d = await api(`/reports/dashboard?from=${S.dFrom}&to=${S.dTo}&scope=${pickScope()}&group=${S.dGroup}`);
  S.dash = d;
  S.dGroup = d.group;
  S.catHidden = new Set();
  const k = d.kpi;
  const [m0, m1] = monthRange(), [y0, y1] = yearRange();
  const isMonth = S.dFrom === m0 && S.dTo === m1, isYear = S.dFrom === y0 && S.dTo === y1;
  const ctl = `<input type="date" id="dFrom" value="${S.dFrom}" aria-label="From date"><span class="mute">to</span><input type="date" id="dTo" value="${S.dTo}" aria-label="To date"><div class="seg"><button type="button" data-act="dash-month" class="${isMonth ? "on" : ""}">This month</button><button type="button" data-act="dash-year" class="${isYear ? "on" : ""}">This year</button></div>`;

  const KPI_ICONS = {
    Income: ICON.income,

    Budget: svg(
        '<circle cx="12" cy="12" r="9"/><path d="M12 7v10"/><path d="M8 10h8"/>',
        18
    ),

    Expenses: ICON.expense,

    Balance: svg(
        '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 9h10"/><path d="M7 13h6"/>',
        18
    ),

    Savings: ICON.savings,

    "Liquid funds": svg(
        '<path d="M3 7h18v10H3z"/><path d="M7 12h.01"/><path d="M17 12h.01"/><path d="M12 9v6"/>',
        18
    ),
  };
  const cards = [
    ["Income", k.income, COLORS.income, "kpi-income"],
    ["Budget", k.budget, COLORS.budget, "kpi-budget"],
    ["Expenses", k.expenses, COLORS.expenses, "kpi-expenses"],
    ["Balance", k.balance, COLORS.balance, "kpi-balance"],
    ["Savings", k.savings, COLORS.savings, "kpi-savings"],
    ["Liquid funds", k.unspent, "#5e5ce6", "kpi-liquid"],
  ].map(([label, v, col, cls]) => `
  <div class="kpi ${cls}">
      <div class="kpi-top">
            <span class="kpi-icon" style="--kpi-accent:${col}">
              ${KPI_ICONS[label]}
            </span>
            
            <div class="kl">
              ${label}
            </div>
          </div>
          
          <div class="kv${v < 0 ? " neg" : ""}">
            ${money(v)}
          </div>
         </div>
`).join("");
  const panel = (title, sub, extra, inner) => `<div class="inc-tablecard"><div class="inc-th dph"><div><b>${title}</b><small>${sub}</small></div>${extra}</div><div class="dpb">${inner}</div></div>`;
  const seg = ["day", "month", "year"].map((g, i) => `<button type="button" data-act="dash-group" data-g="${g}" class="${d.group === g ? "on" : ""}">${["Daily", "Monthly", "Yearly"][i]}</button>`).join("");
  const legend = SERIES.map((s) => `<button type="button" class="lg${S.hidden.has(s.key) ? " off" : ""}" data-act="ch-toggle" data-k="${s.key}"><i style="background:${s.color}"></i>${s.name}</button>`).join("");

  return `
<div class="head">
  <div>
    <h2>Dashboard</h2>

    <p class="inc-sub dash-subtitle">
      Overview of your household finances
    </p>
  </div>

  <div class="ctl dctl">
    ${ctl}
  </div>
</div>`

+ `
<div class="dashboard-top">

  <div class="dashboard-kpi-area">
    <div class="dashboard-kpis">
      ${cards}
    </div>
  </div>

  ${panel(
    "Income split",
    "",
    "",
    '<div id="chPie" class="ch"></div>'
  )}

</div>
`

+ `
<div class="dashboard-charts">

  ${panel(
    "Expenses by category",
    "",
    "",
    '<div id="chCat" class="ch"></div>'
  )}

  ${panel(
    "Budget usage",
    "",
    "",
    '<div id="chBudget" class="ch"></div>'
  )}

</div>
`

+ `
<div class="dashboard-trend">

  ${panel(
    "Trend",
    "",
    `<div class="seg">${seg}</div>`,
    `
      <div class="lgs">${legend}</div>
      <div id="chTrend" class="ch"></div>
    `
  )}

</div>
`;

}


const SHEETS = {
  categories: {api: "/categories", title: "Categories", add: "New category", store: "categories"},
  types: {api: "/income-types", title: "Income types", add: "New income type", store: "incomeTypes"},
  relations: {api: "/relations", title: "Relations", add: "New relation", store: "relations"},
};
const sheetApi = () => SHEETS[S.sheetKind].api;
async function reloadSheetList() { S[SHEETS[S.sheetKind].store] = await api(sheetApi()); }

function renderCatSheet() {
  let el = $("#catSheet");
  if (!el) { el = document.createElement("div"); el.id = "catSheet"; el.className = "sheet-back"; document.body.appendChild(el); }
  const cfg = SHEETS[S.sheetKind];
  const rows = S[cfg.store].map((c) => S.catEdit === c.id
    ? `<li class="cat-row"><form data-form="catrename" data-id="${c.id}" class="cat-edit"><input name="name" value="${esc(c.name)}" required maxlength="80"><button class="primary">Save</button><button type="button" class="ghost" data-act="cat-cancel">Cancel</button></form></li>`
    : `<li class="cat-row"><span>${esc(c.name)}</span><span class="inc-ra"><button type="button" class="inc-ib" title="Rename" data-act="cat-edit" data-id="${c.id}">${ICON.edit}</button><button type="button" class="inc-ib del" title="Delete" data-act="cat-del" data-id="${c.id}">${ICON.del}</button></span></li>`).join("");
  el.innerHTML = `<div class="sheet" role="dialog"><div class="sheet-h"><b>${cfg.title}</b><button type="button" class="ghost" data-act="cat-close">Done</button></div><ul class="cat-list">${rows}</ul><form data-form="category" class="cat-add"><input name="name" placeholder="${cfg.add}" required maxlength="80"><button class="primary">Add</button></form></div>`;
  const inp = el.querySelector(".cat-edit input");
  if (inp) { inp.focus(); inp.select(); }
}

function closeCatSheet() {
  const el = $("#catSheet");
  if (el) el.remove();
  S.catEdit = null;
  go(S.view);
}

async function vExpenses() {
  const me = S.me;
  const people = S.canFamily ? await api("/people") : [];
  const rows = await api(`/expenses?month=${S.month}&scope=${pickScope()}`);
  S.expRows = rows;

  const scopeSel = S.canFamily
    ? `<select id="scope"><option value="family"${S.scope === "family" ? " selected" : ""}>Family</option><option value="personal"${S.scope === "personal" ? " selected" : ""}>Personal</option></select>` : "";

  const cats = S.categories.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("");
  const manage = S.isAdmin ? ' <button type="button" class="lnk" data-act="cat-manage">Manage</button>' : "";
  const mine = [{id: me.id, name: me.full_name}];
  const whoOpts = (S.isAdmin ? people : mine).map((p) => `<option value="${p.id}"${p.id === me.id ? " selected" : ""}>${esc(p.name)}</option>`).join("");
  const forOpts = '<option value="family">Family</option>' + (S.canFamily ? people : mine).map((p) => `<option value="m:${p.id}">${esc(p.name)}</option>`).join("");
  const whereOpts = (S.isAdmin ? [["budget", "Budget"], ["allowance", "Allowance"]] : [["budget", "Budget"], ["allowance", "Allowance"]])
      .map(([v, l]) => `<option value="${v}"${v === (S.isAdmin ? "budget" : "allowance") ? " selected" : ""}>${l}</option>`).join("");

  const form = `<form data-form="expense" id="expForm" class="inc-card inc-expense exf">
    <div class="inc-fh"><span class="inc-chip">${ICON.expense}</span><div><b>Add expense</b><small>Record who spent the money and who it was for</small></div></div>
    <div class="incf">
      <input type="hidden" name="id">
      <label class="fld"><span>Category${manage}</span><select name="category_id" required>${cats}</select></label>
      <label class="fld"><span>Amount (Tk)</span><input name="amount" type="number" step="0.01" min="0.01" placeholder="0.00" required></label>
      <label class="fld"><span>Purpose</span><input name="purpose" placeholder="e.g. Groceries" required maxlength="255"></label>
      <label class="fld"><span>Who</span><select name="user_id" required>${whoOpts}</select></label>
      <label class="fld"><span>For</span><select name="for_to" required>${forOpts}</select></label>
      <label class="fld"><span>Where</span><select name="where" required>${whereOpts}</select></label>
      <label class="fld"><span>Date</span><input name="expense_date" type="date" value="${today()}" required></label>
      <div class="inc-acts"><button type="button" class="ghost hidden" data-act="expense-cancel">Cancel</button><button class="primary" data-btn>Add expense</button></div>
    </div></form>`;

  const total = rows.reduce((a, r) => a + Number(r.amount), 0);
  const body = rows.map((r) => `<tr><td class="inc-date">${esc(r.expense_date)}</td><td>${esc(r.user_name)}</td><td>${esc(r.category)}</td><td>${esc(r.purpose)}</td><td>${esc(r.for_name || "Family")}<td>${esc(r.where)}</td><td class="num">${money(r.amount)}</td><td class="num">${r.can_edit ? `<span class="inc-ra"><button type="button" class="inc-ib" title="Edit" data-act="expense-edit" data-id="${r.id}">${ICON.edit}</button><button type="button" class="inc-ib del" title="Delete" data-act="expense-delete" data-id="${r.id}">${ICON.del}</button></span>` : ""}</td></tr>`).join("");
  const tableCard = `<div class="inc-tablecard"><div class="inc-th"><div><b>Expenses history</b><small>${rows.length} ${rows.length === 1 ? "entry" : "entries"}</small></div></div>`
    + (rows.length
      ? `<div class="inc-scroll"><table class="inc-table"><thead><tr><th>Date</th><th>Who</th><th>Category</th><th>Purpose</th><th>For</th><th>Where</th><th class="num">Amount</th><th></th></tr></thead><tbody>${body}</tbody><tfoot><tr><td colspan="6">Total</td><td class="num">${money(total)}</td><td></td></tr></tfoot></table></div>`
      : '<div class="inc-empty">No expenses for this period yet.</div>')
    + "</div>";

  return `<div class="head"><div><h2>Expenses</h2><p class="inc-sub">Track who spent and who it was for</p></div><div class="ctl">${scopeSel}${ctlMonth()}</div></div>`
    + form + tableCard;
}

function shareLabel(r) {
  if (r.share_type === "bank") return "Deposit to Bank";
  if (r.share_type === "other") return "Others" + (r.share_note ? " - " + r.share_note : "");
  if (r.share_type === "family") return "Family (shared)";
  return r.user_name || "Family (shared)";
}

function toggleShareNote() {
  const f = $("#incomeForm");
  if (!f) return;
  const on = f.elements.share_with.value === "other";
  $("#shareNote").classList.toggle("hidden", !on);
  $("#shareNote").required = on;
}

const svg = (d, s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const ICON = {
  income: svg('<circle cx="12" cy="12" r="10"/><polyline points="8 12 12 16 16 12"/><line x1="12" y1="8" x2="12" y2="16"/>'),
  family: svg('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'),
  savings: svg('<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>'),
  expense: svg('<circle cx="12" cy="12" r="10"/><polyline points="16 12 12 8 8 12"/><line x1="12" y1="16" x2="12" y2="8"/>'), allowance: svg('<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>'),
  edit: svg('<path d="M17 3a2.83 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>', 15),
  del: svg('<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>', 15),
};

function groupIncome(rows) {
  const map = new Map();
  for (const r of rows) {
    const key = r.income_date + "|" + (r.user_id ?? "family");
    if (!map.has(key)) map.set(key, {date: r.income_date, who: r.user_name || "Family", types: new Set(), income: [], family_share: [], savings: []});
    const g = map.get(key);
    g.types.add(r.income_type);
    (g[r.kind] || g.income).push(r);
  }
  return [...map.values()];
}

async function vIncome() {
  if (!S.canFamily) S.incView = "me";
  const me = S.me;
  const people = S.canFamily ? await api("/people") : [];
  let url = `/incomes?month=${S.month}&scope=personal`;
  if (S.incView !== "me") url = `/incomes?month=${S.month}&scope=family` + (S.incView !== "family" ? "&user_id=" + encodeURIComponent(S.incView) : "");
  const rows = await api(url);
  S.incomeRows = rows;

  const sel = (v) => (S.incView === v ? " selected" : "");
  const top = `<select id="incView">`
    + (S.canFamily ? `<option value="family"${sel("family")}>All family members</option>` : "")
    + `<option value="me"${sel("me")}>${esc(me.full_name)}</option>`
    + (S.canFamily ? people.filter((p) => p.id !== me.id).map((p) => `<option value="${p.id}"${sel(String(p.id))}>${esc(p.name)}</option>`).join("") : "")
    + "</select>";

  S.incomeTypes = await api("/income-types");
  const types = S.incomeTypes.map((t) => `<option value="${esc(t.name)}">${esc(t.name)}</option>`).join("");
  const manage = S.isAdmin ? ' <button type="button" class="lnk" data-act="type-manage">Manage</button>' : "";
  const who = S.isAdmin ? people : [{id: me.id, name: me.full_name}];
  const memberOpts = who.map((p) => `<option value="m:${p.id}">${esc(p.name)}</option>`).join("");

  const mkForm = (kind, title, hint, btn, icon) => `<form data-form="income" id="incForm-${kind}" class="inc-card inc-${kind}">
    <div class="inc-fh"><span class="inc-chip">${icon}</span><div><b>${title}</b><small>${hint}</small></div></div>
    <div class="incf">
      <input type="hidden" name="id"><input type="hidden" name="kind" value="${kind}"><input type="hidden" name="description">
      <label class="fld"><span>Type${manage}</span><select name="income_type">${types}</select></label>
      <label class="fld"><span>Amount (Tk)</span><input name="amount" type="number" step="0.01" min="0.01" placeholder="0.00" required></label>
      <label class="fld"><span>Date</span><input name="income_date" type="date" value="${today()}" required></label>
      <label class="fld"><span>Member</span><select name="share_with" required>${memberOpts}</select></label>
      <div class="inc-acts"><button type="button" class="ghost hidden" data-act="income-cancel">Cancel</button><button type="button" class="ghost del hidden" data-act="income-del-one">Delete</button><button class="primary" data-btn>${btn}</button></div>
    </div></form>`;
  const forms = S.canIncome
    ? mkForm("income", "Add income", "Money received by a family member", "Add income", ICON.income)
      + mkForm("family_share", "Share with Family", "Money a member contributes to the family", "Add Contribution", ICON.family)
      + mkForm("savings", "Savings", "Money a member sets aside as savings", "Add savings", ICON.savings)
    : "";

  const sum = (k) => rows.filter((r) => r.kind === k).reduce((a, r) => a + Number(r.amount), 0);
  const cnt = (k) => rows.filter((r) => r.kind === k).length;

  const cell = (list, cls) => list.length
    ? `<div class="inc-amt ${cls}">${money(list.reduce((a, r) => a + Number(r.amount), 0))}</div>`
    : '<span class="inc-none">&ndash;</span>';
  const groups = groupIncome(rows);
  S.incGroups = groups;
  const body = groups.map((g, i) => {
    const can = [...g.income, ...g.family_share, ...g.savings].some((r) => r.can_edit);
    return `<tr><td class="inc-date">${esc(g.date)}</td><td><span class="inc-pill">${esc([...g.types].join(", "))}</span></td><td class="inc-name">${esc(g.who)}</td><td class="num">${cell(g.income, "in")}</td><td class="num">${cell(g.family_share, "fam")}</td><td class="num">${cell(g.savings, "sav")}</td><td class="num">${can ? `<span class="inc-ra"><button type="button" class="inc-ib" title="Edit" data-act="income-edit" data-g="${i}">${ICON.edit}</button><button type="button" class="inc-ib del" title="Delete" data-act="income-delete" data-g="${i}">${ICON.del}</button></span>` : ""}</td></tr>`;
  }).join("");

  const tableCard = `<div class="inc-tablecard"><div class="inc-th"><div><b>Income history</b><small>${rows.length} ${rows.length === 1 ? "entry" : "entries"}</small></div></div>`
    + (rows.length
      ? `<div class="inc-scroll"><table class="inc-table"><thead><tr><th>Date</th><th>Type</th><th>Shared by</th><th class="num">Income</th><th class="num">Share with family</th><th class="num">Savings</th><th></th></tr></thead><tbody>${body}</tbody><tfoot><tr><td colspan="3">Total</td><td class="num tin">${money(sum("income"))}</td><td class="num tfam">${money(sum("family_share"))}</td><td class="num tsav">${money(sum("savings"))}</td><td></td></tr></tfoot></table></div>`
      : '<div class="inc-empty">No entries for this period yet.</div>')
    + "</div>";

  return `<div class="head"><div><h2>Income</h2><p class="inc-sub">Income, family contributions and savings</p></div><div class="ctl">${top}${ctlMonth()}</div></div>`
    + forms + tableCard;
}

async function vAllowance() {
  const [rows, hist] = await Promise.all([api(`/allowances/overview?month=${S.month}`), api(`/allowances?month=${S.month}`)]);
  S.allowRows = hist;
  const opts = rows.map((m) => `<option value="${m.user_id}">${esc(m.name)}</option>`).join("");
  const form = !S.isAdmin ? "" : rows.length
    ? `<form data-form="allowance" id="alForm" class="inc-card inc-allowance exf">
      <div class="inc-fh"><span class="inc-chip">${ICON.allowance}</span><div><b>Give allowance</b><small>Money given to a family member for the month</small></div></div>
      <div class="incf">
        <input type="hidden" name="id">
        <label class="fld"><span>Member</span><select name="user_id" required>${opts}</select></label>
        <label class="fld"><span>Amount (Tk)</span><input name="amount" type="number" step="0.01" min="0.01" placeholder="0.00" required></label>
        <label class="fld"><span>Month</span><input name="period" type="month" value="${S.month}" required></label>
        <label class="fld"><span>Note</span><input name="note" placeholder="Optional" maxlength="255"></label>
        <div class="inc-acts"><button type="button" class="ghost hidden" data-act="allow-cancel">Cancel</button><button class="primary" data-btn>Give allowance</button></div>
      </div></form>`
    : '<p class="mute">Add family members first.</p>';

  const total = hist.reduce((a, r) => a + Number(r.amount), 0);
  const act = (id) => S.isAdmin
    ? `<td class="num"><span class="inc-ra"><button type="button" class="inc-ib" title="Edit" data-act="allow-edit" data-id="${id}">${ICON.edit}</button><button type="button" class="inc-ib del" title="Delete" data-act="allow-delete" data-id="${id}">${ICON.del}</button></span></td>` : "";
  const hbody = hist.map((r) => `<tr><td class="inc-date">${esc(r.date)}</td><td>${esc(r.user_name)}</td><td>${esc(r.note)}</td><td class="num">${money(r.amount)}</td>${act(r.id)}</tr>`).join("");
  const histCard = `<div class="inc-tablecard"><div class="inc-th"><div><b>Allowance history</b><small>${hist.length} ${hist.length === 1 ? "entry" : "entries"}</small></div></div>`
    + (hist.length
      ? `<div class="inc-scroll"><table class="inc-table"><thead><tr><th>Date</th><th>Member</th><th>Note</th><th class="num">Amount</th>${S.isAdmin ? "<th></th>" : ""}</tr></thead><tbody>${hbody}</tbody><tfoot><tr><td colspan="3">Total</td><td class="num">${money(total)}</td>${S.isAdmin ? "<td></td>" : ""}</tr></tfoot></table></div>`
      : '<div class="inc-empty">No allowance given for this month yet.</div>')
    + "</div>";

  const sbody = rows.map((m) => `<tr><td>${esc(m.name)}</td><td class="num">${money(m.given)}</td><td class="num">${money(m.spent)}</td><td class="num">${money(m.remaining)}</td><td class="num">${m.percent_used}%</td></tr>`).join("");
  const sGiven = rows.reduce((a, m) => a + Number(m.given), 0);
  const sSpent = rows.reduce((a, m) => a + Number(m.spent), 0);
  const sRemaining = rows.reduce((a, m) => a + Number(m.remaining), 0);
  const sUsed = sGiven > 0 ? (sSpent / sGiven) * 100 : 0;
  const summaryCard = rows.length
    ? `<div class="inc-tablecard"><div class="inc-th"><div><b>Balance summary</b><small>Given, spent and remaining this month</small></div></div><div class="inc-scroll"><table class="inc-table"><thead><tr><th>Member</th><th class="num">Given</th><th class="num">Spent</th><th class="num">Remaining</th><th class="num">Used</th></tr></thead>
<tbody>${sbody}</tbody>
<tfoot><tr>
  <td>Total</td>
  <td class="num">${money(sGiven)}</td>
  <td class="num">${money(sSpent)}</td>
  <td class="num">${money(sRemaining)}</td>
  <td class="num">${sUsed.toFixed(0)}%</td>
</tr></tfoot></table></div></div>` : "";

  return `<div class="head"><div><h2>Allowances</h2><p class="inc-sub">${S.isAdmin ? "Give and track family member allowances" : "Allowances given to family members"}</p></div><div class="ctl">${ctlMonth()}</div></div>`
    + form + histCard + summaryCard;
}
async function vMembers() {
  S.members = await api("/members");
  if (S.isAdmin) S.relations = await api("/relations");
  const members = S.members.filter((m) => m.role === "family_member");

  const rel = S.isAdmin ? S.relations.map((r) => `<option value="${esc(r.name)}">${esc(r.name)}</option>`).join("") : "";
  const form = !S.isAdmin ? "" : `<form data-form="member" id="memForm" class="inc-card inc-member exf">
    <div class="inc-fh"><span class="inc-chip">${ICON.family}</span><div><b>Add family member</b><small>Create an account for a family member</small></div></div>
    <div class="incf">
      <input type="hidden" name="id">
      <label class="fld"><span>Full name</span><input name="full_name" placeholder="Full name" required maxlength="120" autocomplete="off"></label>
      <label class="fld"><span>Email</span><input name="email" type="email" placeholder="name@example.com" required autocomplete="off"></label>
      <label class="fld"><span>Password</span><input name="password" type="password" minlength="10" placeholder="Min 10 characters" autocomplete="new-password" required></label>
      <label class="fld"><span>Relation <button type="button" class="lnk" data-act="rel-manage">Manage</button></span><select name="relation" required>${rel}</select></label>
      <div class="inc-acts"><button type="button" class="ghost hidden" data-act="member-cancel">Cancel</button><button class="primary" data-btn>Add member</button></div>
    </div></form>`;

  const body = members.map((m) => `<tr><td>${esc(m.full_name)}</td><td>${esc(m.email)}</td><td>${esc(m.relation)}</td><td><span class="${m.is_active ? "" : "mute"}">${m.is_active ? "Active" : "Disabled"}</span>${S.isAdmin ? ` <button type="button" class="ghost" data-act="member-toggle" data-id="${m.id}" data-active="${m.is_active}">${m.is_active ? "Disable" : "Enable"}</button>` : ""}</td>${S.isAdmin ? `<td class="num"><span class="inc-ra"><button type="button" class="inc-ib" title="Edit" data-act="member-edit" data-id="${m.id}">${ICON.edit}</button><button type="button" class="inc-ib del" title="Delete" data-act="member-delete" data-id="${m.id}">${ICON.del}</button></span></td>` : ""}</tr>`).join("");
  const tableCard = `<div class="inc-tablecard"><div class="inc-th"><div><b>Family members</b><small>${members.length} ${members.length === 1 ? "member" : "members"}</small></div></div>`
    + (members.length
      ? `<div class="inc-scroll"><table class="inc-table"><thead><tr><th>Name</th><th>Email</th><th>Relation</th><th>Status</th>${S.isAdmin ? "<th></th>" : ""}</tr></thead><tbody>${body}</tbody></table></div>`
      : '<div class="inc-empty">No family members yet.</div>')
    + "</div>";

  return `<div class="head"><div><h2>Family members</h2><p class="inc-sub">${S.isAdmin ? "Manage family member accounts" : "Members of this family"}</p></div></div>` + form + tableCard;
}

async function vPlatform() {
  const rows = await api("/platform/families");
  return head("Families") + table(["ID", "Family", "Plan", "Members", "Status", "Created", ""], rows.map((f) => [
    f.id, esc(f.name), esc(f.plan), f.members, f.is_active ? "Active" : "Suspended", f.created_at.slice(0, 10),
    `<button class="ghost" data-act="fam-toggle" data-id="${f.id}" data-active="${f.is_active}">${f.is_active ? "Suspend" : "Activate"}</button> <button type="button" class="inc-ib del" title="Delete family" data-act="fam-delete" data-id="${f.id}" data-name="${esc(f.name)}">${ICON.del}</button>`,
  ]));
}

const VIEWS = {dashboard: vDashboard, expenses: vExpenses, income: vIncome, allowance: vAllowance, members: vMembers, platform: vPlatform};

/* ---------- AI chat ---------- */
function addMsg(who, text) {
  const d = document.createElement("div");
  d.className = "msg " + who;
  d.textContent = text;
  $("#chat").appendChild(d);
  $("#chat").scrollTop = $("#chat").scrollHeight;
  return d;
}

async function askAI(question, retry = true) {
  const el = addMsg("bot", "Thinking...");
  try {
    const res = await fetch("/api/v1/ai/" + (question ? "chat/stream" : "monthly-summary/stream"), {
      method: question ? "POST" : "GET",
      headers: {"Content-Type": "application/json", Authorization: "Bearer " + S.access},
      body: question ? JSON.stringify({message: question}) : undefined,
    });
    if (res.status === 401 && retry && await refreshTokens()) { el.remove(); return askAI(question, false); }
    if (!res.ok) {
      const err = await res.json().catch(() => null);
      throw new Error(err && typeof err.detail === "string" ? err.detail : "Request failed");
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let text = "";
    el.textContent = "";
    for (;;) {
      const {value, done} = await reader.read();
      if (done) break;
      text += decoder.decode(value, {stream: true});
      el.textContent = text;
      $("#chat").scrollTop = $("#chat").scrollHeight;
    }
    if (!text.trim()) el.textContent = "Sorry, I could not produce an answer.";
  } catch (e) { el.textContent = e.message; }
}
/* ---------- forms ---------- */
const FORMS = {
  async login(f) {
    setTokens(await api("/auth/login", "POST", {email: f.email, password: f.password}));
    S.me = await api("/auth/me");
    await startApp();
  },
  async register(f) {
    setTokens(await api("/auth/register-family", "POST", f));
    S.me = await api("/auth/me");
    await startApp();
  },
  async category(f) {
    await api(sheetApi(), "POST", {name: f.name});
    await reloadSheetList();
    renderCatSheet();
  },
  async catrename(f, form) {
    await api(`${sheetApi()}/${form.dataset.id}`, "PUT", {name: f.name});
    await reloadSheetList();
    S.catEdit = null;
    renderCatSheet();
  },

  async expense(f) {
    const body = {
      category_id: +f.category_id, amount: +f.amount, where: f.where,purpose: f.purpose, expense_date: f.expense_date,
      user_id: +f.user_id, for_user_id: f.for_to === "family" ? null : +f.for_to.slice(2), source: f.source,
    };
    if (f.id) {
      await api("/expenses/" + f.id, "PUT", body);
    } else {
      const r = await api("/expenses", "POST", body);
      addMsg("bot", r.ai_feedback);
    }
    go("expenses");
  },

  async income(f) {
    const body = {income_type: f.income_type, amount: +f.amount, description: f.description || null,
      income_date: f.income_date, share_type: "member", user_id: +f.share_with.slice(2), share_note: null, kind: f.kind};
    if (f.id) await api("/incomes/" + f.id, "PUT", body);
    else await api("/incomes", "POST", body);
    go("income");
  },

  async allowance(f) {
    const body = {user_id: +f.user_id, amount: +f.amount, period: f.period, note: f.note || null};
    if (f.id) await api("/allowances/" + f.id, "PUT", body);
    else await api("/allowances", "POST", body);
    go("allowance");
  },

  async member(f) {
    const body = {full_name: f.full_name, email: f.email, relation: f.relation};
    if (f.id) {
      if (f.password) body.password = f.password;
      await api(`/members/${f.id}`, "PATCH", body);
    } else {
      body.password = f.password;
      await api("/members", "POST", body);
    }
    go("members");
  },

  async chat(f, form) {
    const q = f.message.trim();
    if (!q) return;
    addMsg("user", q);
    form.reset();
    await askAI(q);
  },
};

document.addEventListener("submit", async (e) => {
  const form = e.target, name = form.dataset.form;
  if (!name) return;
  e.preventDefault();
  try { await FORMS[name](Object.fromEntries(new FormData(form)), form); }
  catch (err) {
    if (form.closest("#auth")) $("#authMsg").textContent = err.message; else alert(err.message);
  }
});

document.addEventListener("click", async (e) => {
    if (e.target.id === "catSheet") return closeCatSheet();
  const t = e.target.closest("[data-view],[data-act],[data-tab]");
  if (!t) return;
  try {
    if (t.dataset.tab) {
      document.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("on", b === t));
      $("#loginForm").classList.toggle("hidden", t.dataset.tab !== "login");
      $("#registerForm").classList.toggle("hidden", t.dataset.tab !== "register");
      return;
    }

    if (t.dataset.view) {
      $("#ai").classList.remove("open");
      if (t.dataset.view === "dashboard") {
        resetDash("month");
      }

      return go(t.dataset.view);
    }

    switch (t.dataset.act) {

      case "income-edit": {
        const g = S.incGroups[+t.dataset.g];
        if (!g) return;
        let first = null;
        for (const kind of ["income", "family_share", "savings"]) {
          const r = g[kind].find((x) => x.can_edit);
          const f = r && $("#incForm-" + kind);
          if (!f) continue;
          f.elements.id.value = r.id;
          f.elements.income_type.value = r.income_type;
          f.elements.amount.value = r.amount;
          f.elements.description.value = r.description || "";
          f.elements.income_date.value = r.income_date;
          f.elements.share_with.value = "m:" + (r.user_id ?? S.me.id);
          f.querySelector("[data-btn]").textContent = "Save changes";
          f.querySelector('[data-act="income-cancel"]').classList.remove("hidden");
          const d = f.querySelector('[data-act="income-del-one"]');
          d.dataset.id = r.id;
          d.classList.remove("hidden");
          first = first || f;
        }
        if (first) first.scrollIntoView({behavior: "smooth"});
        return;
      }
      case "income-cancel": return go("income");
      case "income-delete": {
        const g = S.incGroups[+t.dataset.g];
        const list = g ? [...g.income, ...g.family_share, ...g.savings].filter((x) => x.can_edit) : [];
        if (!list.length) return;
        if (!confirm(list.length === 1 ? "Delete this entry?" : `Delete all ${list.length} entries on ${g.date} for ${g.who}?`)) return;
        for (const r of list) await api(`/incomes/${r.id}`, "DELETE");
        return go("income");
      }
      case "income-del-one":
        if (!confirm("Delete this entry?")) return;
        await api(`/incomes/${t.dataset.id}`, "DELETE");
        return go("income");
      case "cat-manage": S.sheetKind = "categories"; S.catEdit = null; return renderCatSheet();
      case "type-manage": S.sheetKind = "types"; S.catEdit = null; return renderCatSheet();
      case "cat-close": return closeCatSheet();
      case "cat-edit": S.catEdit = +t.dataset.id; return renderCatSheet();
      case "cat-cancel": S.catEdit = null; return renderCatSheet();
      case "cat-del":
        if (!confirm("Delete this item?")) return;
        await api(`${sheetApi()}/${t.dataset.id}`, "DELETE");
        await reloadSheetList();
        return renderCatSheet();

      case "allow-edit": {
        const r = S.allowRows.find((x) => x.id === +t.dataset.id);
        const f = $("#alForm");
        if (!r || !f) return;
        f.elements.id.value = r.id;
        f.elements.user_id.value = r.user_id;
        f.elements.amount.value = r.amount;
        f.elements.period.value = r.period;
        f.elements.note.value = r.note || "";
        f.querySelector("[data-btn]").textContent = "Save changes";
        f.querySelector('[data-act="allow-cancel"]').classList.remove("hidden");
        f.scrollIntoView({behavior: "smooth"});
        return;
      }
      case "allow-cancel": return go("allowance");
      case "allow-delete":
        if (!confirm("Delete this allowance entry?")) return;
        await api(`/allowances/${t.dataset.id}`, "DELETE");
        return go("allowance");

      case "rel-manage": S.sheetKind = "relations"; S.catEdit = null; return renderCatSheet();

      case "member-edit": {
        const m = S.members.find((x) => x.id === +t.dataset.id);
        const f = $("#memForm");
        if (!m || !f) return;
        f.elements.id.value = m.id;
        f.elements.full_name.value = m.full_name;
        f.elements.email.value = m.email;
        f.elements.password.value = "";
        f.elements.password.required = false;
        f.elements.password.placeholder = "New password (optional)";
        f.elements.relation.value = m.relation || "";
        f.querySelector(".inc-fh b").textContent = "Edit family member";
        f.querySelector("[data-btn]").textContent = "Save changes";
        f.querySelector('[data-act="member-cancel"]').classList.remove("hidden");
        f.scrollIntoView({behavior: "smooth"});
        return;
      }

      case "member-cancel": return go("members");
      case "member-delete":
        if (!confirm("Delete this member account?")) return;
        await api(`/members/${t.dataset.id}`, "DELETE");
        return go("members");

      case "dash-month": resetDash("month"); return go("dashboard");
      case "dash-year": resetDash("year"); return go("dashboard");
      case "dash-group": S.dGroup = t.dataset.g; return go("dashboard");
      case "ch-toggle": {
        const key = t.dataset.k;
        if (S.hidden.has(key)) S.hidden.delete(key); else S.hidden.add(key);
        t.classList.toggle("off");
        return drawTrend();
      }
      case "pie-toggle": {
        const key = t.dataset.k;
        if (S.pieHidden.has(key)) S.pieHidden.delete(key); else S.pieHidden.add(key);
        return drawPie($("#chPie"), pieItems(), S.pieHidden);
      }

      case "fam-delete": {
        const typed = prompt(`This permanently deletes the family "${t.dataset.name}" and ALL its data.\nType the family name to confirm:`);
        if (typed === null) return;
        if (typed.trim() !== t.dataset.name) { alert("The name did not match. Nothing was deleted."); return; }
        await api(`/platform/families/${t.dataset.id}`, "DELETE");
        return go("platform");
      }

      case "bp-toggle": {
        const key = t.dataset.k;
        if (S.catHidden.has(key)) S.catHidden.delete(key); else S.catHidden.add(key);
        return drawBudgetPie($("#chBudget"), budgetPieItems(), S.catHidden);
      }

      case "expense-edit": {
        const r = S.expRows.find((x) => x.id === +t.dataset.id);
        const f = $("#expForm");
        if (!r || !f) return;
        f.elements.id.value = r.id;
        f.elements.category_id.value = r.category_id;
        f.elements.amount.value = r.amount;
        f.elements.where.value = r.where;
        f.elements.purpose.value = r.purpose;
        f.elements.user_id.value = r.user_id;
        f.elements.for_to.value = r.for_user_id ? "m:" + r.for_user_id : "family";
        f.elements.expense_date.value = r.expense_date;
        f.querySelector("[data-btn]").textContent = "Save changes";
        f.querySelector('[data-act="expense-cancel"]').classList.remove("hidden");
        f.scrollIntoView({behavior: "smooth"});
        return;
      }
      case "expense-cancel": return go("expenses");
      case "expense-delete":
        if (!confirm("Delete this expense?")) return;
        await api(`/expenses/${t.dataset.id}`, "DELETE");
        return go("expenses");
      case "logout": return logout();
      case "ai-toggle": {
        const panel = $("#ai");
        const button = $("#aiToggle");

        panel.classList.toggle("open");

        if (panel.classList.contains("open")) {
          button.style.display = "none";
        } else {
          button.style.display = "";
        }
        return;
      }
      case "ai-summary": return askAI(null);
      case "member-toggle":
        await api(`/members/${t.dataset.id}`, "PATCH", {is_active: t.dataset.active !== "true"});
        return go("members");
      case "fam-toggle":
        await api(`/platform/families/${t.dataset.id}`, "PATCH", {is_active: t.dataset.active !== "true"});
        return go("platform");
    }
  } catch (err) { alert(err.message); }
});

document.addEventListener("change", async (e) => {
  const t = e.target;
  try {
    if (t.id === "month") { S.month = t.value || thisMonth(); return go(S.view); }
    if (t.id === "scope") { S.scope = t.value; return go(S.view); }
    if (t.id === "dFrom" || t.id === "dTo") {
      if (!t.value) return;
      if (t.id === "dFrom") { S.dFrom = t.value; if (S.dTo < S.dFrom) S.dTo = S.dFrom; }
      else { S.dTo = t.value; if (S.dFrom > S.dTo) S.dFrom = S.dTo; }
      return go("dashboard");
    }
    if (t.id === "incView") { S.incView = t.value; return go("income"); }
    if (t.name === "share_with") return toggleShareNote();
    if (t.dataset && t.dataset.perm) {
      const perms = {};
      t.closest("tr").querySelectorAll("[data-perm]").forEach((c) => { perms[c.dataset.perm] = c.checked; });
      await api(`/members/${t.dataset.id}`, "PATCH", {permissions: perms});
    }
  } catch (err) { alert(err.message); go(S.view); }
});

async function boot() {
  if (S.access) {
    try { S.me = await api("/auth/me"); return await startApp(); } catch { /* fall through */ }
  }
  showAuth();
}

let resizeTimer;
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (S.view === "dashboard" && S.dash && $("#chTrend")) drawDashboard(); }, 150);
});

boot();

/* =====================================================
   Login Remember Me
   ===================================================== */

(() => {

  const auth = document.getElementById("auth");
  const loginForm = document.getElementById("loginForm");
  const rememberMe = document.getElementById("rememberMe");

  if (!auth || !loginForm || !rememberMe) return;

  const emailInput =
    loginForm.querySelector('input[name="email"]');

  const passwordInput =
    loginForm.querySelector('input[name="password"]');


  /* -------------------------------
     Restore remembered email
     ------------------------------- */

  const rememberedEmail =
    localStorage.getItem("rememberedLoginEmail");

  if (rememberedEmail) {

    emailInput.value = rememberedEmail;

    rememberMe.checked = true;

  } else {

    emailInput.value = "";

    rememberMe.checked = false;

  }

  /* Password must NEVER be remembered */

  passwordInput.value = "";


  /* -------------------------------
     When Login is submitted
     ------------------------------- */

  loginForm.addEventListener("submit", () => {

    if (rememberMe.checked) {

      localStorage.setItem(
        "rememberedLoginEmail",
        emailInput.value.trim()
      );

    } else {

      localStorage.removeItem(
        "rememberedLoginEmail"
      );

    }

  });


  /* -------------------------------
     Detect logout / auth screen show
     ------------------------------- */

  const resetLoginScreen = () => {

    /* ALWAYS remove password */

    passwordInput.value = "";


    const savedEmail =
      localStorage.getItem("rememberedLoginEmail");


    if (savedEmail) {

      emailInput.value = savedEmail;

      rememberMe.checked = true;

    } else {

      emailInput.value = "";

      rememberMe.checked = false;

    }

  };


  /* Your app uses .hidden to show/hide auth.
     So this automatically detects logout. */

  const observer =
    new MutationObserver(() => {

      if (!auth.classList.contains("hidden")) {

        resetLoginScreen();

      }

    });


  observer.observe(
    auth,
    {
      attributes: true,
      attributeFilter: ["class"]
    }
  );


  /* Initial security cleanup */

  if (!auth.classList.contains("hidden")) {

    resetLoginScreen();

  }

})();

/* =====================================
   Forgot Password
===================================== */

(() => {

const forgotBtn =
document.getElementById("forgotPassword");

const modal =
document.getElementById("resetModal");


const closeBtn =
document.getElementById("closeReset");


const form =
document.getElementById("forgotForm");


const email =
document.getElementById("forgotEmail");


const msg =
document.getElementById("forgotMsg");



if(!forgotBtn || !modal) return;



forgotBtn.onclick = () => {

    modal.classList.remove("hidden");

};



closeBtn.onclick = () => {

    modal.classList.add("hidden");

};



form.onsubmit = async(e)=>{

    e.preventDefault();


    msg.textContent="Sending...";


    try {


      const res =
      await fetch(
        "/auth/forgot-password",
        {

          method:"POST",

          headers:{
            "Content-Type":"application/json"
          },

          body:JSON.stringify({
            email:email.value
          })

        }
      );


      const data =
      await res.json();


      msg.textContent =
      data.message ||
      "Check your email";


    }

    catch(err){

      msg.textContent =
      "Something went wrong";

    }


};



})();