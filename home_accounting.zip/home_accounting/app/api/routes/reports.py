from datetime import date, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import and_, func, select

from app.api.deps import DB, FamilyUser, MonthQ, ScopeQ
from app.core.permissions import can_view_family_reports
from app.models.models import Allowance, Category, Expense, Income, User
from app.services.finance_service import (
    allowance_status, current_month, expense_by_category, income_by_type,
    month_bounds, total_expense, total_income,
)

router = APIRouter(prefix="/reports", tags=["reports"])


@router.get("/summary")
def summary(db: DB, user: FamilyUser, month: MonthQ = None, scope: ScopeQ = "personal"):
    month = month or current_month()
    if scope == "family" and not can_view_family_reports(user):
        raise HTTPException(403, "Not allowed")
    start, end = month_bounds(month)
    fam = user.family_id
    uid = user.id if scope == "personal" else None

    income = total_income(db, fam, start, end, uid)
    expense = total_expense(db, fam, start, end, uid)
    out = {
        "month": month,
        "scope": scope,
        "income": float(income),
        "expense": float(expense),
        "balance": float(income - expense),
        "by_category": [{"name": n, "amount": float(t)} for n, t in expense_by_category(db, fam, start, end, uid)],
        "income_by_type": [{"name": n, "amount": float(t)} for n, t in income_by_type(db, fam, start, end, uid)],
    }
    if scope == "personal":
        out["allowance"] = {k: float(v) for k, v in allowance_status(db, fam, user.id, month).items()}
    else:
        rows = db.execute(
            select(User.full_name, func.coalesce(func.sum(Expense.amount), 0))
            .outerjoin(Expense, and_(Expense.user_id == User.id,
                                     Expense.expense_date >= start, Expense.expense_date < end))
            .where(User.family_id == fam)
            .group_by(User.id, User.full_name)
            .order_by(User.id)
        ).all()
        out["members"] = [{"name": n, "amount": float(t)} for n, t in rows]
    return out


def _buckets(start: date, end: date, group: str) -> list[str]:
    out: list[str] = []
    if group == "day":
        d = start
        while d <= end:
            out.append(d.isoformat())
            d += timedelta(days=1)
    elif group == "month":
        y, m = start.year, start.month
        while (y, m) <= (end.year, end.month):
            out.append(f"{y}-{m:02d}")
            y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    else:
        out = [str(y) for y in range(start.year, end.year + 1)]
    return out


def _key(d: date, group: str) -> str:
    if group == "day":
        return d.isoformat()
    if group == "month":
        return d.strftime("%Y-%m")
    return d.strftime("%Y")



@router.get("/dashboard")
def dashboard(
    db: DB,
    user: FamilyUser,
    date_from: Annotated[date | None, Query(alias="from")] = None,
    date_to: Annotated[date | None, Query(alias="to")] = None,
    scope: ScopeQ = "personal",
    group: Literal["day", "month", "year"] = "day",
):
    today = date.today()
    start = date_from or today.replace(day=1)
    end = date_to or ((today.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1))
    if start > end:
        raise HTTPException(400, "'From' date must be before 'To' date")
    if (end - start).days > 366 * 30:
        raise HTTPException(400, "Date range is too large")
    if scope == "family" and not can_view_family_reports(user):
        raise HTTPException(403, "Not allowed")
    if group == "day" and (end - start).days > 400:
        group = "month"

    fam = user.family_id
    uid = user.id if scope == "personal" else None

    def income_conds(kind: str):
        conds = [Income.family_id == fam, Income.kind == kind,
                 Income.income_date >= start, Income.income_date <= end]
        if uid is not None:
            conds.append(Income.user_id == uid)
        return conds

    # expenses paid from an allowance are not counted again: the allowance itself is the expense
    exp_conds = [Expense.family_id == fam, Expense.source != "allowance",
                 Expense.expense_date >= start, Expense.expense_date <= end]
    if uid is not None:
        exp_conds.append(Expense.user_id == uid)

    all_exp_conds = [Expense.family_id == fam, Expense.expense_date >= start, Expense.expense_date <= end]
    if uid is not None:
        all_exp_conds.append(Expense.user_id == uid)

    al_date = func.date(Allowance.period + "-01")
    al_conds = [
        Allowance.family_id == fam,
        Allowance.period >= start.strftime("%Y-%m"),
        Allowance.period <= end.strftime("%Y-%m"),
    ]
    if uid is not None:
        al_conds.append(Allowance.user_id == uid)

    labels = _buckets(start, end, group)
    pos = {k: i for i, k in enumerate(labels)}
    series = {k: [0.0] * len(labels) for k in ("income", "contrib", "allowance", "expenses", "savings")}

    def fill(name: str, date_col, value_col, conds):
        rows = db.execute(
            select(date_col, func.coalesce(func.sum(value_col), 0)).where(*conds).group_by(date_col)
        ).all()
        for d, total in rows:
            series[name][pos[_key(d, group)]] += float(total)

    fill("income", Income.income_date, Income.amount, income_conds("income"))
    fill("contrib", Income.income_date, Income.amount, income_conds("family_share"))
    fill("savings", Income.income_date, Income.amount, income_conds("savings"))
    fill("expenses", Expense.expense_date, Expense.amount, exp_conds)
    fill("allowance", al_date, Allowance.amount, al_conds)

    total = {k: sum(v) for k, v in series.items()}

    allowance_kpi_conds = [
        Allowance.family_id == fam,
        Allowance.period >= start.strftime("%Y-%m"),
        Allowance.period <= end.strftime("%Y-%m"),
    ]

    if uid is not None:
        allowance_kpi_conds.append(Allowance.user_id == uid)

    allowance_kpi_total = db.scalar(
        select(func.coalesce(func.sum(Allowance.amount), 0))
        .where(*allowance_kpi_conds)
    )
    year_remaining = 0.0

    if group != "day":
        allowance_given_year = db.scalar(
            select(func.coalesce(func.sum(Allowance.amount), 0))
            .where(
                Allowance.family_id == fam,
                Allowance.period >= start.strftime("%Y-%m"),
                Allowance.period <= end.strftime("%Y-%m"),
                *([Allowance.user_id == uid] if uid is not None else [])
            )
        )

        allowance_spent_year = db.scalar(
            select(func.coalesce(func.sum(Expense.amount), 0))
            .where(
                Expense.family_id == fam,
                Expense.place == "allowance",
                Expense.expense_date >= start,
                Expense.expense_date <= end,
                *([Expense.user_id == uid] if uid is not None else [])
            )
        )

        year_remaining = float(allowance_given_year or 0) - float(allowance_spent_year or 0)

    expense_kpi_total = db.scalar(
        select(func.coalesce(func.sum(Expense.amount), 0))
        .where(
            Expense.family_id == fam,
            Expense.place != "allowance",
            Expense.expense_date >= start,
            Expense.expense_date <= end,
            *([Expense.user_id == uid] if uid is not None else [])
        )
    )

    expenses_total = float(expense_kpi_total or 0) + float(allowance_kpi_total or 0)
    budget = total["contrib"]
    balance = budget - expenses_total
    kpi = {
        "income": total["income"],
        "budget": budget,
        "expenses": expenses_total,
        "balance": balance,
        "savings": total["savings"],
        "unspent": (
            total["income"] - budget - total["savings"]
            if group == "day"
            else balance + year_remaining
        ),
    }
    trend = {
        "labels": labels,
        "income": series["income"],
        "budget": series["contrib"],
        "expenses": [e + a for e, a in zip(series["expenses"], series["allowance"])],
        "savings": series["savings"],
    }

    cat_total = func.sum(Expense.amount)

    def by_category(conds):
        return [
            (name, float(t)) for name, t in db.execute(
                select(Category.name, cat_total)
                .select_from(Expense)
                .join(Category, Category.id == Expense.category_id)
                .where(*conds)
                .group_by(Category.name)
            ).all()
        ]

    cat_rows = by_category(all_exp_conds)  # all Expenses page data
    cat_rows.sort(key=lambda r: r[1], reverse=True)
    usage_rows = by_category(exp_conds)  # for the budget pie: expenses not paid from allowance
    if total["allowance"] > 0:
        usage_rows.append(("Allowance", total["allowance"]))
    usage_rows.sort(key=lambda r: r[1], reverse=True)
    members: dict[int, list] = {}
    for member_id, name, t in db.execute(
        select(User.id, User.full_name, func.sum(Expense.amount))
        .select_from(Expense)
        .join(User, User.id == Expense.user_id)
        .where(*exp_conds)
        .group_by(User.id, User.full_name)
    ).all():
        members[member_id] = [name, float(t)]
    for member_id, name, t in db.execute(
        select(User.id, User.full_name, func.sum(Allowance.amount))
        .select_from(Allowance)
        .join(User, User.id == Allowance.user_id)
        .where(*al_conds)
        .group_by(User.id, User.full_name)
    ).all():
        if member_id in members:
            members[member_id][1] += float(t)
        else:
            members[member_id] = [name, float(t)]
    member_rows = sorted(members.values(), key=lambda r: r[1], reverse=True)

    return {
        "from": start.isoformat(),
        "to": end.isoformat(),
        "scope": scope,
        "group": group,
        "kpi": {k: round(v, 2) for k, v in kpi.items()},
        "trend": {k: ([round(x, 2) for x in v] if k != "labels" else v) for k, v in trend.items()},
        "by_category": [{"name": n, "amount": round(a, 2)} for n, a in cat_rows],
        "budget_usage": [{"name": n, "amount": round(a, 2)} for n, a in usage_rows],
        "by_member": [{"name": n, "amount": round(a, 2)} for n, a in member_rows],
    }