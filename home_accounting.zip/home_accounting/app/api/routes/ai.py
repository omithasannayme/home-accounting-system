import re
import time

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from app.ai.service import ai_service
from app.api.deps import DB, FamilyUser
from app.schemas.schemas import ChatIn, ChatOut

router = APIRouter(prefix="/ai", tags=["ai"])

STREAM_HEADERS = {"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}


def _text_stream(text: str):
    for piece in re.split(r"(\s+)", text):
        if piece:
            yield piece
            time.sleep(0.012)


@router.post("/chat/stream")
def chat_stream(data: ChatIn, db: DB, user: FamilyUser):
    _, text = ai_service.route(db, user, data.message)  # search, math and model steps all finish here
    return StreamingResponse(_text_stream(text), media_type="text/plain; charset=utf-8", headers=STREAM_HEADERS)


@router.get("/monthly-summary/stream")
def monthly_summary_stream(db: DB, user: FamilyUser):
    text = ai_service.monthly_summary(db, user)["reply"]
    return StreamingResponse(_text_stream(text), media_type="text/plain; charset=utf-8", headers=STREAM_HEADERS)


@router.post("/chat", response_model=ChatOut)
def chat(data: ChatIn, db: DB, user: FamilyUser):
    return ai_service.chat(db, user, data.message)


@router.get("/monthly-summary", response_model=ChatOut)
def monthly_summary(db: DB, user: FamilyUser):
    return ai_service.monthly_summary(db, user)