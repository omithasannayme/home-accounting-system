"""income kind

Revision ID: 0003
Revises: 0002
"""
import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("incomes", sa.Column("kind", sa.String(20), nullable=False, server_default="income"))


def downgrade() -> None:
    op.drop_column("incomes", "kind")