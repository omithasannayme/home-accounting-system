"""expense source

Revision ID: 0007
Revises: b02b01b86e36
"""
import sqlalchemy as sa
from alembic import op

revision = "0007"
down_revision = "b02b01b86e36"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("expenses", sa.Column("source", sa.String(20), nullable=False, server_default="budget"))
    expenses = sa.table("expenses", sa.column("source", sa.String), sa.column("from_allowance", sa.Boolean))
    op.get_bind().execute(sa.update(expenses).where(expenses.c.from_allowance.is_(True)).values(source="allowance"))


def downgrade() -> None:
    op.drop_column("expenses", "source")