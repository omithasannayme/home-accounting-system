"""expense for_user_id

Revision ID: 0004
Revises: 0003
"""
import sqlalchemy as sa
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("expenses", sa.Column("for_user_id", sa.Integer, nullable=True))
    op.create_foreign_key("fk_expenses_for_user", "expenses", "users", ["for_user_id"], ["id"], ondelete="SET NULL")


def downgrade() -> None:
    op.drop_constraint("fk_expenses_for_user", "expenses", type_="foreignkey")
    op.drop_column("expenses", "for_user_id")