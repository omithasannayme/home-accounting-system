"""income share fields

Revision ID: 0002
Revises: 0001
"""
import sqlalchemy as sa
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("incomes", sa.Column("share_type", sa.String(20), nullable=False, server_default="member"))
    op.add_column("incomes", sa.Column("share_note", sa.String(255), nullable=True))
    op.execute("UPDATE incomes SET share_type = 'family' WHERE user_id IS NULL")


def downgrade() -> None:
    op.drop_column("incomes", "share_note")
    op.drop_column("incomes", "share_type")