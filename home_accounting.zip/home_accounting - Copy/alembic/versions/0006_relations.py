"""relations

Revision ID: 0006
Revises: 0005
"""
import sqlalchemy as sa
from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None

DEFAULT_RELATIONS = ["Father", "Mother", "Brother", "Sister", "Daughter", "Son", "Child", "Other"]


def upgrade() -> None:
    relations = op.create_table(
        "relations",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("family_id", sa.Integer, sa.ForeignKey("families.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(80), nullable=False),
        sa.UniqueConstraint("family_id", "name", name="uq_relations_family_name"),
    )
    op.alter_column("users", "relation", type_=sa.String(80), existing_type=sa.String(30), existing_nullable=True)

    families = sa.table("families", sa.column("id", sa.Integer))
    users = sa.table("users", sa.column("relation", sa.String))
    conn = op.get_bind()
    family_ids = [row[0] for row in conn.execute(sa.select(families.c.id))]
    if family_ids:
        op.bulk_insert(relations, [{"family_id": fid, "name": n} for fid in family_ids for n in DEFAULT_RELATIONS])
    conn.execute(
        sa.update(users).where(users.c.relation.is_not(None)).values(relation=sa.func.initcap(users.c.relation))
    )


def downgrade() -> None:
    op.drop_table("relations")