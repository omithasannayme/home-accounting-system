"""income types

Revision ID: 0005
Revises: 0004
"""
import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

DEFAULT_TYPES = ["Salary", "Business income", "Personal income", "Income from family member"]
OLD_KEYS = {
    "salary": "Salary",
    "business": "Business income",
    "personal": "Personal income",
    "family_member": "Income from family member",
}


def upgrade() -> None:
    income_types = op.create_table(
        "income_types",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("family_id", sa.Integer, sa.ForeignKey("families.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(80), nullable=False),
        sa.UniqueConstraint("family_id", "name", name="uq_income_types_family_name"),
    )
    op.alter_column("incomes", "income_type", type_=sa.String(80), existing_type=sa.String(30), existing_nullable=False)

    families = sa.table("families", sa.column("id", sa.Integer))
    incomes = sa.table("incomes", sa.column("income_type", sa.String))
    conn = op.get_bind()

    family_ids = [row[0] for row in conn.execute(sa.select(families.c.id))]
    if family_ids:
        op.bulk_insert(income_types, [{"family_id": fid, "name": n} for fid in family_ids for n in DEFAULT_TYPES])
    for key, name in OLD_KEYS.items():
        conn.execute(sa.update(incomes).where(incomes.c.income_type == key).values(income_type=name))


def downgrade() -> None:
    op.drop_table("income_types")