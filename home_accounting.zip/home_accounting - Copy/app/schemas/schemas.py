from datetime import date
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field

Relation = Literal["father", "mother", "brother", "sister", "daughter", "son", "child", "other"]
IncomeType = Literal["salary", "business", "personal", "family_member"]
ShareType = Literal["member", "family", "bank", "other"]
Kind = Literal["income", "family_share", "savings"]
Money = Annotated[Decimal, Field(gt=0, max_digits=14, decimal_places=2)]
Password = Annotated[str, Field(min_length=10, max_length=128)]
Period = Annotated[str, Field(pattern=r"^\d{4}-(0[1-9]|1[0-2])$")]


class RegisterFamily(BaseModel):
    family_name: str = Field(min_length=1, max_length=120)
    full_name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: Password
    relation: Relation = "father"


class LoginIn(BaseModel):
    email: str = Field(max_length=255)
    password: str = Field(max_length=128)


class RefreshIn(BaseModel):
    refresh_token: str


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class PermissionsIO(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    can_view_family_reports: bool = False
    can_manage_income: bool = False
    can_use_family_ai: bool = False


class MemberCreate(BaseModel):
    full_name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: Password
    relation: str = Field(default="Child", min_length=1, max_length=80)
    permissions: PermissionsIO = PermissionsIO()


class MemberUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=1, max_length=120)
    email: EmailStr | None = None
    relation: str | None = Field(default=None, min_length=1, max_length=80)
    is_active: bool | None = None
    password: Password | None = None
    permissions: PermissionsIO | None = None

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    full_name: str
    email: str
    role: str
    relation: str | None = None
    is_active: bool
    permissions: PermissionsIO | None = None


class MeOut(UserOut):
    family_name: str | None = None


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class CategoryOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str


class IncomeIn(BaseModel):
    income_type: str = Field(min_length=1, max_length=80)
    amount: Money
    description: str | None = Field(default=None, max_length=255)
    income_date: date
    user_id: int | None = None
    share_type: ShareType = "member"
    share_note: str | None = Field(default=None, max_length=255)
    kind: Kind = "income"


class IncomeRow(BaseModel):
    id: int
    income_type: str
    amount: Decimal
    description: str | None
    income_date: date
    user_id: int | None
    user_name: str | None
    share_type: str
    share_note: str | None
    can_edit: bool
    kind: str

class ExpenseIn(BaseModel):
    category_id: int
    amount: Money
    purpose: str = Field(min_length=1, max_length=255)
    where: str | None = Field(default=None, max_length=160)
    expense_date: date
    user_id: int | None = None
    from_allowance: bool | None = None
    for_user_id: int | None = None
    source: Literal["budget", "allowance", "income"] | None = None


class ExpenseRow(BaseModel):
    id: int
    user_id: int
    user_name: str
    category_id: int
    category: str
    for_user_id: int | None
    for_name: str | None
    amount: Decimal
    purpose: str
    where: str | None
    expense_date: date
    can_edit: bool
    source: str


class ExpenseCreated(BaseModel):
    id: int
    ai_feedback: str


class AllowanceIn(BaseModel):
    user_id: int
    amount: Money
    period: Period
    note: str | None = Field(default=None, max_length=255)


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=500)


class ChatOut(BaseModel):
    reply: str
    scope: str


class PlatformFamilyUpdate(BaseModel):
    is_active: bool | None = None
    plan: str | None = Field(default=None, max_length=30)