import re
from datetime import date, timedelta

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, aliased

from app.models.models import ROLE_ADMIN, ROLE_MEMBER, Allowance, Category, Expense, Family, Income, User
from app.services.finance_service import allowance_status

KIND_LABEL = {"income": "income", "family_share": "family share", "savings": "savings"}


def _month_range(d: date) -> tuple[date, date]:
    start = d.replace(day=1)
    end = (start.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    return start, end


def _r(v):
    f = round(float(v or 0), 2)
    return int(f) if f == int(f) else f


def _nonzero(d: dict) -> dict:
    return {k: v for k, v in d.items() if v}

STOP_WORDS = set(
    "a an the is are was were be been am i me my we our us you your he she it they them his her its their "
    "how what when where which who whom why much many total amount sum paid pay pays paying spent spend spends "
    "spending cost costs did do does done for of in on at to from by with and or but this that these those last "
    "next current month months year years today yesterday tomorrow week all any each every show tell give list "
    "please can could would should will tk taka bdt money income expense expenses allowance savings budget "
    "balance family families member members".split()
)


def _keywords(question: str | None) -> list[str]:
    if not question:
        return []
    out: list[str] = []
    for w in re.findall(r"[^\W_]+", question.lower()):
        if w in STOP_WORDS or w.isdigit() or len(w) < (3 if w.isascii() else 2) or w in out:
            continue
        out.append(w)
    return out[:5]


def _money_text(v) -> str:
    f = float(v or 0)
    return f"{f:,.0f} Tk" if f == int(f) else f"{f:,.2f} Tk"


def _best(rows, text_of, kws):
    scored = [(sum(1 for k in kws if k in text_of(r).lower()), r) for r in rows]
    top = max((s for s, _ in scored), default=0)
    return [r for s, r in scored if s == top and s > 0]


def _matches(db: Session, fam: int, question: str | None) -> dict:
    """Exact records (all dates) that match the words of the question, with a ready total."""
    kws = _keywords(question)
    if not kws:
        return {}
    pat = [f"%{k}%" for k in kws]
    ForUser = aliased(User)
    exp_rows = db.execute(
        select(Expense, User.full_name, Category.name, ForUser.full_name)
        .join(User, User.id == Expense.user_id)
        .join(Category, Category.id == Expense.category_id)
        .outerjoin(ForUser, ForUser.id == Expense.for_user_id)
        .where(Expense.family_id == fam,
               or_(*[or_(Expense.purpose.ilike(p), Category.name.ilike(p)) for p in pat]))
        .order_by(Expense.expense_date.desc(), Expense.id.desc()).limit(200)
    ).all()
    exp_best = _best(exp_rows, lambda r: f"{r[0].purpose} {r[2]}", kws)

    inc_rows = db.execute(
        select(Income, User.full_name).outerjoin(User, User.id == Income.user_id)
        .where(Income.family_id == fam,
               or_(*[or_(Income.description.ilike(p), Income.income_type.ilike(p)) for p in pat]))
        .order_by(Income.income_date.desc(), Income.id.desc()).limit(200)
    ).all()
    inc_best = _best(inc_rows, lambda r: f"{r[0].description or ''} {r[0].income_type}", kws)

    al_rows = db.execute(
        select(Allowance, User.full_name).join(User, User.id == Allowance.user_id)
        .where(Allowance.family_id == fam, or_(*[Allowance.note.ilike(p) for p in pat]))
        .order_by(Allowance.id.desc()).limit(200)
    ).all()
    al_best = _best(al_rows, lambda r: r[0].note or "", kws)

    found: dict = {}
    if exp_best:
        found["expenses"] = {
            "count": len(exp_best),
            "total": _money_text(sum(r[0].amount for r in exp_best)),
            "items": [{"date": e.expense_date.isoformat(), "who": who, "for": fn or "Family", "category": cat,
                       "purpose": (e.purpose or "")[:40], "amount": _money_text(e.amount)}
                      for e, who, cat, fn in exp_best[:12]],
        }
    if inc_best:
        found["income_entries"] = {
            "count": len(inc_best),
            "total": _money_text(sum(r[0].amount for r in inc_best)),
            "items": [{"date": i.income_date.isoformat(), "member": name or "Family",
                       "kind": KIND_LABEL.get(i.kind, i.kind), "type": i.income_type,
                       "note": (i.description or "")[:40], "amount": _money_text(i.amount)}
                      for i, name in inc_best[:12]],
        }
    if al_best:
        found["allowances"] = {
            "count": len(al_best),
            "total": _money_text(sum(r[0].amount for r in al_best)),
            "items": [{"date": a.created_at.date().isoformat(), "member": name, "month": a.period,
                       "note": (a.note or "")[:40], "amount": _money_text(a.amount)}
                      for a, name in al_best[:12]],
        }
    return {"matches": {"words": kws, **found}} if found else {}

def _period(db: Session, fam: int, start: date, end: date) -> dict:
    def income_sum(kind: str) -> float:
        return _r(db.scalar(select(func.coalesce(func.sum(Income.amount), 0)).where(
            Income.family_id == fam, Income.kind == kind,
            Income.income_date >= start, Income.income_date <= end)))

    income, budget, savings = income_sum("income"), income_sum("family_share"), income_sum("savings")
    al_date = func.date(Allowance.created_at)
    al_conds = [Allowance.family_id == fam, al_date >= start, al_date <= end]
    allowance = _r(db.scalar(select(func.coalesce(func.sum(Allowance.amount), 0)).where(*al_conds)))
    exp_conds = [Expense.family_id == fam, Expense.from_allowance.is_(False),
                 Expense.expense_date >= start, Expense.expense_date <= end]
    other = _r(db.scalar(select(func.coalesce(func.sum(Expense.amount), 0)).where(*exp_conds)))
    expenses = other + allowance
    balance = budget - expenses

    cat_total = func.sum(Expense.amount)
    by_cat = {
        n: _r(t) for n, t in db.execute(
            select(Category.name, cat_total).select_from(Expense)
            .join(Category, Category.id == Expense.category_id)
            .where(*exp_conds).group_by(Category.name)
        ).all()
    }
    if allowance:
        by_cat["Allowance"] = _r(by_cat.get("Allowance", 0) + allowance)

    by_mem: dict[str, float] = {}
    for name, t in db.execute(
        select(User.full_name, func.sum(Expense.amount)).select_from(Expense)
        .join(User, User.id == Expense.user_id).where(*exp_conds).group_by(User.id, User.full_name)
    ).all():
        by_mem[name] = _r(t)
    for name, t in db.execute(
        select(User.full_name, func.sum(Allowance.amount)).select_from(Allowance)
        .join(User, User.id == Allowance.user_id).where(*al_conds).group_by(User.id, User.full_name)
    ).all():
        by_mem[name] = _r(by_mem.get(name, 0) + float(t))

    by_type = {
        n: _r(t) for n, t in db.execute(
            select(Income.income_type, func.sum(Income.amount)).where(
                Income.family_id == fam, Income.kind == "income",
                Income.income_date >= start, Income.income_date <= end)
            .group_by(Income.income_type)
        ).all()
    }
    return {
        "income": income,
        "budget_family_share": budget,
        "allowance_given": allowance,
        "expenses": _r(expenses),
        "balance": _r(balance),
        "savings": savings,
        "total_unspent": _r((income - budget - savings) + balance),
        "expenses_by_category": _nonzero(by_cat),
        "expenses_by_member": _nonzero(by_mem),
        "income_by_type": _nonzero(by_type),
    }


def build_family_summary(db: Session, user: User, question: str | None = None) -> dict:
    """Aggregated data of the user's own family only. Never touches other families."""
    fam = user.family_id
    today = date.today()
    m0, m1 = _month_range(today)
    p0, p1 = _month_range(m0 - timedelta(days=1))
    y0, y1 = date(today.year, 1, 1), date(today.year, 12, 31)
    month = today.strftime("%Y-%m")

    family = db.get(Family, fam)
    people = db.scalars(select(User).where(User.family_id == fam, User.is_active.is_(True)).order_by(User.id)).all()
    members = [{"name": u.full_name, "relation": u.relation,
                "role": "admin" if u.role == ROLE_ADMIN else "member"} for u in people]

    allowances = []
    for u in people:
        if u.role != ROLE_MEMBER:
            continue
        st = allowance_status(db, fam, u.id, month)
        allowances.append({"member": u.full_name, "given": _r(st["given"]), "spent": _r(st["spent"]),
                           "remaining": _r(st["remaining"]), "percent_used": st["percent_used"]})

    recent_allowances = [
        {"date": a.created_at.date().isoformat(), "member": name, "amount": _r(a.amount),
         "month": a.period, "note": a.note}
        for a, name in db.execute(
            select(Allowance, User.full_name).join(User, User.id == Allowance.user_id)
            .where(Allowance.family_id == fam).order_by(Allowance.id.desc()).limit(8)
        ).all()
    ]

    ForUser = aliased(User)
    recent_expenses = [
        {"date": e.expense_date.isoformat(), "who": who, "for": for_name or "Family", "category": cat,
         "purpose": (e.purpose or "")[:40], "amount": _r(e.amount), "where": e.source}
        for e, who, cat, for_name in db.execute(
            select(Expense, User.full_name, Category.name, ForUser.full_name)
            .join(User, User.id == Expense.user_id)
            .join(Category, Category.id == Expense.category_id)
            .outerjoin(ForUser, ForUser.id == Expense.for_user_id)
            .where(Expense.family_id == fam)
            .order_by(Expense.expense_date.desc(), Expense.id.desc()).limit(8)
        ).all()
    ]

    recent_income = [
        {"date": i.income_date.isoformat(), "member": name or "Family", "kind": KIND_LABEL.get(i.kind, i.kind),
         "type": i.income_type, "amount": _r(i.amount)}
        for i, name in db.execute(
            select(Income, User.full_name).outerjoin(User, User.id == Income.user_id)
            .where(Income.family_id == fam)
            .order_by(Income.income_date.desc(), Income.id.desc()).limit(8)
        ).all()
    ]

    return {
        "currency": "Tk",
        "today": today.isoformat(),
        "family": family.name if family else "",
        "asking": user.full_name,
        "members": members,
        "this_month": {"month": month, **_period(db, fam, m0, m1)},
        "last_month": {"month": p0.strftime("%Y-%m"), **_period(db, fam, p0, p1)},
        "this_year": {"year": today.year, **_period(db, fam, y0, y1)},
        "allowance_this_month": allowances,
        "recent_allowances": recent_allowances,
        "recent_expenses": recent_expenses,
        "recent_income": recent_income,
        **_matches(db, fam, question),
    }