import json
import re
from collections.abc import Iterator
from typing import Protocol

import httpx

from app.core.config import settings

UNAVAILABLE = "AI assistant is not available. Make sure Ollama is running and the model is pulled."


class AIProviderError(Exception):
    pass


class AIProvider(Protocol):
    def generate(self, system: str, user: str) -> str: ...
    def stream(self, system: str, user: str) -> Iterator[str]: ...


def _strip_think(chunks: Iterator[str]) -> Iterator[str]:
    """Remove <think>...</think> blocks from a stream of text pieces."""
    buf, in_think = "", False
    for piece in chunks:
        buf += piece
        while True:
            if in_think:
                i = buf.find("</think>")
                if i == -1:
                    buf = buf[-8:]
                    break
                buf, in_think = buf[i + 8:], False
            else:
                i = buf.find("<think>")
                if i == -1:
                    if len(buf) > 7:
                        yield buf[:-7]
                        buf = buf[-7:]
                    break
                if i:
                    yield buf[:i]
                buf, in_think = buf[i + 7:], True
    if buf and not in_think:
        yield buf


class OllamaProvider:
    @staticmethod
    def _payload(system: str, user: str, stream: bool) -> dict:
        return {
            "model": settings.ollama_model,
            "stream": stream,
            "think": False,
            "keep_alive": "10m",
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "options": {"temperature": 0, "num_predict": settings.ai_max_tokens, "num_ctx": 4096},
        }

    def generate(self, system: str, user: str) -> str:
        try:
            r = httpx.post(f"{settings.ollama_base_url}/api/chat", json=self._payload(system, user, False),
                           timeout=settings.ollama_timeout)
            r.raise_for_status()
            text = r.json()["message"]["content"]
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            raise AIProviderError(UNAVAILABLE) from exc
        return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()

    def stream(self, system: str, user: str) -> Iterator[str]:
        def raw() -> Iterator[str]:
            try:
                with httpx.stream("POST", f"{settings.ollama_base_url}/api/chat",
                                  json=self._payload(system, user, True),
                                  timeout=settings.ollama_timeout) as r:
                    r.raise_for_status()
                    for line in r.iter_lines():
                        if not line:
                            continue
                        data = json.loads(line)
                        piece = (data.get("message") or {}).get("content", "")
                        if piece:
                            yield piece
                        if data.get("done"):
                            break
            except (httpx.HTTPError, ValueError) as exc:
                raise AIProviderError(UNAVAILABLE) from exc

        return _strip_think(raw())


def get_provider() -> AIProvider:
    # Future: add "openai", "anthropic" etc. here without touching the rest of the app.
    if settings.ai_provider == "ollama":
        return OllamaProvider()
    raise AIProviderError(f"Unknown AI provider: {settings.ai_provider}")