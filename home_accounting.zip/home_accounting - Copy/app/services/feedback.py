from datetime import timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.models import Expense, User
from app.services.finance_service import (
    allowance_status, month_bounds, previous_month, total_expense,
)


def tk(value) -> str:
    return f"{Decimal(str(value)):,.0f} Tk"


def expense_feedback(db: Session, actor: User, target: User, exp: Expense, category_name: str) -> str:
    """Instant, fact-based feedback. Numbers are computed here, never by the LLM."""
    you = actor.id == target.id
    cat = category_name.lower()
    when = "today" if exp.expense_date == __import__("datetime").date.today() else f"on {exp.expense_date:%d %b %Y}"
    if you:
        parts = [f"You spent {tk(exp.amount)} {when} on {cat}."]
    else:
        parts = [f"Recorded {tk(exp.amount)} {when} on {cat} for {target.full_name}."]

    month = exp.expense_date.strftime("%Y-%m")
    start, end = month_bounds(month)
    pstart, pend = month_bounds(previous_month(month))
    fam = target.family_id
    current = total_expense(db, fam, start, end, user_id=target.id, category_id=exp.category_id)
    previous = total_expense(db, fam, pstart, pend, user_id=target.id, category_id=exp.category_id)
    if previous > 0 and current > previous:
        parts.append(f"{category_name} expenses increased compared to last month "
                     f"({tk(previous)} to {tk(current)}). Consider reviewing your budget.")
    elif previous > 0 and current < previous:
        parts.append(f"{category_name} expenses are still lower than last month. Good job!")

    since = exp.expense_date - timedelta(days=90)
    avg, count = db.execute(
        select(func.avg(Expense.amount), func.count(Expense.id)).where(
            Expense.family_id == fam, Expense.user_id == target.id,
            Expense.expense_date >= since, Expense.id != exp.id,
        )
    ).one()
    if count >= 5 and avg and exp.amount > Decimal(str(avg)) * 2:
        parts.append(f"Note: this is unusually high compared with the average expense of {tk(avg)}.")

    if exp.from_allowance:
        st = allowance_status(db, fam, target.id, month)
        if st["given"] > 0:
            subject = "You have" if you else f"{target.full_name} has"
            owner = "your" if you else "their"
            if st["remaining"] < 0:
                parts.append(f"{subject} exceeded {owner} monthly allowance by {tk(-st['remaining'])}.")
            else:
                parts.append(f"{subject} used {st['percent_used']:.0f}% of {owner} monthly allowance. "
                             f"Remaining balance is {tk(st['remaining'])}.")
    return " ".join(parts)