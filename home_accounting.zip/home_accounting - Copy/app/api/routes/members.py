from fastapi import APIRouter, HTTPException
from sqlalchemy import func, or_, select

from app.api.deps import DB, FamilyAdmin, FamilyUser
from app.core.security import hash_password
from app.models.models import (
    ROLE_MEMBER, Allowance, Expense, Income, MemberPermission, RelationModel, User,
)
from app.schemas.schemas import MemberCreate, MemberUpdate, UserOut

router = APIRouter(prefix="/members", tags=["members"])


def _relation_name(db, admin: User, name: str) -> str:
    found = db.scalar(select(RelationModel.name).where(
        RelationModel.family_id == admin.family_id, RelationModel.name == name.strip()))
    if not found:
        raise HTTPException(404, "Relation not found")
    return found


def _get_member(db, admin: User, member_id: int) -> User:
    member = db.get(User, member_id)
    if not member or member.family_id != admin.family_id or member.role != ROLE_MEMBER:
        raise HTTPException(404, "Member not found")
    return member


@router.get("", response_model=list[UserOut])
def list_members(db: DB, user: FamilyUser):
    return db.scalars(select(User).where(User.family_id == user.family_id).order_by(User.id)).all()

@router.post("", response_model=UserOut, status_code=201)
def create_member(data: MemberCreate, db: DB, admin: FamilyAdmin):
    email = data.email.lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "This email is not available")
    member = User(
        family_id=admin.family_id, full_name=data.full_name.strip(), email=email,
        password_hash=hash_password(data.password), role=ROLE_MEMBER,
        relation=_relation_name(db, admin, data.relation),
    )
    member.permissions = MemberPermission(**data.permissions.model_dump())
    db.add(member)
    db.commit()
    return member


@router.patch("/{member_id}", response_model=UserOut)
def update_member(member_id: int, data: MemberUpdate, db: DB, admin: FamilyAdmin):
    member = _get_member(db, admin, member_id)
    if data.full_name is not None:
        member.full_name = data.full_name.strip()
    if data.email is not None:
        email = data.email.lower()
        if email != member.email:
            if db.scalar(select(User.id).where(User.email == email)):
                raise HTTPException(409, "This email is not available")
            member.email = email
    if data.relation is not None:
        member.relation = _relation_name(db, admin, data.relation)
    if data.is_active is not None:
        member.is_active = data.is_active
    if data.password:
        member.password_hash = hash_password(data.password)
    if data.permissions is not None:
        if member.permissions is None:
            member.permissions = MemberPermission()
        for key, value in data.permissions.model_dump().items():
            setattr(member.permissions, key, value)
    db.commit()
    return member


@router.delete("/{member_id}", status_code=204)
def delete_member(member_id: int, db: DB, admin: FamilyAdmin):
    member = _get_member(db, admin, member_id)
    records = (
        db.scalar(select(func.count(Expense.id)).where(
            or_(Expense.user_id == member.id, Expense.for_user_id == member.id)))
        + db.scalar(select(func.count(Income.id)).where(
            or_(Income.user_id == member.id, Income.created_by == member.id)))
        + db.scalar(select(func.count(Allowance.id)).where(Allowance.user_id == member.id))
    )
    if records:
        raise HTTPException(409, "This member has financial records and cannot be deleted. Disable the account instead.")
    db.delete(member)
    db.commit()