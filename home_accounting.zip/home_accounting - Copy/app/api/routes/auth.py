import time

from fastapi import APIRouter, HTTPException, Request
from sqlalchemy import select

from app.api.deps import DB, CurrentUser
from datetime import datetime, timedelta, timezone

from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
    create_reset_token,
)
from app.models.models import (
    DEFAULT_CATEGORIES, DEFAULT_INCOME_TYPES, DEFAULT_RELATIONS, ROLE_ADMIN,
    Category, Family, IncomeTypeModel, RelationModel, User,
)
from app.schemas.schemas import LoginIn, MeOut, RefreshIn, RegisterFamily, TokenOut

router = APIRouter(prefix="/auth", tags=["auth"])

_attempts: dict[str, list[float]] = {}
_DUMMY_HASH = hash_password("dummy-password-for-timing")


def _tokens(user_id: int) -> TokenOut:
    return TokenOut(access_token=create_access_token(user_id), refresh_token=create_refresh_token(user_id))


def _check_rate(key: str) -> None:
    now = time.time()
    recent = [t for t in _attempts.get(key, []) if now - t < 300]
    _attempts[key] = recent
    if len(recent) >= 5:
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")


@router.post("/register-family", response_model=TokenOut, status_code=201)
def register_family(data: RegisterFamily, db: DB):
    email = data.email.lower()
    if db.scalar(select(User.id).where(User.email == email)):
        raise HTTPException(409, "This email is not available")
    family = Family(name=data.family_name.strip())
    db.add(family)
    db.flush()
    user = User(
        family_id=family.id, full_name=data.full_name.strip(), email=email,
        password_hash=hash_password(data.password), role=ROLE_ADMIN, relation=data.relation.capitalize(),
    )
    db.add(user)
    db.add_all(Category(family_id=family.id, name=n) for n in DEFAULT_CATEGORIES)
    db.add_all(IncomeTypeModel(family_id=family.id, name=n) for n in DEFAULT_INCOME_TYPES)
    db.add_all(RelationModel(family_id=family.id, name=n) for n in DEFAULT_RELATIONS)
    db.commit()
    return _tokens(user.id)


@router.post("/login", response_model=TokenOut)
def login(data: LoginIn, request: Request, db: DB):
    email = data.email.strip().lower()
    key = f"{request.client.host if request.client else 'unknown'}:{email}"
    _check_rate(key)
    user = db.scalar(select(User).where(User.email == email))
    ok = verify_password(data.password, user.password_hash if user else _DUMMY_HASH)
    if not (user and ok and user.is_active):
        _attempts.setdefault(key, []).append(time.time())
        raise HTTPException(401, "Invalid email or password")
    _attempts.pop(key, None)
    return _tokens(user.id)


@router.post("/refresh", response_model=TokenOut)
def refresh(data: RefreshIn, db: DB):
    uid = decode_token(data.refresh_token, "refresh")
    user = db.get(User, uid) if uid else None
    if not user or not user.is_active:
        raise HTTPException(401, "Invalid refresh token")
    return _tokens(user.id)


@router.get("/me", response_model=MeOut)
def me(user: CurrentUser):
    out = MeOut.model_validate(user)
    out.family_name = user.family.name if user.family else None
    return out

@router.post("/forgot-password")
def forgot_password(email: str, db: DB):

    user = db.scalar(
        select(User).where(
            User.email == email.lower()
        )
    )


    # Security:
    # Do not reveal if email exists

    if not user:
        return {
            "message":
            "If this email exists, reset instructions have been sent."
        }


    user.reset_token = create_reset_token()

    user.reset_token_expire = (
        datetime.now(timezone.utc)
        +
        timedelta(minutes=30)
    )


    db.commit()


    # Later:
    # Send email here

    return {
        "message":
        "Password reset instructions have been sent."
    }

@router.post("/reset-password")
def reset_password(
    token: str,
    new_password: str,
    db: DB
):

    user = db.scalar(
        select(User).where(
            User.reset_token == token
        )
    )


    if not user:
        raise HTTPException(
            400,
            "Invalid reset token"
        )


    if (
        not user.reset_token_expire
        or user.reset_token_expire <
        datetime.now(timezone.utc)
    ):
        raise HTTPException(
            400,
            "Reset token expired"
        )


    user.password_hash = hash_password(
        new_password
    )


    user.reset_token = None
    user.reset_token_expire = None


    db.commit()


    return {
        "message":
        "Password changed successfully"
    }