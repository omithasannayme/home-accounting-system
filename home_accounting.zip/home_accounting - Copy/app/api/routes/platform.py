from fastapi import APIRouter, HTTPException
from sqlalchemy import delete, func, select

from app.api.deps import DB, SuperAdmin
from app.models.models import (
    Allowance, Category, Expense, Family, Income, IncomeTypeModel, MemberPermission, RelationModel, User,
)
from app.schemas.schemas import PlatformFamilyUpdate

router = APIRouter(prefix="/platform", tags=["platform"])


@router.get("/families")
def list_families(db: DB, _: SuperAdmin):
    rows = db.execute(
        select(Family, func.count(User.id))
        .outerjoin(User, User.family_id == Family.id)
        .group_by(Family.id)
        .order_by(Family.id)
    ).all()
    return [
        {"id": f.id, "name": f.name, "plan": f.plan, "is_active": f.is_active,
         "members": count, "created_at": f.created_at.isoformat()}
        for f, count in rows
    ]


@router.patch("/families/{family_id}")
def update_family(family_id: int, data: PlatformFamilyUpdate, db: DB, _: SuperAdmin):
    family = db.get(Family, family_id)
    if not family:
        raise HTTPException(404, "Family not found")
    if data.is_active is not None:
        family.is_active = data.is_active
    if data.plan is not None:
        family.plan = data.plan
    db.commit()
    return {"id": family.id, "is_active": family.is_active, "plan": family.plan}


@router.delete("/families/{family_id}", status_code=204)
def delete_family(family_id: int, db: DB, _: SuperAdmin):
    if not db.scalar(select(Family.id).where(Family.id == family_id)):
        raise HTTPException(404, "Family not found")
    for model in (Expense, Income, Allowance, IncomeTypeModel, RelationModel):
        db.execute(delete(model).where(model.family_id == family_id))
    member_ids = select(User.id).where(User.family_id == family_id)
    db.execute(delete(MemberPermission).where(MemberPermission.user_id.in_(member_ids)))
    db.execute(delete(Category).where(Category.family_id == family_id))
    db.execute(delete(User).where(User.family_id == family_id))
    db.execute(delete(Family).where(Family.id == family_id))
    db.commit()