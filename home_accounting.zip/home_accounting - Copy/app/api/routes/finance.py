from fastapi import APIRouter, HTTPException
from sqlalchemy import func, or_, select, update
from sqlalchemy.orm import aliased

from app.api.deps import DB, FamilyAdmin, FamilyUser, MonthQ, ScopeQ
from app.core.permissions import can_manage_income, can_view_family_reports
from app.models.models import (
    ROLE_ADMIN, ROLE_MEMBER, Allowance, Category, Expense, Income, IncomeTypeModel, RelationModel, User,
)
from app.schemas.schemas import (
    AllowanceIn, CategoryIn, CategoryOut, ExpenseCreated, ExpenseIn, ExpenseRow, IncomeIn, IncomeRow,
)
from app.services.feedback import expense_feedback
from app.services.finance_service import (
    allowance_status, current_month, expense_by_category, month_bounds,
)

router = APIRouter(tags=["finance"])


def _family_user(db, actor: User, user_id: int) -> User:
    u = db.get(User, user_id)
    if not u or u.family_id != actor.family_id or not u.is_active:
        raise HTTPException(404, "Member not found")
    return u


# ---------- categories ----------
@router.get("/categories", response_model=list[CategoryOut])
def list_categories(db: DB, user: FamilyUser):
    return db.scalars(select(Category).where(Category.family_id == user.family_id).order_by(Category.name)).all()


@router.post("/categories", response_model=CategoryOut, status_code=201)
def create_category(data: CategoryIn, db: DB, admin: FamilyAdmin):
    name = data.name.strip()
    exists = db.scalar(select(Category.id).where(
        Category.family_id == admin.family_id, func.lower(Category.name) == name.lower()))
    if exists:
        raise HTTPException(409, "Category already exists")
    cat = Category(family_id=admin.family_id, name=name)
    db.add(cat)
    db.commit()
    return cat

@router.put("/categories/{category_id}", response_model=CategoryOut)
def rename_category(category_id: int, data: CategoryIn, db: DB, admin: FamilyAdmin):
    cat = db.get(Category, category_id)
    if not cat or cat.family_id != admin.family_id:
        raise HTTPException(404, "Category not found")
    name = data.name.strip()
    dup = db.scalar(select(Category.id).where(
        Category.family_id == admin.family_id, func.lower(Category.name) == name.lower(), Category.id != cat.id))
    if dup:
        raise HTTPException(409, "Category already exists")
    cat.name = name
    db.commit()
    return cat


@router.delete("/categories/{category_id}", status_code=204)
def delete_category(category_id: int, db: DB, admin: FamilyAdmin):
    cat = db.get(Category, category_id)
    if not cat or cat.family_id != admin.family_id:
        raise HTTPException(404, "Category not found")
    used = db.scalar(select(func.count(Expense.id)).where(Expense.category_id == cat.id))
    if used:
        raise HTTPException(409, f"This category is used by {used} expense(s). Change or delete those first.")
    db.delete(cat)
    db.commit()

# ---------- income types ----------
@router.get("/income-types", response_model=list[CategoryOut])
def list_income_types(db: DB, user: FamilyUser):
    return db.scalars(
        select(IncomeTypeModel).where(IncomeTypeModel.family_id == user.family_id).order_by(IncomeTypeModel.name)
    ).all()


@router.post("/income-types", response_model=CategoryOut, status_code=201)
def create_income_type(data: CategoryIn, db: DB, admin: FamilyAdmin):
    name = data.name.strip()
    exists = db.scalar(select(IncomeTypeModel.id).where(
        IncomeTypeModel.family_id == admin.family_id, func.lower(IncomeTypeModel.name) == name.lower()))
    if exists:
        raise HTTPException(409, "Income type already exists")
    item = IncomeTypeModel(family_id=admin.family_id, name=name)
    db.add(item)
    db.commit()
    return item


@router.put("/income-types/{type_id}", response_model=CategoryOut)
def rename_income_type(type_id: int, data: CategoryIn, db: DB, admin: FamilyAdmin):
    item = db.get(IncomeTypeModel, type_id)
    if not item or item.family_id != admin.family_id:
        raise HTTPException(404, "Income type not found")
    name = data.name.strip()
    dup = db.scalar(select(IncomeTypeModel.id).where(
        IncomeTypeModel.family_id == admin.family_id, func.lower(IncomeTypeModel.name) == name.lower(),
        IncomeTypeModel.id != item.id))
    if dup:
        raise HTTPException(409, "Income type already exists")
    old = item.name
    item.name = name
    db.execute(update(Income).where(Income.family_id == admin.family_id, Income.income_type == old)
               .values(income_type=name))
    db.commit()
    return item


@router.delete("/income-types/{type_id}", status_code=204)
def delete_income_type(type_id: int, db: DB, admin: FamilyAdmin):
    item = db.get(IncomeTypeModel, type_id)
    if not item or item.family_id != admin.family_id:
        raise HTTPException(404, "Income type not found")
    used = db.scalar(select(func.count(Income.id)).where(
        Income.family_id == admin.family_id, Income.income_type == item.name))
    if used:
        raise HTTPException(409, f"This income type is used by {used} entr{'y' if used == 1 else 'ies'}. Change or delete those first.")
    db.delete(item)
    db.commit()

# ---------- relations ----------
@router.get("/relations", response_model=list[CategoryOut])
def list_relations(db: DB, admin: FamilyAdmin):
    return db.scalars(
        select(RelationModel).where(RelationModel.family_id == admin.family_id).order_by(RelationModel.id)
    ).all()


@router.post("/relations", response_model=CategoryOut, status_code=201)
def create_relation(data: CategoryIn, db: DB, admin: FamilyAdmin):
    name = data.name.strip()
    exists = db.scalar(select(RelationModel.id).where(
        RelationModel.family_id == admin.family_id, func.lower(RelationModel.name) == name.lower()))
    if exists:
        raise HTTPException(409, "Relation already exists")
    item = RelationModel(family_id=admin.family_id, name=name)
    db.add(item)
    db.commit()
    return item


@router.put("/relations/{relation_id}", response_model=CategoryOut)
def rename_relation(relation_id: int, data: CategoryIn, db: DB, admin: FamilyAdmin):
    item = db.get(RelationModel, relation_id)
    if not item or item.family_id != admin.family_id:
        raise HTTPException(404, "Relation not found")
    name = data.name.strip()
    dup = db.scalar(select(RelationModel.id).where(
        RelationModel.family_id == admin.family_id, func.lower(RelationModel.name) == name.lower(),
        RelationModel.id != item.id))
    if dup:
        raise HTTPException(409, "Relation already exists")
    old = item.name
    item.name = name
    db.execute(update(User).where(User.family_id == admin.family_id, User.relation == old).values(relation=name))
    db.commit()
    return item


@router.delete("/relations/{relation_id}", status_code=204)
def delete_relation(relation_id: int, db: DB, admin: FamilyAdmin):
    item = db.get(RelationModel, relation_id)
    if not item or item.family_id != admin.family_id:
        raise HTTPException(404, "Relation not found")
    used = db.scalar(select(func.count(User.id)).where(
        User.family_id == admin.family_id, User.relation == item.name))
    if used:
        raise HTTPException(409, f"This relation is used by {used} member(s). Change those first.")
    db.delete(item)
    db.commit()

# ---------- income ----------
def _can_edit_income(user: User, inc: Income) -> bool:
    return user.role == ROLE_ADMIN or (inc.created_by == user.id and can_manage_income(user))


def _resolve_share(db, user: User, data: IncomeIn) -> tuple[int | None, str, str | None]:
    note = (data.share_note or "").strip() or None
    if data.share_type == "member":
        target = data.user_id if data.user_id is not None else user.id
        if target != user.id:
            if user.role != ROLE_ADMIN:
                raise HTTPException(403, "Not allowed")
            target = _family_user(db, user, target).id
        return target, "member", None
    if data.share_type == "family":
        if user.role != ROLE_ADMIN:
            raise HTTPException(403, "Only the family admin can record shared family income")
        return None, "family", None
    if data.share_type == "other" and not note:
        raise HTTPException(422, "Please add a description for 'Others'")
    return user.id, data.share_type, note if data.share_type == "other" else None


@router.get("/people")
def list_people(db: DB, user: FamilyUser):
    if not can_view_family_reports(user):
        raise HTTPException(403, "Not allowed")
    rows = db.execute(
        select(User.id, User.full_name)
        .where(User.family_id == user.family_id, User.is_active.is_(True))
        .order_by(User.id)
    ).all()
    return [{"id": i, "name": n} for i, n in rows]

def _income_type_name(db, user: User, name: str) -> str:
    found = db.scalar(select(IncomeTypeModel.name).where(
        IncomeTypeModel.family_id == user.family_id, IncomeTypeModel.name == name.strip()))
    if not found:
        raise HTTPException(404, "Income type not found")
    return found

@router.post("/incomes", status_code=201)
def add_income(data: IncomeIn, db: DB, user: FamilyUser):
    if not can_manage_income(user):
        raise HTTPException(403, "You are not allowed to record income")
    owner_id, share_type, note = _resolve_share(db, user, data)
    income = Income(
        family_id=user.family_id, user_id=owner_id, income_type=_income_type_name(db, user, data.income_type), amount=data.amount,
        description=data.description, income_date=data.income_date, created_by=user.id,
        share_type=share_type, share_note=note, kind=data.kind,
    )
    db.add(income)
    db.commit()
    return {"id": income.id}


@router.put("/incomes/{income_id}")
def update_income(income_id: int, data: IncomeIn, db: DB, user: FamilyUser):
    inc = db.get(Income, income_id)
    if not inc or inc.family_id != user.family_id:
        raise HTTPException(404, "Income not found")
    if not _can_edit_income(user, inc):
        raise HTTPException(403, "You cannot edit this entry")
    owner_id, share_type, note = _resolve_share(db, user, data)
    inc.user_id = owner_id
    inc.income_type = _income_type_name(db, user, data.income_type)
    inc.amount = data.amount
    inc.description = data.description
    inc.income_date = data.income_date
    inc.share_type = share_type
    inc.share_note = note
    inc.kind = data.kind
    db.commit()
    return {"id": inc.id}

@router.delete("/incomes/{income_id}", status_code=204)
def delete_income(income_id: int, db: DB, user: FamilyUser):
    inc = db.get(Income, income_id)
    if not inc or inc.family_id != user.family_id:
        raise HTTPException(404, "Income not found")
    if not _can_edit_income(user, inc):
        raise HTTPException(403, "You cannot delete this entry")
    db.delete(inc)
    db.commit()

@router.get("/incomes", response_model=list[IncomeRow])
def list_incomes(db: DB, user: FamilyUser, month: MonthQ = None, scope: ScopeQ = "personal",
                 user_id: int | None = None):
    start, end = month_bounds(month or current_month())
    q = (
        select(Income, User.full_name)
        .outerjoin(User, User.id == Income.user_id)
        .where(Income.family_id == user.family_id, Income.income_date >= start, Income.income_date < end)
        .order_by(Income.income_date.desc(), Income.id.desc())
        .limit(200)
    )
    if scope == "family":
        if not can_view_family_reports(user):
            raise HTTPException(403, "Not allowed")
        if user_id is not None:
            q = q.where(Income.user_id == user_id)
    else:
        q = q.where(Income.user_id == user.id)
    return [
        IncomeRow(id=i.id, income_type=i.income_type, amount=i.amount, description=i.description,
                  income_date=i.income_date, user_id=i.user_id, user_name=name,
                  share_type=i.share_type, share_note=i.share_note, kind=i.kind, can_edit=_can_edit_income(user, i))
        for i, name in db.execute(q).all()
    ]

# ---------- expenses ----------
def _can_edit_expense(user: User, exp: Expense) -> bool:
    return user.role == ROLE_ADMIN or exp.user_id == user.id


def _expense_refs(db, user: User, data: ExpenseIn):
    target = user
    if data.user_id is not None and data.user_id != user.id:
        if user.role != ROLE_ADMIN:
            raise HTTPException(403, "Not allowed")
        target = _family_user(db, user, data.user_id)
    cat = db.get(Category, data.category_id)
    if not cat or cat.family_id != user.family_id:
        raise HTTPException(404, "Category not found")
    for_id = _family_user(db, user, data.for_user_id).id if data.for_user_id is not None else None
    return target, cat, for_id

def _expense_source(user: User, target: User, data: ExpenseIn) -> str:
    source = data.source or ("allowance" if target.role == ROLE_MEMBER else "budget")
    if source == "income" and user.role != ROLE_ADMIN:
        raise HTTPException(403, "Only the family admin can use Income as the source")
    if source == "allowance" and target.role != ROLE_MEMBER:
        raise HTTPException(400, "Allowance can only be used for family members")
    return source


@router.post("/expenses", response_model=ExpenseCreated, status_code=201)
def add_expense(data: ExpenseIn, db: DB, user: FamilyUser):
    target, cat, for_id = _expense_refs(db, user, data)
    source = _expense_source(user, target, data)
    exp = Expense(
        family_id=user.family_id, user_id=target.id, category_id=cat.id, for_user_id=for_id,
        amount=data.amount, purpose=data.purpose.strip(), place=data.where,
        expense_date=data.expense_date, source=source, from_allowance=(source == "allowance"),
    )
    db.add(exp)
    db.commit()
    db.refresh(exp)
    return {"id": exp.id, "ai_feedback": expense_feedback(db, user, target, exp, cat.name)}


@router.put("/expenses/{expense_id}")
def update_expense(expense_id: int, data: ExpenseIn, db: DB, user: FamilyUser):
    exp = db.get(Expense, expense_id)
    if not exp or exp.family_id != user.family_id:
        raise HTTPException(404, "Expense not found")
    if not _can_edit_expense(user, exp):
        raise HTTPException(403, "You cannot edit this entry")
    target, cat, for_id = _expense_refs(db, user, data)
    source = _expense_source(user, target, data)
    exp.user_id = target.id
    exp.category_id = cat.id
    exp.for_user_id = for_id
    exp.amount = data.amount
    exp.purpose = data.purpose.strip()
    exp.place = data.where
    exp.expense_date = data.expense_date
    exp.source = source
    exp.from_allowance = source == "allowance"
    db.commit()
    return {"id": exp.id}

@router.delete("/expenses/{expense_id}", status_code=204)
def delete_expense(expense_id: int, db: DB, user: FamilyUser):
    exp = db.get(Expense, expense_id)
    if not exp or exp.family_id != user.family_id:
        raise HTTPException(404, "Expense not found")
    if not _can_edit_expense(user, exp):
        raise HTTPException(403, "You cannot delete this entry")
    db.delete(exp)
    db.commit()


@router.get("/expenses", response_model=list[ExpenseRow])
def list_expenses(db: DB, user: FamilyUser, month: MonthQ = None, scope: ScopeQ = "personal"):
    start, end = month_bounds(month or current_month())
    ForUser = aliased(User)
    q = (
        select(Expense, User.full_name, Category.name, ForUser.full_name)
        .join(User, User.id == Expense.user_id)
        .join(Category, Category.id == Expense.category_id)
        .outerjoin(ForUser, ForUser.id == Expense.for_user_id)
        .where(Expense.family_id == user.family_id, Expense.expense_date >= start, Expense.expense_date < end)
        .order_by(Expense.expense_date.desc(), Expense.id.desc())
        .limit(300)
    )
    if can_view_family_reports(user):
        if scope == "personal":
            q = q.where(Expense.for_user_id.is_not(None))
    else:
        if scope == "family":
            raise HTTPException(403, "Not allowed")
        q = q.where(or_(Expense.user_id == user.id, Expense.for_user_id == user.id))
    return [
        ExpenseRow(id=e.id, user_id=e.user_id, user_name=who, category_id=e.category_id, category=cat,
                   for_user_id=e.for_user_id, for_name=for_name, amount=e.amount, purpose=e.purpose, where=e.place,
                   expense_date=e.expense_date, source=e.source, can_edit=_can_edit_expense(user, e))
        for e, who, cat, for_name in db.execute(q).all()
    ]

# ---------- allowances ----------
@router.post("/allowances", status_code=201)
def give_allowance(data: AllowanceIn, db: DB, admin: FamilyAdmin):
    member = _family_user(db, admin, data.user_id)
    allowance = Allowance(
        family_id=admin.family_id, user_id=member.id, amount=data.amount, period=data.period,
        note=data.note, given_by=admin.id,
    )
    db.add(allowance)
    db.commit()
    return {"id": allowance.id}

@router.get("/allowances/overview")
def allowance_overview(db: DB, user: FamilyUser, month: MonthQ = None):
    month = month or current_month()
    members = db.scalars(select(User).where(
        User.family_id == user.family_id, User.role == ROLE_MEMBER, User.is_active.is_(True)
    ).order_by(User.id)).all()
    out = []
    for m in members:
        st = allowance_status(db, user.family_id, m.id, month)
        out.append({"user_id": m.id, "name": m.full_name, **{k: float(v) for k, v in st.items()}})
    return out


@router.get("/allowances")
def list_allowances(db: DB, user: FamilyUser, month: MonthQ = None):
    month = month or current_month()
    rows = db.execute(
        select(Allowance, User.full_name)
        .join(User, User.id == Allowance.user_id)
        .where(Allowance.family_id == user.family_id, Allowance.period == month)
        .order_by(Allowance.created_at.desc(), Allowance.id.desc())
    ).all()
    return [
        {"id": a.id, "user_id": a.user_id, "user_name": name, "period": a.period,
         "amount": float(a.amount), "note": a.note, "date": a.created_at.date().isoformat()}
        for a, name in rows
    ]

@router.put("/allowances/{allowance_id}")
def update_allowance(allowance_id: int, data: AllowanceIn, db: DB, admin: FamilyAdmin):
    a = db.get(Allowance, allowance_id)
    if not a or a.family_id != admin.family_id:
        raise HTTPException(404, "Allowance not found")
    member = _family_user(db, admin, data.user_id)
    a.user_id = member.id
    a.amount = data.amount
    a.period = data.period
    a.note = data.note
    db.commit()
    return {"id": a.id}


@router.delete("/allowances/{allowance_id}", status_code=204)
def delete_allowance(allowance_id: int, db: DB, admin: FamilyAdmin):
    a = db.get(Allowance, allowance_id)
    if not a or a.family_id != admin.family_id:
        raise HTTPException(404, "Allowance not found")
    db.delete(a)
    db.commit()

