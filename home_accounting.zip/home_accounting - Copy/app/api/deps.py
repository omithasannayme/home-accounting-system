from typing import Annotated, Literal

from fastapi import Depends, HTTPException, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import decode_token
from app.db.session import get_db
from app.models.models import ROLE_ADMIN, ROLE_SUPER, Family, User

bearer = HTTPBearer(auto_error=False)

MONTH_PATTERN = r"^\d{4}-(0[1-9]|1[0-2])$"
DB = Annotated[Session, Depends(get_db)]
MonthQ = Annotated[str | None, Query(pattern=MONTH_PATTERN)]
ScopeQ = Literal["personal", "family"]


def get_current_user(
    db: DB, creds: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]
) -> User:
    if creds is None:
        raise HTTPException(401, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
    uid = decode_token(creds.credentials, "access")
    user = db.get(User, uid) if uid else None
    if not user or not user.is_active:
        raise HTTPException(401, "Invalid or expired token", headers={"WWW-Authenticate": "Bearer"})
    if user.family_id is not None:
        family = db.get(Family, user.family_id)
        if not family or not family.is_active:
            raise HTTPException(403, "This family account is suspended")
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def get_family_user(user: CurrentUser) -> User:
    if user.role == ROLE_SUPER or user.family_id is None:
        raise HTTPException(404, "Not found")
    return user


FamilyUser = Annotated[User, Depends(get_family_user)]


def get_family_admin(user: FamilyUser) -> User:
    if user.role != ROLE_ADMIN:
        raise HTTPException(403, "Family admin only")
    return user


FamilyAdmin = Annotated[User, Depends(get_family_admin)]


def get_super_admin(user: CurrentUser) -> User:
    if user.role != ROLE_SUPER:
        raise HTTPException(404, "Not found")  # hide the platform area completely
    return user


SuperAdmin = Annotated[User, Depends(get_super_admin)]