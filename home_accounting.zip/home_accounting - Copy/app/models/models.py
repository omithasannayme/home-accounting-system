from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Numeric,
    String,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base

ROLE_SUPER = "super_admin"
ROLE_ADMIN = "family_admin"
ROLE_MEMBER = "family_member"

DEFAULT_CATEGORIES = [
    "Food & Groceries", "Shopping", "Transport", "Education", "Health",
    "Utilities", "Rent", "Entertainment", "Other",
]

DEFAULT_INCOME_TYPES = ["Salary", "Business income", "Personal income", "Income from family member"]
DEFAULT_RELATIONS = ["Father", "Mother", "Brother", "Sister", "Daughter", "Son", "Child", "Other"]
class Family(Base):
    __tablename__ = "families"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    plan: Mapped[str] = mapped_column(String(30), default="free", server_default="free")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class User(Base):
    __tablename__ = "users"
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )
    reset_token: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        index=True
    )

    reset_token_expire: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int | None] = mapped_column(
        ForeignKey("families.id", ondelete="CASCADE"), index=True
    )
    full_name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30))
    relation: Mapped[str | None] = mapped_column(String(80))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    family: Mapped["Family | None"] = relationship()
    permissions: Mapped["MemberPermission | None"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )


class MemberPermission(Base):
    __tablename__ = "member_permissions"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    can_view_family_reports: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    can_manage_income: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    can_use_family_ai: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")

    user: Mapped["User"] = relationship(back_populates="permissions")


class Category(Base):
    __tablename__ = "categories"
    __table_args__ = (UniqueConstraint("family_id", "name", name="uq_categories_family_name"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(80))

class IncomeTypeModel(Base):
    __tablename__ = "income_types"
    __table_args__ = (UniqueConstraint("family_id", "name", name="uq_income_types_family_name"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(80))

class RelationModel(Base):
    __tablename__ = "relations"
    __table_args__ = (UniqueConstraint("family_id", "name", name="uq_relations_family_name"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(80))

class Income(Base):
    __tablename__ = "incomes"
    __table_args__ = (Index("ix_incomes_family_date", "family_id", "income_date"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    income_type: Mapped[str] = mapped_column(String(80))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    description: Mapped[str | None] = mapped_column(String(255))
    share_type: Mapped[str] = mapped_column(String(20), default="member", server_default="member")
    share_note: Mapped[str | None] = mapped_column(String(255))
    kind: Mapped[str] = mapped_column(String(20), default="income", server_default="income")
    income_date: Mapped[date] = mapped_column(Date)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Allowance(Base):
    __tablename__ = "allowances"
    __table_args__ = (Index("ix_allowances_user_period", "user_id", "period"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    period: Mapped[str] = mapped_column(String(7))
    note: Mapped[str | None] = mapped_column(String(255))
    given_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Expense(Base):
    __tablename__ = "expenses"
    __table_args__ = (
        Index("ix_expenses_family_date", "family_id", "expense_date"),
        Index("ix_expenses_user_date", "user_id", "expense_date"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    family_id: Mapped[int] = mapped_column(ForeignKey("families.id", ondelete="CASCADE"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id"))
    for_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    purpose: Mapped[str] = mapped_column(String(255))
    place: Mapped[str | None] = mapped_column(String(160))
    expense_date: Mapped[date] = mapped_column(Date)
    from_allowance: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    source: Mapped[str] = mapped_column(String(20), default="budget", server_default="budget")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())