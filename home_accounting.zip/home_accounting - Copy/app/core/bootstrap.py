import logging

import psycopg
from alembic import command
from alembic.config import Config
from psycopg import sql
from sqlalchemy import select

from app.core.config import BASE_DIR, settings
from app.core.security import hash_password
from app.db.session import SessionLocal
from app.models.models import ROLE_SUPER, User

log = logging.getLogger("bootstrap")


def ensure_database() -> None:
    with psycopg.connect(
        host=settings.db_host, port=settings.db_port, user=settings.db_user,
        password=settings.db_password, dbname="postgres", autocommit=True,
    ) as conn:
        exists = conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (settings.db_name,)).fetchone()
        if not exists:
            conn.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(settings.db_name)))
            log.warning("Database '%s' created", settings.db_name)


def run_migrations() -> None:
    cfg = Config(str(BASE_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BASE_DIR / "alembic"))
    command.upgrade(cfg, "head")


def seed_super_admin() -> None:
    with SessionLocal() as db:
        if db.scalar(select(User.id).where(User.role == ROLE_SUPER)):
            return
        db.add(User(
            family_id=None, full_name=settings.super_admin_name,
            email=settings.super_admin_email.lower(),
            password_hash=hash_password(settings.super_admin_password), role=ROLE_SUPER,
        ))
        db.commit()
        log.warning("Super admin created")


def bootstrap() -> None:
    ensure_database()
    run_migrations()
    seed_super_admin()