from app.models.models import ROLE_ADMIN, User


def can_view_family_reports(user: User) -> bool:
    return user.family_id is not None


def can_manage_income(user: User) -> bool:
    return user.role == ROLE_ADMIN


def can_use_family_ai(user: User) -> bool:
    return user.family_id is not None